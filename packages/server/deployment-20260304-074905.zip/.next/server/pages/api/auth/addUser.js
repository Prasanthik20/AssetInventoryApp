var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/addUser.js")
R.c("server/chunks/[root-of-the-server]__e31de495._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(22608)
module.exports=R.m(22608).exports
