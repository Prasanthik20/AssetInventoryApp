var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/reset-password.js")
R.c("server/chunks/[root-of-the-server]__59324cb8._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(55266)
module.exports=R.m(55266).exports
