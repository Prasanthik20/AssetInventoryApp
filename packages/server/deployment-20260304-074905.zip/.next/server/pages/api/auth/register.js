var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register.js")
R.c("server/chunks/[root-of-the-server]__596878b2._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(10591)
module.exports=R.m(10591).exports
