var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/forgot-password.js")
R.c("server/chunks/[root-of-the-server]__2e1e47a5._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(782)
module.exports=R.m(782).exports
