var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/login.js")
R.c("server/chunks/[root-of-the-server]__33de0a31._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(41961)
module.exports=R.m(41961).exports
