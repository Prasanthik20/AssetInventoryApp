var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/admin.js")
R.c("server/chunks/[root-of-the-server]__c3696e96._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(18273)
module.exports=R.m(18273).exports
