var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/hide.js")
R.c("server/chunks/[root-of-the-server]__d2851ab1._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(17309)
module.exports=R.m(17309).exports
