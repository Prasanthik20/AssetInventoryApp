module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},30056,e=>e.a(async(t,r)=>{try{let t=await e.y("pg");e.n(t),r()}catch(e){r(e)}},!0),65058,e=>e.a(async(t,r)=>{try{var s=e.i(30056),a=t([s]);[s]=a.then?(await a)():a;let i=new s.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:!1}});function n(e,t){return i.query(e,t)}e.s(["default",()=>n]),r()}catch(e){r(e)}},!1),18328,e=>e.a(async(t,r)=>{try{var s=e.i(65058),a=t([s]);async function n(e,t){try{if("GET"===e.method)return i(e,t);if("POST"===e.method)return o(e,t);if("PUT"===e.method)return d(e,t);return t.status(405).json({message:"Method not allowed"})}catch(e){return console.error("Supervisor API Error:",e),t.status(500).json({message:"Internal server error"})}}async function i(e,t){let r=Number(e.query.id);if(!r)return t.status(400).json({message:"Supervisor ID required"});let a=`
  SELECT
    n.id                    AS "notificationId",
    n.reason,
    n.reply,
    n.status,
    n.created_at            AS "createdAt",
    n."assignmentId",       -- 🔥 Need this for the PUT extend function later
    ad.id                   AS "assetId",
    ad.name                 AS "assetName",

    u."fullName"            AS "operatorName" -- The person who sent the reply

  FROM "Notifications" n
  LEFT JOIN "Asset_Details" ad ON ad.id = n."assetId"
  -- Join Users to 'senderId' because in a reply, the Operator is the sender
  LEFT JOIN "Users" u ON u."employeeId" = n."senderId" 

  WHERE n."receiverId" = $1   -- Supervisor is the Receiver of the reply
    AND n.status IN ('unread', 'replied')  -- Only show active replies
  ORDER BY n.created_at DESC
`,{rows:n}=await (0,s.default)(a,[r]);return console.log(`Backend found ${n.length} replies for ID ${r}`),t.status(200).json(n)}async function o(e,t){let{assetId:r,assignmentId:a,operatorId:n,receiverId:i,reason:o}=e.body;if(!r||!n||!i||!o)return t.status(400).json({message:"Missing required fields"});let d=`
  INSERT INTO "Notifications"
    ("assetId", "assignmentId", "senderId", "receiverId", "reason", "status")
  VALUES ($1, $2, $3, $4, $5, 'unread')
  RETURNING *;
`,{rows:u}=await (0,s.default)(d,[r,a||null,n,i,o]);return t.status(201).json(u[0])}async function d(e,t){let{notificationId:r,assignmentId:a,newReturnDate:n}=e.body;return r&&a&&n?(await (0,s.default)(`UPDATE "Asset_Assignments"
     SET expected_return_date = $1
     WHERE id = $2`,[n,a]),await (0,s.default)(`UPDATE "Notifications"
     SET status = 'resolved'
     WHERE id = $1`,[r]),t.status(200).json({message:"Resolved successfully"})):t.status(400).json({message:"Missing required fields"})}[s]=a.then?(await a)():a,e.s(["default",()=>n]),r()}catch(e){r(e)}},!1),62794,e=>e.a(async(t,r)=>{try{var s=e.i(33534),a=e.i(59016),n=e.i(55334),i=e.i(26175),o=e.i(18328),d=e.i(8322),u=e.i(84914),l=e.i(83666),c=t([o]);[o]=c.then?(await c)():c;let f=(0,i.hoist)(o,"default"),h=(0,i.hoist)(o,"config"),m=new n.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/notifications/supervisor",pathname:"/api/notifications/supervisor",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,r){m.isDev&&(0,l.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/notifications/supervisor";a=a.replace(/\/index$/,"")||"/";let n=await m.prepare(e,t,{srcPage:a});if(!n){t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:i,params:o,prerenderManifest:c,routerServerContext:p}=n;try{let r=e.method||"GET",s=(0,d.getTracer)(),n=s.getActiveScopeSpan(),l=m.instrumentationOnRequestError.bind(m),f=async n=>m.render(e,t,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:m.isDev,page:"/api/notifications/supervisor",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>l(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${r} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${r} ${a}`)});n?await f(n):await s.withPropagatedContext(e.headers,()=>s.trace(u.BaseServerSpan.handleRequest,{spanName:`${r} ${a}`,kind:d.SpanKind.SERVER,attributes:{"http.method":r,"http.target":e.url}},f))}catch(e){if(m.isDev)throw e;(0,s.sendError)(t,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,h,"default",0,f,"handler",()=>p]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__96ce794a._.js.map