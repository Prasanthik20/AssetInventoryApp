module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},30056,e=>e.a(async(t,a)=>{try{let t=await e.y("pg");e.n(t),a()}catch(e){a(e)}},!0),65058,e=>e.a(async(t,a)=>{try{var n=e.i(30056),i=t([n]);[n]=i.then?(await i)():i;let s=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:!1}});function r(e,t){return s.query(e,t)}e.s(["default",()=>r]),a()}catch(e){a(e)}},!1),27677,e=>e.a(async(t,a)=>{try{var n=e.i(65058),i=t([n]);async function r(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).end(`Method ${e.method} Not Allowed`);try{let{id:a,role:i}=e.query;if(!a||"string"!=typeof a)return t.status(400).json({message:"Valid numeric receiver ID is required."});let r="",s="";"operator"===i&&(s="AND n.reply IS NULL"),"admin"==i&&(r=`
        SELECT * FROM "Notifications" ORDER BY created_at DESC`),r=`
      SELECT
        n.id AS "notificationId",
        n."assignmentId",
        n.reason,
        n.reply,
        n.status AS "notificationStatus",
        n.created_at AS "createdAt",

        a.id AS "assetId",
        a.name AS "assetName",

        s."employeeId" AS "senderEmployeeId",
        s."fullName" AS "senderName"
      FROM "Notifications" n
      LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
      LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
      WHERE n."receiverId" = $1
      ${s}
      ORDER BY n.created_at DESC;
    `;let o=(await (0,n.default)(r,[parseInt(a)])).rows.map(e=>({notificationId:e.notificationId,assignmentId:e.assignmentId,reason:e.reason,reply:e.reply,status:e.notificationStatus,createdAt:e.createdAt,asset:{id:e.assetId,name:e.assetName},sender:{employeeId:e.senderEmployeeId,name:e.senderName}}));return t.status(200).json({count:o.length,notifications:o})}catch(e){return console.error("GET /notifications/[id] error:",e),t.status(500).json({message:"Internal server error"})}}[n]=i.then?(await i)():i,e.s(["default",()=>r]),a()}catch(e){a(e)}},!1),43366,e=>e.a(async(t,a)=>{try{var n=e.i(33534),i=e.i(59016),r=e.i(55334),s=e.i(26175),o=e.i(27677),d=e.i(8322),l=e.i(84914),c=e.i(83666),u=t([o]);[o]=u.then?(await u)():u;let m=(0,s.hoist)(o,"default"),f=(0,s.hoist)(o,"config"),y=new r.PagesAPIRouteModule({definition:{kind:i.RouteKind.PAGES_API,page:"/api/notifications/[id]",pathname:"/api/notifications/[id]",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,a){y.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let i="/api/notifications/[id]";i=i.replace(/\/index$/,"")||"/";let r=await y.prepare(e,t,{srcPage:i});if(!r){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:s,params:o,prerenderManifest:u,routerServerContext:p}=r;try{let a=e.method||"GET",n=(0,d.getTracer)(),r=n.getActiveScopeSpan(),c=y.instrumentationOnRequestError.bind(y),m=async r=>y.render(e,t,{query:{...s,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:u.preview,propagateError:!1,dev:y.isDev,page:"/api/notifications/[id]",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>c(e,...t)}).finally(()=>{if(!r)return;r.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=n.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=e.get("next.route");if(s){let e=`${a} ${s}`;r.setAttributes({"next.route":s,"http.route":s,"next.span_name":e}),r.updateName(e)}else r.updateName(`${a} ${i}`)});r?await m(r):await n.withPropagatedContext(e.headers,()=>n.trace(l.BaseServerSpan.handleRequest,{spanName:`${a} ${i}`,kind:d.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},m))}catch(e){if(y.isDev)throw e;(0,n.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,f,"default",0,m,"handler",()=>p]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__38537194._.js.map