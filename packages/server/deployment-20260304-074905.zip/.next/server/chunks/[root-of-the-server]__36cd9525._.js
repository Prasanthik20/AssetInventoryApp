module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},30056,e=>e.a(async(t,a)=>{try{let t=await e.y("pg");e.n(t),a()}catch(e){a(e)}},!0),65058,e=>e.a(async(t,a)=>{try{var r=e.i(30056),n=t([r]);[r]=n.then?(await n)():n;let i=new r.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:!1}});function s(e,t){return i.query(e,t)}e.s(["default",()=>s]),a()}catch(e){a(e)}},!1),2305,e=>e.a(async(t,a)=>{try{var r=e.i(65058),n=t([r]);async function s(e,t){try{if("GET"===e.method){let{id:a,role:n}=e.query,s="string"==typeof n?n.toLowerCase():"",i="",o=[];if(a||s){if(!a||"0"===a)return t.status(200).json([]);i=`
          SELECT
            n.id::text AS "notifId",
            n.reason,
            n.reply,
            n.status,
            n."created_at" AS "createdAt",
            a.name AS "assetName",
            s."fullName" AS "senderName",
            r."roleName" AS "senderRole"
          FROM "Notifications" n
          LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
          LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
          LEFT JOIN "Roles" r ON s."roleId" = r."roleId"
          WHERE n."receiverId" = $1
          ${"operator"===s?"AND n.reply IS NULL":""}
          ORDER BY n."created_at" DESC;
        `,o=[parseInt(a)]}else i=`
          SELECT
            n.id::text AS "notifId",
            n.reason,
            n.reply,
            n.status,
            n."created_at" AS "createdAt",
            a.name AS "assetName",
            s."fullName" AS "senderName",
            r."roleName" AS "senderRole"
          FROM "Notifications" n
          LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
          LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
          LEFT JOIN "Roles" r ON s."roleId" = r."roleId"
          ORDER BY n."created_at" DESC;
        `;let l=await (0,r.default)(i,o);return t.status(200).json(l.rows)}if("POST"===e.method){let{assetId:a,senderId:n,receiverId:s,reason:i}=e.body;if(!a||!n||!s||!i)return t.status(400).json({message:"Missing required fields"});let o=`
        INSERT INTO "Notifications"
        ("assetId", "senderId", "receiverId", "reason")
        VALUES ($1, $2, $3, $4)
        RETURNING *;
      `,l=[Number(a),Number(n),Number(s),i],d=await (0,r.default)(o,l);return t.status(201).json({message:"Notification sent successfully",notification:d.rows[0]})}return t.status(405).json({message:"Method not allowed"})}catch(e){return console.error("Notifications API Error:",e),t.status(500).json({message:"Internal server error",error:e.message})}}[r]=n.then?(await n)():n,e.s(["default",()=>s]),a()}catch(e){a(e)}},!1),25229,e=>e.a(async(t,a)=>{try{var r=e.i(33534),n=e.i(59016),s=e.i(55334),i=e.i(26175),o=e.i(2305),l=e.i(8322),d=e.i(84914),u=e.i(83666),c=t([o]);[o]=c.then?(await c)():c;let f=(0,i.hoist)(o,"default"),m=(0,i.hoist)(o,"config"),N=new s.PagesAPIRouteModule({definition:{kind:n.RouteKind.PAGES_API,page:"/api/notifications/index",pathname:"/api/notifications",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,a){N.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/notifications/index";n=n.replace(/\/index$/,"")||"/";let s=await N.prepare(e,t,{srcPage:n});if(!s){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:i,params:o,prerenderManifest:c,routerServerContext:p}=s;try{let a=e.method||"GET",r=(0,l.getTracer)(),s=r.getActiveScopeSpan(),u=N.instrumentationOnRequestError.bind(N),f=async s=>N.render(e,t,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:N.isDev,page:"/api/notifications/index",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!s)return;s.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${a} ${i}`;s.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),s.updateName(e)}else s.updateName(`${a} ${n}`)});s?await f(s):await r.withPropagatedContext(e.headers,()=>r.trace(d.BaseServerSpan.handleRequest,{spanName:`${a} ${n}`,kind:l.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},f))}catch(e){if(N.isDev)throw e;(0,r.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,m,"default",0,f,"handler",()=>p]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__36cd9525._.js.map