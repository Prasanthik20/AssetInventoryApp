module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},30056,e=>e.a(async(t,a)=>{try{let t=await e.y("pg");e.n(t),a()}catch(e){a(e)}},!0),65058,e=>e.a(async(t,a)=>{try{var r=e.i(30056),n=t([r]);[r]=n.then?(await n)():n;let s=new r.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:!1}});function i(e,t){return s.query(e,t)}e.s(["default",()=>i]),a()}catch(e){a(e)}},!1),32839,e=>e.a(async(t,a)=>{try{var r=e.i(65058),n=t([r]);async function i(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).end(`Method ${e.method} Not Allowed`);try{let e=`
      SELECT
        n.id                    AS "notificationId",
        n.reason,
        n.reply,
        n.status,
        n.created_at            AS "createdAt",
        COALESCE(n."isSeenByAdmin", false) AS "isSeenByAdmin",

        ad.id                   AS "assetId",
        ad.name                 AS "assetName",

        s."employeeId"          AS "senderId",
        s."fullName"            AS "senderName",

        r."employeeId"          AS "receiverId",
        r."fullName"            AS "receiverName"

      FROM "Notifications" n
      LEFT JOIN "Asset_Details" ad ON ad.id = n."assetId"
      LEFT JOIN "Users" s ON s."employeeId" = n."senderId"
      LEFT JOIN "Users" r ON r."employeeId" = n."receiverId"

      WHERE COALESCE(n."isSeenByAdmin", false) = false
      ORDER BY n.created_at DESC;
    `,{rows:a}=await (0,r.default)(e),n=a.map(e=>({id:e.notificationId,message:e.reply??e.reason,reason:e.reason,reply:e.reply,status:e.status,createdAt:e.createdAt,asset:e.assetId?{id:e.assetId,name:e.assetName}:null,sender:{employeeId:e.senderId,name:e.senderName},receiver:{employeeId:e.receiverId,name:e.receiverName}}));return t.status(200).json({notifications:n})}catch(e){return console.error("❌ Admin Notifications Error:",e),t.status(500).json({message:"Internal server error"})}}[r]=n.then?(await n)():n,e.s(["default",()=>i]),a()}catch(e){a(e)}},!1),18273,e=>e.a(async(t,a)=>{try{var r=e.i(33534),n=e.i(59016),i=e.i(55334),s=e.i(26175),d=e.i(32839),o=e.i(8322),l=e.i(84914),c=e.i(83666),u=t([d]);[d]=u.then?(await u)():u;let m=(0,s.hoist)(d,"default"),y=(0,s.hoist)(d,"config"),f=new i.PagesAPIRouteModule({definition:{kind:n.RouteKind.PAGES_API,page:"/api/notifications/admin",pathname:"/api/notifications/admin",bundlePath:"",filename:""},userland:d,distDir:".next",relativeProjectDir:""});async function p(e,t,a){f.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/notifications/admin";n=n.replace(/\/index$/,"")||"/";let i=await f.prepare(e,t,{srcPage:n});if(!i){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:s,params:d,prerenderManifest:u,routerServerContext:p}=i;try{let a=e.method||"GET",r=(0,o.getTracer)(),i=r.getActiveScopeSpan(),c=f.instrumentationOnRequestError.bind(f),m=async i=>f.render(e,t,{query:{...s,...d},params:d,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:u.preview,propagateError:!1,dev:f.isDev,page:"/api/notifications/admin",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>c(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=e.get("next.route");if(s){let e=`${a} ${s}`;i.setAttributes({"next.route":s,"http.route":s,"next.span_name":e}),i.updateName(e)}else i.updateName(`${a} ${n}`)});i?await m(i):await r.withPropagatedContext(e.headers,()=>r.trace(l.BaseServerSpan.handleRequest,{spanName:`${a} ${n}`,kind:o.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},m))}catch(e){if(f.isDev)throw e;(0,r.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,y,"default",0,m,"handler",()=>p]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__c3696e96._.js.map