self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error",
    "/api/assets",
    "/api/assets/assetId",
    "/api/assets/assign",
    "/api/assets/create",
    "/api/assets/extend-return-date",
    "/api/auth/addUser",
    "/api/auth/forgot-password",
    "/api/auth/login",
    "/api/auth/register",
    "/api/auth/reset-password",
    "/api/auth/users",
    "/api/categories",
    "/api/dashboard",
    "/api/dashboard/metrics",
    "/api/notifications",
    "/api/notifications/admin",
    "/api/notifications/hide",
    "/api/notifications/operator",
    "/api/notifications/overdue",
    "/api/notifications/overdue-assets",
    "/api/notifications/reply",
    "/api/notifications/supervisor",
    "/api/notifications/[id]",
    "/api/operator/assets",
    "/api/operator/returnAsset",
    "/api/statuses"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()