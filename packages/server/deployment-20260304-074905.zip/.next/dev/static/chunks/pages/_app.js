__turbopack_load_page_chunks__("/_app", [
  "static/chunks/791b8_next_dist_compiled_75d2de03._.js",
  "static/chunks/791b8_next_dist_shared_lib_c0e0d572._.js",
  "static/chunks/791b8_next_dist_client_45f1487a._.js",
  "static/chunks/791b8_next_dist_9e6b4d73._.js",
  "static/chunks/791b8_next_app_3bee5fe5.js",
  "static/chunks/[next]_entry_page-loader_ts_84d25d4b._.js",
  "static/chunks/791b8_react-dom_c5a13aa4._.js",
  "static/chunks/791b8_3c75d4c7._.js",
  "static/chunks/[root-of-the-server]__903e9b07._.js",
  "static/chunks/packages_server_src_pages__app_2da965e7._.js",
  "static/chunks/turbopack-packages_server_src_pages__app_46845372._.js"
])
