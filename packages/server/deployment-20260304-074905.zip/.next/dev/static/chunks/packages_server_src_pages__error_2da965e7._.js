(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/791b8_next_dist_compiled_75d2de03._.js",
  "static/chunks/791b8_next_dist_shared_lib_eb7ed3e0._.js",
  "static/chunks/791b8_next_dist_client_45f1487a._.js",
  "static/chunks/791b8_next_dist_b7c7a6bb._.js",
  "static/chunks/791b8_next_error_e4aa6e44.js",
  "static/chunks/[next]_entry_page-loader_ts_a1604961._.js",
  "static/chunks/791b8_react-dom_c5a13aa4._.js",
  "static/chunks/791b8_3c75d4c7._.js",
  "static/chunks/[root-of-the-server]__9efc29ab._.js"
],
    source: "entry"
});
