var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/791b8_f4c6c5c0._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/791b8_353d7dc7._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/791b8_next_9e267fcb._.js")
R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/packages/server/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/packages/server/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/packages/server/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/packages/server/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/packages/server/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/packages/server/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
