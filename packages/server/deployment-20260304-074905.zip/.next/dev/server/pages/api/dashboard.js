var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/dashboard.js")
R.c("server/chunks/791b8_next_dist_3a32f8fb._.js")
R.c("server/chunks/[root-of-the-server]__e51fbdda._.js")
R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/dashboard.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/dashboard.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
