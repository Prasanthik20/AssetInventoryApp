var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/users.js")
R.c("server/chunks/791b8_next_dist_a230a98c._.js")
R.c("server/chunks/[root-of-the-server]__931829d4._.js")
R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/auth/users.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/auth/users.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
