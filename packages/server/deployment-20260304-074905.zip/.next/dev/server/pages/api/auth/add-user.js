var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/add-user.js")
R.c("server/chunks/791b8_next_dist_2aa04326._.js")
R.c("server/chunks/[root-of-the-server]__2ee131bb._.js")
R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/auth/add-user.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/auth/add-user.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
