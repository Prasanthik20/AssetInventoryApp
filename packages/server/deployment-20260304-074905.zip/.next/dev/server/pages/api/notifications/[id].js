var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/[id].js")
R.c("server/chunks/791b8_next_dist_c3a4b8ee._.js")
R.c("server/chunks/[root-of-the-server]__672cbbe0._.js")
R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/notifications/[id].ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/notifications/[id].ts [api] (ecmascript)\" } [api] (ecmascript)").exports
