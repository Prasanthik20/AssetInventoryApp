var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/admin.js")
R.c("server/chunks/791b8_next_dist_5f3a31e1._.js")
R.c("server/chunks/[root-of-the-server]__590d3912._.js")
R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/notifications/admin.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/packages/server/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/packages/server/src/pages/api/notifications/admin.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
