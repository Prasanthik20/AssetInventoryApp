module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/pg [external] (pg, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("pg");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/packages/server/src/lib/db.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>query
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/pg [external] (pg, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
const pool = new __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__["Pool"]({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});
function query(text, params) {
    return pool.query(text, params);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/packages/server/src/pages/api/auth/users.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>usersCoreHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/server/src/lib/db.ts [api] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
async function usersCoreHandler(req, res) {
    if (req.method !== 'GET') {
        res.setHeader('Allow', [
            'GET'
        ]);
        res.status(405).end(`Method ${req.method} Not Allowed`);
        return; // <-- Exit (return void)
    }
    try {
        // Corrected Query: Fetch all users and join with Roles to get the roleName
        const sqlQuery = `
   SELECT u.*, r."roleName",
         json_agg(
           json_build_object(
             'id', a.id,
             'name', a.name,
             'barcode', a."asset_Id"
           )
         ) FILTER (WHERE a.id IS NOT NULL) AS assignedAssets
  FROM "Users" AS u
  LEFT JOIN "Roles" AS r ON u."roleId" = r."roleId"
  LEFT JOIN "Asset_Details" AS a ON a."assigned_to" = u."employeeId"
  GROUP BY u."userId", r."roleName"
  ORDER BY u."userId" ASC;
`;
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["default"])(sqlQuery, []);
        // Format result data
        const users = result.rows.map((user)=>({
                userId: user.userId,
                employeeId: user.employeeId,
                fullName: user.fullName,
                email: user.email,
                phoneNumber: user.phoneNumber || null,
                address: user.address || null,
                photoURL: user.photoURL || null,
                // Use the fetched roleName
                role: {
                    roleName: user.roleName || 'Unassigned'
                },
                assignedAssets: user.assignedassets || []
            }));
        res.status(200).json({
            message: 'Users fetched successfully!',
            count: users.length,
            users
        });
        return; // <-- Exit (return void) after sending 200 response
    } catch (error) {
        console.error('❌ Get All Users API Error:', error);
        res.status(500).json({
            message: 'An internal server error occurred while fetching users.'
        });
        return; // <-- Exit (return void) after sending 500 response
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__931829d4._.js.map