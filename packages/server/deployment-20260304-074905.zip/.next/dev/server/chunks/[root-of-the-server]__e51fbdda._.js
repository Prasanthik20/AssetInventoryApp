module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client", () => require("@prisma/client"));

module.exports = mod;
}),
"[project]/packages/server/src/prisma/client.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
const prisma = new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["PrismaClient"]();
const __TURBOPACK__default__export__ = prisma;
}),
"[project]/packages/server/src/pages/api/dashboard.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>handler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$prisma$2f$client$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/server/src/prisma/client.ts [api] (ecmascript)");
;
async function handler(req, res) {
    try {
        // Total Assets
        const totalAssets = await __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$prisma$2f$client$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["default"].asset_Details.count();
        // Total Users
        const totalUsers = await __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$prisma$2f$client$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["default"].users.count();
        // Office Assets → Unassigned
        const officeAssets = await __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$prisma$2f$client$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["default"].asset_Details.count({
            where: {
                status: {
                    status: "Unassigned"
                }
            }
        });
        // Field Assets → Assigned + Overdue
        const fieldAssets = await __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$prisma$2f$client$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["default"].asset_Details.count({
            where: {
                status: {
                    status: {
                        in: [
                            "Assigned",
                            "Overdue"
                        ]
                    }
                }
            }
        });
        return res.status(200).json({
            totalAssets,
            totalUsers,
            officeAssets,
            fieldAssets
        });
    } catch (error) {
        console.error("Dashboard API Error:", error);
        return res.status(500).json({
            error: "Something went wrong"
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__e51fbdda._.js.map