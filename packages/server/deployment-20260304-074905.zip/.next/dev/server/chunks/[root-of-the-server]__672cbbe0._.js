module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/pg [external] (pg, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("pg");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/packages/server/src/lib/db.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>query
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/pg [external] (pg, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
const pool = new __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__["Pool"]({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});
function query(text, params) {
    return pool.query(text, params);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/packages/server/src/pages/api/notifications/[id].ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>handler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/server/src/lib/db.ts [api] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
async function handler(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'GET') {
        res.setHeader('Allow', [
            'GET'
        ]);
        return res.status(405).end(`Method ${req.method} Not Allowed`);
    }
    try {
        const { id: receiverEmployeeId, role } = req.query;
        if (!receiverEmployeeId || typeof receiverEmployeeId !== "string") {
            return res.status(400).json({
                message: "Valid numeric receiver ID is required."
            });
        }
        let extraCondition = "";
        let sqlQuery = "";
        // OPERATOR MODE → only show notifications without reply (pending)
        if (role === "operator") {
            extraCondition = `AND n.reply IS NULL`;
        }
        // SUPERVISOR MODE → show all notifications
        // no extra condition
        if (role === "admin") {
            sqlQuery = `Select * from "Notifications" order by "created_at" desc;`;
        } else {
            sqlQuery = `
      SELECT
        n.id AS "notificationId",
        n."assignmentId",
        n.reason,
        n.reply,
        n.status AS "notificationStatus",
        n.created_at AS "createdAt",

        a.id AS "assetId",
        a.name AS "assetName",

        s."employeeId" AS "senderEmployeeId",
        s."fullName" AS "senderName"
      FROM "Notifications" n
      LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
      LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
      WHERE n."receiverId" = $1
      ${extraCondition}
      ORDER BY n.created_at DESC;
    `;
        }
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$server$2f$src$2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["default"])(sqlQuery, [
            parseInt(receiverEmployeeId)
        ]);
        const formattedNotifications = result.rows.map((row)=>({
                notificationId: row.notificationId,
                assignmentId: row.assignmentId,
                reason: row.reason,
                reply: row.reply,
                status: row.notificationStatus,
                createdAt: row.createdAt,
                asset: {
                    id: row.assetId,
                    name: row.assetName
                },
                sender: {
                    employeeId: row.senderEmployeeId,
                    name: row.senderName
                }
            }));
        return res.status(200).json({
            count: formattedNotifications.length,
            notifications: formattedNotifications
        });
    } catch (err) {
        console.error("GET /notifications/[id] error:", err);
        return res.status(500).json({
            message: "Internal server error"
        });
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__672cbbe0._.js.map