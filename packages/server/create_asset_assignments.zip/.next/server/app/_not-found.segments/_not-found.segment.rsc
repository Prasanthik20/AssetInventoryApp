1:"$Sreact.fragment"
2:I[49465,["/_next/static/chunks/5b12029ccc604d0f.js","/_next/static/chunks/0dea1a803408d166.js"],"default"]
3:I[96709,["/_next/static/chunks/5b12029ccc604d0f.js","/_next/static/chunks/0dea1a803408d166.js"],"default"]
0:{"buildId":"h7ZBm5ExSIitkQ5ifsqyA","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
