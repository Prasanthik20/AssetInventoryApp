var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__84494e95._.js")
R.c("server/chunks/[root-of-the-server]__6ed80bdc._.js")
R.c("server/chunks/packages_server__next-internal_server_app_favicon_ico_route_actions_84297f34.js")
R.m(86044)
module.exports=R.m(86044).exports
