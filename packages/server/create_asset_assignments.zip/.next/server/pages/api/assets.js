var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/assets.js")
R.c("server/chunks/[root-of-the-server]__50a38b2f._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(90556)
module.exports=R.m(90556).exports
