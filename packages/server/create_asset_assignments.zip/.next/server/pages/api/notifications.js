var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications.js")
R.c("server/chunks/[root-of-the-server]__36cd9525._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(25229)
module.exports=R.m(25229).exports
