var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/dashboard.js")
R.c("server/chunks/[root-of-the-server]__58c4f415._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(93960)
module.exports=R.m(93960).exports
