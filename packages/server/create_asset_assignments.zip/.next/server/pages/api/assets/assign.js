var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/assign.js")
R.c("server/chunks/[root-of-the-server]__8ecb1b0f._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(45151)
module.exports=R.m(45151).exports
