var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/assetId.js")
R.c("server/chunks/[root-of-the-server]__af3c1913._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(6599)
module.exports=R.m(6599).exports
