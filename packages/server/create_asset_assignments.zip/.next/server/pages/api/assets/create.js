var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/create.js")
R.c("server/chunks/[root-of-the-server]__b2e05d2f._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(41744)
module.exports=R.m(41744).exports
