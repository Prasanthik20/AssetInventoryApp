var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/extend-return-date.js")
R.c("server/chunks/[root-of-the-server]__69527323._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(34348)
module.exports=R.m(34348).exports
