var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/overdue-assets.js")
R.c("server/chunks/[root-of-the-server]__2c435177._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(70221)
module.exports=R.m(70221).exports
