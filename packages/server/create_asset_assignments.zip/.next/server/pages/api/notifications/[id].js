var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/[id].js")
R.c("server/chunks/[root-of-the-server]__38537194._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(43366)
module.exports=R.m(43366).exports
