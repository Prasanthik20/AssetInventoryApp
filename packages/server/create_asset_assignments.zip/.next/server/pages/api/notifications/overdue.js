var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/overdue.js")
R.c("server/chunks/[root-of-the-server]__d34a96c6._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(17823)
module.exports=R.m(17823).exports
