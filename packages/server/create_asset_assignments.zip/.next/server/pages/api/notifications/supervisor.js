var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/supervisor.js")
R.c("server/chunks/[root-of-the-server]__96ce794a._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(62794)
module.exports=R.m(62794).exports
