var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/operator.js")
R.c("server/chunks/[root-of-the-server]__ddde781a._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(90921)
module.exports=R.m(90921).exports
