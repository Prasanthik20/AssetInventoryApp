var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/reply.js")
R.c("server/chunks/[root-of-the-server]__e4d4163a._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(18522)
module.exports=R.m(18522).exports
