var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/users.js")
R.c("server/chunks/[root-of-the-server]__cc41652a._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(10245)
module.exports=R.m(10245).exports
