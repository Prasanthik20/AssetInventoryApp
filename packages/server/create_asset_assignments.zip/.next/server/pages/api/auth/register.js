var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register.js")
R.c("server/chunks/[root-of-the-server]__5d7d23d4._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(10591)
module.exports=R.m(10591).exports
