var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/operator/assets.js")
R.c("server/chunks/[root-of-the-server]__65018242._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(41504)
module.exports=R.m(41504).exports
