var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/operator/returnAsset.js")
R.c("server/chunks/[root-of-the-server]__2ddb9c69._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(82894)
module.exports=R.m(82894).exports
