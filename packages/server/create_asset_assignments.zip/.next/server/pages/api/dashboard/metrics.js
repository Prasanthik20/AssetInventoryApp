var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/dashboard/metrics.js")
R.c("server/chunks/[root-of-the-server]__f1ac8135._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(70876)
module.exports=R.m(70876).exports
