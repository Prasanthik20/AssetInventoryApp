var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/statuses.js")
R.c("server/chunks/[root-of-the-server]__68396fb9._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(53977)
module.exports=R.m(53977).exports
