var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/categories.js")
R.c("server/chunks/[root-of-the-server]__493fdd88._.js")
R.c("server/chunks/[root-of-the-server]__5958e49d._.js")
R.m(95763)
module.exports=R.m(95763).exports
