var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__debeb149._.js")
R.c("server/chunks/ssr/[root-of-the-server]__f3f8aef2._.js")
R.m(11921)
module.exports=R.m(11921).exports
