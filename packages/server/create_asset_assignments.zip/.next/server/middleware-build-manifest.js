globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/58e6ab6abd4b7deb.js",
      "static/chunks/21693af0e5947607.js",
      "static/chunks/turbopack-29e283371d7d0588.js"
    ],
    "/_error": [
      "static/chunks/aafeea1476204ef7.js",
      "static/chunks/21693af0e5947607.js",
      "static/chunks/turbopack-905a3c054cac85e3.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a78dae34f8cd62dc.js",
    "static/chunks/cfdf8a6d616c2b44.js",
    "static/chunks/c757984141c99415.js",
    "static/chunks/turbopack-cb211b19e801343e.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];