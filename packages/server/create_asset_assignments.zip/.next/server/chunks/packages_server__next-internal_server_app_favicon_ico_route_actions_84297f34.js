module.exports=[15473,(e,o,d)=>{}];

//# sourceMappingURL=packages_server__next-internal_server_app_favicon_ico_route_actions_84297f34.js.map