module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},30056,e=>e.a(async(t,a)=>{try{let t=await e.y("pg");e.n(t),a()}catch(e){a(e)}},!0),65058,e=>e.a(async(t,a)=>{try{var s=e.i(30056),r=t([s]);[s]=r.then?(await r)():r;let i=new s.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:!1}});function n(e,t){return i.query(e,t)}e.s(["default",()=>n]),a()}catch(e){a(e)}},!1),696,e=>e.a(async(t,a)=>{try{var s=e.i(65058),r=t([s]);async function n(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).end(`Method ${e.method} Not Allowed`);let{operatorId:a}=e.query;if(!a||"string"!=typeof a)return t.status(400).json({message:"Operator ID is required."});try{let e=parseInt(a),r=`
    SELECT DISTINCT ON (ad.id) 
    aa.id AS "assignmentId",
    ad.id AS "assetId",
    ad.name AS "assetName",
    ad."asset_Id" AS "barcode",
    ad.location AS "assetLocation",
    aa.expected_return_date AS "expectedReturnDate",
    ad.assigned_by AS "assignedBy",
    s.status AS "Status"
  FROM "Asset_Assignments" aa
  INNER JOIN "Asset_Details" ad ON ad.id = aa."assetId"
  INNER JOIN "Status" s ON s.id = ad.status_Id
  WHERE aa."operator_employeeId" = $1
    AND ad.assigned_to = $1   
  ORDER BY ad.id, aa.assigned_date DESC;
    `,n=(await (0,s.default)(r,[e])).rows.map(e=>{let t=new Date;t.setHours(0,0,0,0);let a=!1;if(e.expectedReturnDate){let s=new Date(e.expectedReturnDate);s.setHours(0,0,0,0),a=s<t}return{assignmentId:Number(e.assignmentId),assetId:Number(e.assetId),assetName:e.assetName,barcode:e.barcode,location:e.assetLocation,expectedReturnDate:e.expectedReturnDate,assignedBy:e.assignedBy,isOverdue:a,status:a?"Overdue":"Assigned"}}),i=`
      SELECT location 
      FROM "Asset_Assignments"
      WHERE "operator_employeeId" = $1
      ORDER BY assigned_date DESC NULLS LAST
      LIMIT 1;
    `,o=await (0,s.default)(i,[e]),d=o.rows.length>0?o.rows[0].location:"No Location",l={operatorEmployeeId:e,assignedCount:n.length,location:d,assets:n};return t.status(200).json(l)}catch(e){return console.error("Operator Assets API Error:",e),t.status(500).json({message:"Internal server error."})}}[s]=r.then?(await r)():r,e.s(["default",()=>n]),a()}catch(e){a(e)}},!1),41504,e=>e.a(async(t,a)=>{try{var s=e.i(33534),r=e.i(59016),n=e.i(55334),i=e.i(26175),o=e.i(696),d=e.i(8322),l=e.i(84914),u=e.i(83666),p=t([o]);[o]=p.then?(await p)():p;let g=(0,i.hoist)(o,"default"),m=(0,i.hoist)(o,"config"),h=new n.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/operator/assets",pathname:"/api/operator/assets",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function c(e,t,a){h.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/operator/assets";r=r.replace(/\/index$/,"")||"/";let n=await h.prepare(e,t,{srcPage:r});if(!n){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:i,params:o,prerenderManifest:p,routerServerContext:c}=n;try{let a=e.method||"GET",s=(0,d.getTracer)(),n=s.getActiveScopeSpan(),u=h.instrumentationOnRequestError.bind(h),g=async n=>h.render(e,t,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:h.isDev,page:"/api/operator/assets",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${a} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${a} ${r}`)});n?await g(n):await s.withPropagatedContext(e.headers,()=>s.trace(l.BaseServerSpan.handleRequest,{spanName:`${a} ${r}`,kind:d.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},g))}catch(e){if(h.isDev)throw e;(0,s.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,m,"default",0,g,"handler",()=>c]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__65018242._.js.map