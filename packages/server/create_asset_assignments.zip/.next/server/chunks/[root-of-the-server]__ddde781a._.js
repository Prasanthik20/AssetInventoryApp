module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},30056,e=>e.a(async(t,r)=>{try{let t=await e.y("pg");e.n(t),r()}catch(e){r(e)}},!0),65058,e=>e.a(async(t,r)=>{try{var a=e.i(30056),n=t([a]);[a]=n.then?(await n)():n;let s=new a.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:!1}});function i(e,t){return s.query(e,t)}e.s(["default",()=>i]),r()}catch(e){r(e)}},!1),46695,e=>e.a(async(t,r)=>{try{var a=e.i(65058),n=t([a]);async function i(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).end(`Method ${e.method} Not Allowed`);let r=Number(e.query.id);if(!r)return t.status(400).json({message:"Operator ID missing or invalid"});try{let e=`
      SELECT
        n.id                    AS "notificationId",
        n.reason,
        n.reply,
        n.status,
        n.created_at            AS "createdAt",

        ad.id                   AS "assetId",
        ad.name                 AS "assetName",

        s."employeeId"          AS "senderId",
        s."fullName"            AS "senderName",

        r."employeeId"          AS "receiverId",
        r."fullName"            AS "receiverName"

      FROM "Notifications" n
      LEFT JOIN "Asset_Details" ad ON ad.id = n."assetId"
      LEFT JOIN "Users" s ON s."employeeId" = n."senderId"
      LEFT JOIN "Users" r ON r."employeeId" = n."receiverId"

      WHERE n."receiverId" = $1
        AND n.status IN ('unread', 'resolved')
      ORDER BY n.created_at DESC;
    `,{rows:n}=await (0,a.default)(e,[r]),i=n.map(e=>({id:e.notificationId,notificationId:e.notificationId,message:e.reply??e.reason,reason:e.reason,reply:e.reply,status:e.status,createdAt:e.createdAt,asset:e.assetId?{id:e.assetId,name:e.assetName}:null,sender:{employeeId:e.senderId,name:e.senderName},receiver:{employeeId:e.receiverId,name:e.receiverName}}));return t.status(200).json({notifications:i})}catch(e){return console.error("❌ Operator Notifications Error:",e),t.status(500).json({message:"Internal server error",error:e instanceof Error?e.message:e})}}[a]=n.then?(await n)():n,e.s(["default",()=>i]),r()}catch(e){r(e)}},!1),90921,e=>e.a(async(t,r)=>{try{var a=e.i(33534),n=e.i(59016),i=e.i(55334),s=e.i(26175),o=e.i(46695),d=e.i(8322),l=e.i(84914),c=e.i(83666),u=t([o]);[o]=u.then?(await u)():u;let m=(0,s.hoist)(o,"default"),f=(0,s.hoist)(o,"config"),y=new i.PagesAPIRouteModule({definition:{kind:n.RouteKind.PAGES_API,page:"/api/notifications/operator",pathname:"/api/notifications/operator",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,r){y.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/notifications/operator";n=n.replace(/\/index$/,"")||"/";let i=await y.prepare(e,t,{srcPage:n});if(!i){t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:s,params:o,prerenderManifest:u,routerServerContext:p}=i;try{let r=e.method||"GET",a=(0,d.getTracer)(),i=a.getActiveScopeSpan(),c=y.instrumentationOnRequestError.bind(y),m=async i=>y.render(e,t,{query:{...s,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:u.preview,propagateError:!1,dev:y.isDev,page:"/api/notifications/operator",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>c(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=e.get("next.route");if(s){let e=`${r} ${s}`;i.setAttributes({"next.route":s,"http.route":s,"next.span_name":e}),i.updateName(e)}else i.updateName(`${r} ${n}`)});i?await m(i):await a.withPropagatedContext(e.headers,()=>a.trace(l.BaseServerSpan.handleRequest,{spanName:`${r} ${n}`,kind:d.SpanKind.SERVER,attributes:{"http.method":r,"http.target":e.url}},m))}catch(e){if(y.isDev)throw e;(0,a.sendError)(t,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,f,"default",0,m,"handler",()=>p]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__ddde781a._.js.map