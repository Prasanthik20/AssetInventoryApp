module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},30056,e=>e.a(async(t,a)=>{try{let t=await e.y("pg");e.n(t),a()}catch(e){a(e)}},!0),65058,e=>e.a(async(t,a)=>{try{var s=e.i(30056),r=t([s]);[s]=r.then?(await r)():r;let i=new s.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:!1}});function n(e,t){return i.query(e,t)}e.s(["default",()=>n]),a()}catch(e){a(e)}},!1),61706,e=>e.a(async(t,a)=>{try{var s=e.i(65058),r=t([s]);async function n(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).end(`Method ${e.method} Not Allowed`);let{assetId:a}=e.query;if(!a||"string"!=typeof a)return t.status(400).json({message:"Asset ID is required."});try{let e=`
      SELECT
        a.id AS "assetId",
        a.name AS "assetName",
        cat.category AS "category",
        s.status AS "dbStatus",
        a.model_no AS "modelNumber",
        a.serial_no AS "serialNumber",
        a."asset_Id" AS "barcode",
        a.location,
        u."fullName" AS "assignedBy",
        a.assigned_to,
        a.warranty_expiry AS "warrantyExpiry",
        a.purchase_date AS "purchaseDate",
        a.price,
        (
          SELECT "assigned_date"
          FROM "Asset_Assignments"
          WHERE "assetId" = a.id
          ORDER BY id DESC
          LIMIT 1
        ) AS assigned_date,
        (
          SELECT "expected_return_date"
          FROM "Asset_Assignments"
          WHERE "assetId" = a.id
          ORDER BY id DESC
          LIMIT 1
        ) AS expected_return_date
      FROM "Asset_Details" a
      LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
      LEFT JOIN "Status" s ON a.status_id = s.id
      LEFT JOIN "Users" u ON a.assigned_by = u."employeeId"
      WHERE a.id = $1;
    `,r=await (0,s.default)(e,[parseInt(a)]);if(0===r.rows.length)return t.status(404).json({message:`Asset with ID ${a} not found.`});let n=r.rows[0],i=e=>e?new Date(e).toISOString().split("T")[0]:null,d=new Date;d.setHours(0,0,0,0);let o=n.expected_return_date?new Date(n.expected_return_date):null,l=!!o&&o<d,u="Assigned"===n.dbStatus&&null!==n.assigned_to,c={assetId:n.assetId,assetName:n.assetName,category:n.category,status:u&&l?"Overdue":n.dbStatus,modelNumber:n.modelNumber,serialNumber:n.serialNumber,barcode:n.barcode,location:n.location,assignedBy:n.assignedBy||"N/A",warrantyExpiry:i(n.warrantyExpiry),purchaseDate:i(n.purchaseDate),assignedDate:i(n.assigned_date),expectedReturnDate:i(n.expected_return_date),value:n.price?parseFloat(n.price).toLocaleString():"N/A"};return t.status(200).json(c)}catch(e){return console.error("Get Asset Error:",e),t.status(500).json({message:"Internal server error."})}}[s]=r.then?(await r)():r,e.s(["default",()=>n]),a()}catch(e){a(e)}},!1),6599,e=>e.a(async(t,a)=>{try{var s=e.i(33534),r=e.i(59016),n=e.i(55334),i=e.i(26175),d=e.i(61706),o=e.i(8322),l=e.i(84914),u=e.i(83666),c=t([d]);[d]=c.then?(await c)():c;let g=(0,i.hoist)(d,"default"),y=(0,i.hoist)(d,"config"),m=new n.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/assets/assetId",pathname:"/api/assets/assetId",bundlePath:"",filename:""},userland:d,distDir:".next",relativeProjectDir:""});async function p(e,t,a){m.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/assets/assetId";r=r.replace(/\/index$/,"")||"/";let n=await m.prepare(e,t,{srcPage:r});if(!n){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:i,params:d,prerenderManifest:c,routerServerContext:p}=n;try{let a=e.method||"GET",s=(0,o.getTracer)(),n=s.getActiveScopeSpan(),u=m.instrumentationOnRequestError.bind(m),g=async n=>m.render(e,t,{query:{...i,...d},params:d,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:m.isDev,page:"/api/assets/assetId",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${a} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${a} ${r}`)});n?await g(n):await s.withPropagatedContext(e.headers,()=>s.trace(l.BaseServerSpan.handleRequest,{spanName:`${a} ${r}`,kind:o.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},g))}catch(e){if(m.isDev)throw e;(0,s.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,y,"default",0,g,"handler",()=>p]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__af3c1913._.js.map