module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},30056,e=>e.a(async(t,a)=>{try{let t=await e.y("pg");e.n(t),a()}catch(e){a(e)}},!0),65058,e=>e.a(async(t,a)=>{try{var s=e.i(30056),r=t([s]);[s]=r.then?(await r)():r;let i=new s.Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:!1}});function n(e,t){return i.query(e,t)}e.s(["default",()=>n]),a()}catch(e){a(e)}},!1),31350,e=>e.a(async(t,a)=>{try{var s=e.i(65058),r=t([s]);async function n(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).end(`Method ${e.method} Not Allowed`);try{let e=`
            UPDATE "Asset_Details"
            SET status_id = (
                SELECT id FROM "Status" WHERE status = 'Overdue' LIMIT 1
            )
            WHERE status_id = (
                SELECT id FROM "Status" WHERE status = 'Assigned' LIMIT 1
            )
            AND assigned_to IS NOT NULL
            AND id IN (
                SELECT "assetId" FROM "Asset_Assignments"
                WHERE "expected_return_date" < CURRENT_DATE
            );
        `;await (0,s.default)(e);let a=`
            SELECT
                a.id,
                a.name AS "assetName",
                a."asset_Id" AS "barcode",
                a."serial_no" AS "serialNumber",
                a.location,
                a."purchase_date" AS "purchaseDate",
                a.price,
                a."warranty_expiry" AS "warrantyExpiry",
                cat.category AS "category",
                s.status AS "status",
                u."fullName" AS "assignedBy",
                assignee."fullName" AS "assignedTo",
                
                -- Lateral join ensures we only get the single most recent assignment record
                aa.id AS "assignmentId",
                aa.expected_return_date AS "expectedReturnDate",
                aa."operator_employeeId" AS "operatorId",
                aa."supervisor_employeeId" AS "senderId"

            FROM "Asset_Details" a
            LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
            LEFT JOIN "Status" s ON a.status_id = s.id
            LEFT JOIN "Users" u ON a.assigned_by = u."employeeId"
            LEFT JOIN "Users" assignee ON a.assigned_to = assignee."employeeId"
            
            -- This subquery picks the latest assignment row for each asset
            LEFT JOIN LATERAL (
                SELECT * FROM "Asset_Assignments"
                WHERE "assetId" = a.id
                ORDER BY id DESC
                LIMIT 1
            ) aa ON TRUE

            ORDER BY a.id ASC;
        `,r=(await (0,s.default)(a)).rows.map(e=>({id:e.id,assetName:e.assetName,barcode:e.barcode,serialNumber:e.serialNumber,category:e.category,status:e.status,assignedBy:e.assignedBy||null,assignedTo:e.assignedTo||null,location:e.location,purchaseDate:e.purchaseDate,warrantyExpiry:e.warrantyExpiry,price:e.price,expectedReturnDate:e.expectedReturnDate||null,assignmentId:e.assignmentId||null,operatorId:e.operatorId||null,senderId:e.senderId||null,receiverId:e.operatorId||null}));return t.status(200).json({message:"Assets fetched successfully!",count:r.length,assets:r})}catch(e){return console.error("Get All Assets Error:",e),t.status(500).json({message:"Internal server error."})}}[s]=r.then?(await r)():r,e.s(["default",()=>n]),a()}catch(e){a(e)}},!1),90556,e=>e.a(async(t,a)=>{try{var s=e.i(33534),r=e.i(59016),n=e.i(55334),i=e.i(26175),d=e.i(31350),o=e.i(8322),l=e.i(84914),u=e.i(83666),c=t([d]);[d]=c.then?(await c)():c;let g=(0,i.hoist)(d,"default"),E=(0,i.hoist)(d,"config"),y=new n.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/assets/index",pathname:"/api/assets",bundlePath:"",filename:""},userland:d,distDir:".next",relativeProjectDir:""});async function p(e,t,a){y.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/assets/index";r=r.replace(/\/index$/,"")||"/";let n=await y.prepare(e,t,{srcPage:r});if(!n){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:i,params:d,prerenderManifest:c,routerServerContext:p}=n;try{let a=e.method||"GET",s=(0,o.getTracer)(),n=s.getActiveScopeSpan(),u=y.instrumentationOnRequestError.bind(y),g=async n=>y.render(e,t,{query:{...i,...d},params:d,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:y.isDev,page:"/api/assets/index",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${a} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${a} ${r}`)});n?await g(n):await s.withPropagatedContext(e.headers,()=>s.trace(l.BaseServerSpan.handleRequest,{spanName:`${a} ${r}`,kind:o.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},g))}catch(e){if(y.isDev)throw e;(0,s.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,E,"default",0,g,"handler",()=>p]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__50a38b2f._.js.map