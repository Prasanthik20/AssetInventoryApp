module.exports=[27862,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},92436,a=>{"use strict";let b={src:a.i(27862).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=packages_server_src_app_1e0c6851._.js.map