module.exports=[91930,(a,b,c)=>{}];

//# sourceMappingURL=packages_server__next-internal_server_app__global-error_page_actions_a65a1bf0.js.map