__turbopack_load_page_chunks__("/_error", [
  "static/chunks/aafeea1476204ef7.js",
  "static/chunks/21693af0e5947607.js",
  "static/chunks/turbopack-905a3c054cac85e3.js"
])
