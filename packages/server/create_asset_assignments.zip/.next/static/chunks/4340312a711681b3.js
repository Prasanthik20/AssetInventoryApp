__turbopack_load_page_chunks__("/_app", [
  "static/chunks/58e6ab6abd4b7deb.js",
  "static/chunks/21693af0e5947607.js",
  "static/chunks/turbopack-29e283371d7d0588.js"
])
