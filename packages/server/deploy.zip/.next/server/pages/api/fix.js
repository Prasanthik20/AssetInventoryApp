var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/fix.js")
R.c("server/chunks/[root-of-the-server]__4eef6776._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(91369)
module.exports=R.m(91369).exports
