var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/reports/asset-history.js")
R.c("server/chunks/[root-of-the-server]__0045493d._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(94990)
module.exports=R.m(94990).exports
