var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/reports/asset-history.js")
R.c("server/chunks/[root-of-the-server]__177afdac._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(94990)
module.exports=R.m(94990).exports
