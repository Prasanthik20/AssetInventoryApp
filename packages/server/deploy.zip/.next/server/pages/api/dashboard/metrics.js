var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/dashboard/metrics.js")
R.c("server/chunks/[root-of-the-server]__76fba108._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(70876)
module.exports=R.m(70876).exports
