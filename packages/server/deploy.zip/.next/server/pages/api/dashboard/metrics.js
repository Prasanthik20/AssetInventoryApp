var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/dashboard/metrics.js")
R.c("server/chunks/[root-of-the-server]__0524508f._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(70876)
module.exports=R.m(70876).exports
