var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/reset-password.js")
R.c("server/chunks/[root-of-the-server]__7b7746a2._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(55266)
module.exports=R.m(55266).exports
