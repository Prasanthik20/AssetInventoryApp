var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/login.js")
R.c("server/chunks/[root-of-the-server]__edd4441b._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(41961)
module.exports=R.m(41961).exports
