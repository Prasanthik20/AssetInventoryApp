var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/add-user.js")
R.c("server/chunks/[root-of-the-server]__d043d288._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(96584)
module.exports=R.m(96584).exports
