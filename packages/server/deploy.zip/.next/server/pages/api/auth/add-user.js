var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/add-user.js")
R.c("server/chunks/[root-of-the-server]__e7fa475b._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(96584)
module.exports=R.m(96584).exports
