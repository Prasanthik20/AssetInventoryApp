var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register.js")
R.c("server/chunks/[root-of-the-server]__38431842._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(10591)
module.exports=R.m(10591).exports
