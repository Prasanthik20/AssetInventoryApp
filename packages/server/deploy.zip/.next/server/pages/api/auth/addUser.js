var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/addUser.js")
R.c("server/chunks/[root-of-the-server]__bbee595d._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(22608)
module.exports=R.m(22608).exports
