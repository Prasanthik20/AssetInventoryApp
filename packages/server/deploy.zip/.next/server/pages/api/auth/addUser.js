var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/addUser.js")
R.c("server/chunks/[root-of-the-server]__a690865e._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(22608)
module.exports=R.m(22608).exports
