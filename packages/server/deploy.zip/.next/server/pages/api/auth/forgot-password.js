var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/forgot-password.js")
R.c("server/chunks/[root-of-the-server]__e75376c4._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(782)
module.exports=R.m(782).exports
