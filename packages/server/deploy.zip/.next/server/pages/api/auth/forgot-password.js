var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/forgot-password.js")
R.c("server/chunks/[root-of-the-server]__f5ad8aa9._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(782)
module.exports=R.m(782).exports
