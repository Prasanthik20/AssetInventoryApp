var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/users.js")
R.c("server/chunks/[root-of-the-server]__a17faee8._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(10245)
module.exports=R.m(10245).exports
