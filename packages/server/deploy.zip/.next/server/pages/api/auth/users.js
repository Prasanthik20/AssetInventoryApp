var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/users.js")
R.c("server/chunks/[root-of-the-server]__1ab5fcb7._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(10245)
module.exports=R.m(10245).exports
