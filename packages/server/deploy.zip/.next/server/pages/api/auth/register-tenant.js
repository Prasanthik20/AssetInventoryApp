var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register-tenant.js")
R.c("server/chunks/[root-of-the-server]__302c5352._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(53889)
module.exports=R.m(53889).exports
