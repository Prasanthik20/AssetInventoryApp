var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register-tenant.js")
R.c("server/chunks/[root-of-the-server]__2e533063._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(53889)
module.exports=R.m(53889).exports
