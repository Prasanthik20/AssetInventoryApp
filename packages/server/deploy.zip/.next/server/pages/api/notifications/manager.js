var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/manager.js")
R.c("server/chunks/[root-of-the-server]__0f19b73e._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(51968)
module.exports=R.m(51968).exports
