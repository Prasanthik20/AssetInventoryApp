var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/reply.js")
R.c("server/chunks/[root-of-the-server]__1707c3e6._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(18522)
module.exports=R.m(18522).exports
