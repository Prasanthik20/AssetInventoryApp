var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/reply.js")
R.c("server/chunks/[root-of-the-server]__3b14c024._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(18522)
module.exports=R.m(18522).exports
