var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/supervisor.js")
R.c("server/chunks/[root-of-the-server]__199cbc5d._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(62794)
module.exports=R.m(62794).exports
