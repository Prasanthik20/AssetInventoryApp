var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/supervisor.js")
R.c("server/chunks/[root-of-the-server]__1c32cf26._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(62794)
module.exports=R.m(62794).exports
