var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/admin.js")
R.c("server/chunks/[root-of-the-server]__048fd6c4._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(18273)
module.exports=R.m(18273).exports
