var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/admin.js")
R.c("server/chunks/[root-of-the-server]__085e41bc._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(18273)
module.exports=R.m(18273).exports
