var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/user.js")
R.c("server/chunks/[root-of-the-server]__74ba827e._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(24370)
module.exports=R.m(24370).exports
