var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/operator.js")
R.c("server/chunks/[root-of-the-server]__df8918cb._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(90921)
module.exports=R.m(90921).exports
