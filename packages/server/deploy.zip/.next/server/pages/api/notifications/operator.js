var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/operator.js")
R.c("server/chunks/[root-of-the-server]__7661812e._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(90921)
module.exports=R.m(90921).exports
