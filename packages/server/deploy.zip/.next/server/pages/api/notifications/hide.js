var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/hide.js")
R.c("server/chunks/[root-of-the-server]__60f39a7e._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(17309)
module.exports=R.m(17309).exports
