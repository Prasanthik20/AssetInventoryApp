var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/hide.js")
R.c("server/chunks/[root-of-the-server]__34713f1d._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(17309)
module.exports=R.m(17309).exports
