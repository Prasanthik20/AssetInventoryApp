var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/[id].js")
R.c("server/chunks/[root-of-the-server]__b46ed4f5._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(43366)
module.exports=R.m(43366).exports
