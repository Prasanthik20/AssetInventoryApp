var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/[id].js")
R.c("server/chunks/[root-of-the-server]__0c48704f._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(43366)
module.exports=R.m(43366).exports
