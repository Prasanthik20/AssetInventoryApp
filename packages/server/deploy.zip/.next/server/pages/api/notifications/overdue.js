var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/overdue.js")
R.c("server/chunks/[root-of-the-server]__edf197ba._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(17823)
module.exports=R.m(17823).exports
