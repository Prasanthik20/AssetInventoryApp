var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/overdue.js")
R.c("server/chunks/[root-of-the-server]__9b61da12._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(17823)
module.exports=R.m(17823).exports
