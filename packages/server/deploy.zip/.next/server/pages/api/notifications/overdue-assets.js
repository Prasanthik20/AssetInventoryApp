var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/overdue-assets.js")
R.c("server/chunks/[root-of-the-server]__1a54b020._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(70221)
module.exports=R.m(70221).exports
