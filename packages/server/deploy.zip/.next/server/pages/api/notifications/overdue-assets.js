var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications/overdue-assets.js")
R.c("server/chunks/[root-of-the-server]__c1a64ed6._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(70221)
module.exports=R.m(70221).exports
