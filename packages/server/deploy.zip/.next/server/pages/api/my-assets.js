var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/my-assets.js")
R.c("server/chunks/[root-of-the-server]__df2f9081._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(35746)
module.exports=R.m(35746).exports
