var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/categories.js")
R.c("server/chunks/[root-of-the-server]__72e3af54._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(95763)
module.exports=R.m(95763).exports
