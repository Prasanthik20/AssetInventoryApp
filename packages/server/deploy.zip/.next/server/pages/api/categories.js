var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/categories.js")
R.c("server/chunks/[root-of-the-server]__56c14319._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(95763)
module.exports=R.m(95763).exports
