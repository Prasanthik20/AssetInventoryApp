var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/managed-assets.js")
R.c("server/chunks/[root-of-the-server]__784432de._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(26526)
module.exports=R.m(26526).exports
