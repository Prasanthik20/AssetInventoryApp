var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/approvals/request.js")
R.c("server/chunks/[root-of-the-server]__7a932e01._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(51141)
module.exports=R.m(51141).exports
