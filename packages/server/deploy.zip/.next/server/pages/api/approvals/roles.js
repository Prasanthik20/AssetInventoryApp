var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/approvals/roles.js")
R.c("server/chunks/[root-of-the-server]__a8993887._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(51683)
module.exports=R.m(51683).exports
