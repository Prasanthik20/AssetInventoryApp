var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/approvals/action.js")
R.c("server/chunks/[root-of-the-server]__4ce41a1b._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(41860)
module.exports=R.m(41860).exports
