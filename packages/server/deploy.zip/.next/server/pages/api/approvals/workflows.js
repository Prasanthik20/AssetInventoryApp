var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/approvals/workflows.js")
R.c("server/chunks/[root-of-the-server]__55ce7c54._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(53059)
module.exports=R.m(53059).exports
