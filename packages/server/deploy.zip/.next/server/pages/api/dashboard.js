var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/dashboard.js")
R.c("server/chunks/[root-of-the-server]__cb4aacb3._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(93960)
module.exports=R.m(93960).exports
