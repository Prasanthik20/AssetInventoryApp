var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/dashboard.js")
R.c("server/chunks/[root-of-the-server]__5a2cf3d0._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(93960)
module.exports=R.m(93960).exports
