var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/test-db.js")
R.c("server/chunks/[root-of-the-server]__ed880393._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(653)
module.exports=R.m(653).exports
