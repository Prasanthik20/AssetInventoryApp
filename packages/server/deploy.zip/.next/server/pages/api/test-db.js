var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/test-db.js")
R.c("server/chunks/[root-of-the-server]__ced1a56c._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(653)
module.exports=R.m(653).exports
