var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/superadmin/plans.js")
R.c("server/chunks/[root-of-the-server]__0cfc7a7d._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(63188)
module.exports=R.m(63188).exports
