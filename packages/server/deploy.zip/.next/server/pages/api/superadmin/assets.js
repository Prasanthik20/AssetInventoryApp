var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/superadmin/assets.js")
R.c("server/chunks/[root-of-the-server]__84595a26._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(89904)
module.exports=R.m(89904).exports
