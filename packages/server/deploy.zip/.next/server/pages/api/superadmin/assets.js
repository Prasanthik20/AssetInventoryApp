var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/superadmin/assets.js")
R.c("server/chunks/[root-of-the-server]__73ca934a._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(89904)
module.exports=R.m(89904).exports
