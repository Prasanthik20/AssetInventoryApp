var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/superadmin/stats.js")
R.c("server/chunks/[root-of-the-server]__79b6333c._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(54071)
module.exports=R.m(54071).exports
