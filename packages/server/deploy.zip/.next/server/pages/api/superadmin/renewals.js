var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/superadmin/renewals.js")
R.c("server/chunks/[root-of-the-server]__763c3e60._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(32851)
module.exports=R.m(32851).exports
