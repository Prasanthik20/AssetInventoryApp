var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/superadmin/renewals.js")
R.c("server/chunks/[root-of-the-server]__74185008._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(32851)
module.exports=R.m(32851).exports
