var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/superadmin/tenants.js")
R.c("server/chunks/[root-of-the-server]__7dab13b6._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(39732)
module.exports=R.m(39732).exports
