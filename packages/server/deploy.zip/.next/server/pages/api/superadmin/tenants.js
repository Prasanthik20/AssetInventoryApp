var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/superadmin/tenants.js")
R.c("server/chunks/[root-of-the-server]__9d768787._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(39732)
module.exports=R.m(39732).exports
