var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/subscription/renew.js")
R.c("server/chunks/[root-of-the-server]__441b3509._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(95850)
module.exports=R.m(95850).exports
