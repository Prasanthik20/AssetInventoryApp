var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/subscription/renew.js")
R.c("server/chunks/[root-of-the-server]__d65aeb61._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(95850)
module.exports=R.m(95850).exports
