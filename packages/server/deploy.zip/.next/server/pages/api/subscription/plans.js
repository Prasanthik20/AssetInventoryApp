var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/subscription/plans.js")
R.c("server/chunks/[root-of-the-server]__608ceb01._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(58667)
module.exports=R.m(58667).exports
