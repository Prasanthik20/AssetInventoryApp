var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/subscription/plans.js")
R.c("server/chunks/[root-of-the-server]__09975179._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(58667)
module.exports=R.m(58667).exports
