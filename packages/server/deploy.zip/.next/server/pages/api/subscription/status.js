var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/subscription/status.js")
R.c("server/chunks/[root-of-the-server]__a6a8f46a._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(98447)
module.exports=R.m(98447).exports
