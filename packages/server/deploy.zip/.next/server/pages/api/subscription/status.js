var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/subscription/status.js")
R.c("server/chunks/[root-of-the-server]__a2f813c3._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(98447)
module.exports=R.m(98447).exports
