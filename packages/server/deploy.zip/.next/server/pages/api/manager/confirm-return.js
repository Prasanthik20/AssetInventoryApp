var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/manager/confirm-return.js")
R.c("server/chunks/[root-of-the-server]__61e4ac08._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(24613)
module.exports=R.m(24613).exports
