var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/user/return-asset.js")
R.c("server/chunks/[root-of-the-server]__7dfd957e._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(63421)
module.exports=R.m(63421).exports
