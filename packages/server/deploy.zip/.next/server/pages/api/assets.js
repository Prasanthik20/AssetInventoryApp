var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/assets.js")
R.c("server/chunks/[root-of-the-server]__9ac496ee._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(90556)
module.exports=R.m(90556).exports
