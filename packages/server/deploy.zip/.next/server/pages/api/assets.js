var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/assets.js")
R.c("server/chunks/[root-of-the-server]__b672da7a._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(90556)
module.exports=R.m(90556).exports
