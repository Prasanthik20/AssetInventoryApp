var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications.js")
R.c("server/chunks/[root-of-the-server]__fb506d09._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(25229)
module.exports=R.m(25229).exports
