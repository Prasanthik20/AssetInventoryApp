var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/notifications.js")
R.c("server/chunks/[root-of-the-server]__4fb19984._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(25229)
module.exports=R.m(25229).exports
