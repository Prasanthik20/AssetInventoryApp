var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/statuses.js")
R.c("server/chunks/[root-of-the-server]__db7e3199._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(53977)
module.exports=R.m(53977).exports
