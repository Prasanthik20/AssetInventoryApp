var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/statuses.js")
R.c("server/chunks/[root-of-the-server]__c41ad326._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(53977)
module.exports=R.m(53977).exports
