var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/test.js")
R.c("server/chunks/[root-of-the-server]__8306e538._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(2625)
module.exports=R.m(2625).exports
