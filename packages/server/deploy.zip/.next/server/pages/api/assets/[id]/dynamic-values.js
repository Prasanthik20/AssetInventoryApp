var R=require("../../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/[id]/dynamic-values.js")
R.c("server/chunks/[root-of-the-server]__1852b4b8._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(93856)
module.exports=R.m(93856).exports
