var R=require("../../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/[id]/dynamic-values.js")
R.c("server/chunks/[root-of-the-server]__7a2305bb._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(93856)
module.exports=R.m(93856).exports
