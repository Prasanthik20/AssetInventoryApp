var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/extend-return-date.js")
R.c("server/chunks/[root-of-the-server]__88606e51._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(34348)
module.exports=R.m(34348).exports
