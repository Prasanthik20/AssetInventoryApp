var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/extend-return-date.js")
R.c("server/chunks/[root-of-the-server]__919343fb._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(34348)
module.exports=R.m(34348).exports
