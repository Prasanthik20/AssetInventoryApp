var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/create.js")
R.c("server/chunks/[root-of-the-server]__650dd4ab._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(41744)
module.exports=R.m(41744).exports
