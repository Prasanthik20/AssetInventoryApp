var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/create.js")
R.c("server/chunks/[root-of-the-server]__db5e1488._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(41744)
module.exports=R.m(41744).exports
