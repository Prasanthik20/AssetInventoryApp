var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/assign.js")
R.c("server/chunks/[root-of-the-server]__a18a5c1a._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(45151)
module.exports=R.m(45151).exports
