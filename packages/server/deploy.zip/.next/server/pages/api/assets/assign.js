var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/assign.js")
R.c("server/chunks/[root-of-the-server]__edc6e1aa._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.c("server/chunks/791b8_next_dist_esm_build_templates_pages-api_75059053.js")
R.m(45151)
module.exports=R.m(45151).exports
