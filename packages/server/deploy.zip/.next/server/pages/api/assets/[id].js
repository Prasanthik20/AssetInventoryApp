var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/[id].js")
R.c("server/chunks/[root-of-the-server]__1dc56ec1._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(59679)
module.exports=R.m(59679).exports
