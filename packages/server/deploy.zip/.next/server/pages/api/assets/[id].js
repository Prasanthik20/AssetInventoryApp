var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/[id].js")
R.c("server/chunks/[root-of-the-server]__264bbef3._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(59679)
module.exports=R.m(59679).exports
