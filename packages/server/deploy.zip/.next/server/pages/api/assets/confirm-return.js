var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/confirm-return.js")
R.c("server/chunks/[root-of-the-server]__69a5a8d3._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(59923)
module.exports=R.m(59923).exports
