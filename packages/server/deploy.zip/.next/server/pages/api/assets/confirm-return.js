var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/assets/confirm-return.js")
R.c("server/chunks/[root-of-the-server]__e851b05d._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(59923)
module.exports=R.m(59923).exports
