var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/operator/assets.js")
R.c("server/chunks/[root-of-the-server]__bd0112e5._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(41504)
module.exports=R.m(41504).exports
