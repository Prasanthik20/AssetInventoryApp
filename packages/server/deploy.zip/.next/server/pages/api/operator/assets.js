var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/operator/assets.js")
R.c("server/chunks/[root-of-the-server]__b58ef2b9._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(41504)
module.exports=R.m(41504).exports
