var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/operator/returnAsset.js")
R.c("server/chunks/[root-of-the-server]__9c9068b1._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(82894)
module.exports=R.m(82894).exports
