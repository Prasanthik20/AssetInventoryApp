var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/operator/returnAsset.js")
R.c("server/chunks/[root-of-the-server]__149deb88._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(82894)
module.exports=R.m(82894).exports
