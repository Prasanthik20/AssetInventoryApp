var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/supervisor/returnAsset.js")
R.c("server/chunks/[root-of-the-server]__ca33774e._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(18451)
module.exports=R.m(18451).exports
