var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/supervisor/returnAsset.js")
R.c("server/chunks/[root-of-the-server]__f3e798c9._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(18451)
module.exports=R.m(18451).exports
