var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/supervisor/assets.js")
R.c("server/chunks/[root-of-the-server]__14e7b695._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(17318)
module.exports=R.m(17318).exports
