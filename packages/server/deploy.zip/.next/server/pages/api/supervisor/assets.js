var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/supervisor/assets.js")
R.c("server/chunks/[root-of-the-server]__d261436b._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(17318)
module.exports=R.m(17318).exports
