var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/test-db2.js")
R.c("server/chunks/[root-of-the-server]__b755f40a._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(14648)
module.exports=R.m(14648).exports
