var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/test-db2.js")
R.c("server/chunks/[root-of-the-server]__2bb37e86._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(14648)
module.exports=R.m(14648).exports
