var R=require("../../../../chunks/[turbopack]_runtime.js")("server/pages/api/categories/[categoryId]/fields.js")
R.c("server/chunks/[root-of-the-server]__b37dba8d._.js")
R.c("server/chunks/[root-of-the-server]__c909443a._.js")
R.m(2963)
module.exports=R.m(2963).exports
