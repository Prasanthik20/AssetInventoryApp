var R=require("../../../../chunks/[turbopack]_runtime.js")("server/pages/api/categories/[categoryId]/fields.js")
R.c("server/chunks/[root-of-the-server]__11a659a6._.js")
R.c("server/chunks/[root-of-the-server]__feb594b4._.js")
R.m(2963)
module.exports=R.m(2963).exports
