module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,s)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let s=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,s,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,s)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),s=e.i(74606),r=e.i(65058);let a=e=>async(r,a)=>{let i=r.headers.origin;if((0,s.setCorsHeaders)(a,i),"OPTIONS"===r.method)return void a.status(200).end();let n=r.headers.authorization;if(!n||!n.startsWith("Bearer "))return a.status(401).json({message:"Authorization token missing or invalid."});let o=n.split(" ")[1],l=(0,t.verifyToken)(o);return l?(r.user=l,e(r,a)):a.status(401).json({message:"Invalid or expired token."})};e.s(["withAuth",0,a,"withPermission",0,(e,t)=>a(async(s,a)=>{let{userId:i,tenantId:n,role:o}=s.user;if("Super Admin"===o||"SuperAdmin"===o)return t(s,a);try{let o=await (0,r.default)(`SELECT 1 
         FROM "Users" u
         INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
         INNER JOIN "Permissions" p ON rp."permissionId" = p.id
         WHERE u."userId" = $1 AND p.code = $2 AND (u."tenantId" = $3 OR u."tenantId" IS NULL)
         LIMIT 1`,[i,e,n||null]);if(0===o.rows.length)return a.status(403).json({message:`Forbidden: Missing required permission ${e}`});return t(s,a)}catch(e){return console.error("Permission check error:",e),a.status(500).json({message:"Internal server error during authorization."})}})])},89904,e=>{"use strict";var t=e.i(33534),s=e.i(59016),r=e.i(55334),a=e.i(26175),i=e.i(65058);async function n(e,t){if("Super Admin"!==e.user.role)return t.status(403).json({message:"Access denied. Super Admin privileges required."});if("GET"===e.method)try{let{tenantId:s,status:r}=e.query,a=[],n=[];s&&"all"!==s&&(a.push(s),n.push(`a."tenantId" = $${a.length}`)),r&&"all"!==r&&(a.push(r),n.push(`st.status LIKE $${a.length}`));try{await (0,i.default)(`
          IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Asset_Details' AND COLUMN_NAME = 'useful_life')
          BEGIN
              ALTER TABLE "Asset_Details" ADD "useful_life" INT DEFAULT 5;
          END
          
          IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Asset_Details' AND COLUMN_NAME = 'salvage_value')
          BEGIN
              ALTER TABLE "Asset_Details" ADD "salvage_value" VARCHAR(255);
          END
        `,[])}catch(e){console.error("[AUTO-MIGRATION ERROR in superadmin assets]",e)}let o=n.length>0?`WHERE ${n.join(" AND ")}`:"",l=`
        SELECT TOP 1000
          a.id,
          a.name,
          a.serial_no AS "serialNo",
          a."asset_Id" AS "assetId",
          st.status,
          a.location,
          a.useful_life AS "usefulLife",
          a.salvage_value AS "salvageValue",
          t.name AS "tenantName"
        FROM 
          "Asset_Details" a
        JOIN 
          "Tenants" t ON a."tenantId" = t.id
        LEFT JOIN
          "Status" st ON a."status_id" = st.id
        ${o}
        ORDER BY a.id DESC;
      `,u=await (0,i.default)(l,a);return t.status(200).json({count:u.rows.length,assets:u.rows})}catch(e){return console.error("Super Admin Fetch Assets Error:",e),t.status(500).json({message:"An internal server error occurred."})}return t.setHeader("Allow",["GET"]),t.status(405).json({message:`Method ${e.method} Not Allowed`})}let o=(0,e.i(19477).withAuth)(n);e.s(["default",0,o],58078);var l=e.i(58078),u=e.i(8322),d=e.i(84914),p=e.i(83666);let c=(0,a.hoist)(l,"default"),h=(0,a.hoist)(l,"config"),A=new r.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/superadmin/assets",pathname:"/api/superadmin/assets",bundlePath:"",filename:""},userland:l,distDir:".next",relativeProjectDir:""});async function E(e,s,r){A.isDev&&(0,p.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/superadmin/assets";a=a.replace(/\/index$/,"")||"/";let i=await A.prepare(e,s,{srcPage:a});if(!i){s.statusCode=400,s.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:n,params:o,prerenderManifest:l,routerServerContext:c}=i;try{let t=e.method||"GET",r=(0,u.getTracer)(),i=r.getActiveScopeSpan(),p=A.instrumentationOnRequestError.bind(A),h=async i=>A.render(e,s,{query:{...n,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:l.preview,propagateError:!1,dev:A.isDev,page:"/api/superadmin/assets",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>p(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${t} ${a}`)});i?await h(i):await r.withPropagatedContext(e.headers,()=>r.trace(d.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:u.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},h))}catch(e){if(A.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,h,"default",0,c,"handler",()=>E],89904)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__84595a26._.js.map