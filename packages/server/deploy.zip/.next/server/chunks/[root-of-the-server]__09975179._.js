module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,s)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let s=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,s,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,s)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),s=e.i(74606),r=e.i(65058);let a=e=>async(r,a)=>{let i=r.headers.origin;if((0,s.setCorsHeaders)(a,i),"OPTIONS"===r.method)return void a.status(200).end();let n=r.headers.authorization;if(!n||!n.startsWith("Bearer "))return a.status(401).json({message:"Authorization token missing or invalid."});let o=n.split(" ")[1],u=(0,t.verifyToken)(o);return u?(r.user=u,e(r,a)):a.status(401).json({message:"Invalid or expired token."})};e.s(["withAuth",0,a,"withPermission",0,(e,t)=>a(async(s,a)=>{let{userId:i,tenantId:n,role:o}=s.user;if("Super Admin"===o||"SuperAdmin"===o)return t(s,a);try{let o=await (0,r.default)(`SELECT 1 
         FROM "Users" u
         INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
         INNER JOIN "Permissions" p ON rp."permissionId" = p.id
         WHERE u."userId" = $1 AND p.code = $2 AND (u."tenantId" = $3 OR u."tenantId" IS NULL)
         LIMIT 1`,[i,e,n||null]);if(0===o.rows.length)return a.status(403).json({message:`Forbidden: Missing required permission ${e}`});return t(s,a)}catch(e){return console.error("Permission check error:",e),a.status(500).json({message:"Internal server error during authorization."})}})])},38503,e=>{"use strict";var t=e.i(65058),s=e.i(19477);let r=!1;async function a(){if(!r)try{await (0,t.default)(`
      IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Plans' AND COLUMN_NAME = 'min_users')
      BEGIN
          ALTER TABLE "Plans" ADD "min_users" INT DEFAULT 1;
      END

      IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Plans' AND COLUMN_NAME = 'min_assets')
      BEGIN
          ALTER TABLE "Plans" ADD "min_assets" INT DEFAULT 1;
      END
    `);let e=`
      MERGE INTO "Plans" AS target
      USING (VALUES 
        ('free-trial', 'Free Trial', 1, 5, 1, 100, 0.00, 'INR', '{"qrCode": false, "reports": "basic", "storage": "2GB", "support": "email", "apiAccess": false, "dashboard": "basic", "trialDays": 30, "customCategories": false}', '2026-05-14T02:36:33.002Z'),
        ('starter', 'Starter', 6, 25, 101, 2500, 4999.00, 'INR', '{"qrCode": true, "reports": "standard", "storage": "25GB", "support": "email", "apiAccess": false, "yearlyPrice": 59988, "customCategories": false, "emailNotifications": true}', '2026-05-14T02:36:33.002Z'),
        ('professional', 'Professional', 26, 100, 2501, 25000, 14999.00, 'INR', '{"qrCode": true, "reports": "advanced", "storage": "100GB", "support": "priority", "apiAccess": true, "auditLogs": true, "yearlyPrice": 179988, "dynamicFields": true, "roleManagement": true, "customCategories": true, "emailNotifications": true}', '2026-05-14T02:36:33.002Z'),
        ('enterprise', 'Enterprise Plan', 101, 999999, 25001, 999999, -1.00, 'INR', '{"sla": true, "sso": true, "qrCode": true, "reports": "advanced", "storage": "Unlimited", "support": "dedicated", "apiAccess": true, "auditLogs": true, "dedicatedDB": true, "multiBranch": true, "customPricing": true, "dynamicFields": true, "whiteLabeling": true, "roleManagement": true, "customCategories": true, "customIntegrations": true, "emailNotifications": true}', '2026-05-14T02:18:07.300Z'),
        ('enterprise-demo', 'Enterprise (Demo)', 1, 999, 1, 999999, 0.00, 'INR', NULL, '2026-06-13T00:26:34.959Z')
      ) AS source (id, name, min_users, maxUsers, min_assets, maxAssets, price, currency, features, createdAt)
      ON target.id = source.id
      WHEN MATCHED THEN
        UPDATE SET 
          name = source.name,
          min_users = source.min_users,
          "maxUsers" = source.maxUsers,
          min_assets = source.min_assets,
          "maxAssets" = source.maxAssets,
          price = source.price,
          currency = source.currency,
          features = source.features
      WHEN NOT MATCHED THEN
        INSERT (id, name, min_users, "maxUsers", min_assets, "maxAssets", price, currency, features, "createdAt")
        VALUES (source.id, source.name, source.min_users, source.maxUsers, source.min_assets, source.maxAssets, source.price, source.currency, source.features, source.createdAt);
    `;await (0,t.default)(e),r=!0,console.log("SQL Server plans schema auto-migration and seeding succeeded.")}catch(e){console.error("ensureDatabaseSchema plans migration error:",e)}}async function i(e,s){if(await a(),"GET"===e.method){if(!["Super Admin","Tenant Admin","Admin"].includes(e.user.role))return s.status(403).json({message:"Access denied. Privileged role required to view plans."})}else if("Super Admin"!==e.user.role)return s.status(403).json({message:"Access denied. Super Admin privileges required."});if("GET"===e.method)try{let e=await (0,t.default)('SELECT * FROM "Plans" ORDER BY price ASC');return s.status(200).json({count:e.rows.length,plans:e.rows})}catch(e){return console.error("Fetch Plans Error:",e),s.status(500).json({message:"An internal server error occurred."})}if("POST"===e.method){let{id:r,name:a,minUsers:i,maxUsers:n,minAssets:o,maxAssets:u,price:l,currency:d,features:c}=e.body;if(!r||!a||void 0===n||void 0===u||void 0===l)return s.status(400).json({message:"Plan Identifier (id), name, maximum users, maximum assets, and price are required."});try{let e=`
        MERGE INTO "Plans" AS target
        USING (SELECT $1 AS id) AS source
        ON target.id = source.id
        WHEN MATCHED THEN
          UPDATE SET
            name = $2,
            min_users = $3,
            "maxUsers" = $4,
            min_assets = $5,
            "maxAssets" = $6,
            price = $7,
            currency = $8,
            features = $9
        WHEN NOT MATCHED THEN
          INSERT (id, name, min_users, "maxUsers", min_assets, "maxAssets", price, currency, features, "createdAt")
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, GETDATE())
        OUTPUT INSERTED.*;
      `,p=[r.toLowerCase().trim().replace(/\s+/g,"-"),a.trim(),parseInt(void 0!==i?i:1,10),parseInt(n,10),parseInt(void 0!==o?o:1,10),parseInt(u,10),parseFloat(l),d||"INR",JSON.stringify(c||{})],m=await (0,t.default)(e,p);return s.status(200).json({success:!0,message:`Plan "${a}" has been successfully added/updated in the catalog.`,plan:m.rows[0]})}catch(e){return console.error("Super Admin Save Plan Error:",e),s.status(500).json({message:"An internal server error occurred during plan saving."})}}return s.setHeader("Allow",["GET","POST"]),s.status(405).json({message:`Method ${e.method} Not Allowed`})}let n=(0,s.withAuth)(i);e.s(["default",0,n])},58667,e=>{"use strict";var t=e.i(33534),s=e.i(59016),r=e.i(55334),a=e.i(26175);let i=e.i(38503).default;e.s(["default",0,i],12826);var n=e.i(12826),o=e.i(8322),u=e.i(84914),l=e.i(83666);let d=(0,a.hoist)(n,"default"),c=(0,a.hoist)(n,"config"),p=new r.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/subscription/plans",pathname:"/api/subscription/plans",bundlePath:"",filename:""},userland:n,distDir:".next",relativeProjectDir:""});async function m(e,s,r){p.isDev&&(0,l.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/subscription/plans";a=a.replace(/\/index$/,"")||"/";let i=await p.prepare(e,s,{srcPage:a});if(!i){s.statusCode=400,s.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:n,params:d,prerenderManifest:c,routerServerContext:m}=i;try{let t=e.method||"GET",r=(0,o.getTracer)(),i=r.getActiveScopeSpan(),l=p.instrumentationOnRequestError.bind(p),E=async i=>p.render(e,s,{query:{...n,...d},params:d,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:p.isDev,page:"/api/subscription/plans",internalRevalidate:null==m?void 0:m.revalidate,onError:(...t)=>l(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${t} ${a}`)});i?await E(i):await r.withPropagatedContext(e.headers,()=>r.trace(u.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:o.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},E))}catch(e){if(p.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,c,"default",0,d,"handler",()=>m],58667)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__09975179._.js.map