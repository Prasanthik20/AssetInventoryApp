module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let a=t||"";a.endsWith("/")&&(a=a.slice(0,-1)),a&&(a.includes("localhost")||a.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(a))&&(e.setHeader("Access-Control-Allow-Origin",a),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},45532,e=>{"use strict";var t=e.i(65058),a=e.i(74606);async function s(e,s){let r=e.headers.origin;if((0,a.setCorsHeaders)(s,r),"OPTIONS"===e.method)return void s.status(200).end();if("GET"!==e.method)return s.setHeader("Allow",["GET","OPTIONS"]),s.status(405).json({message:`Method ${e.method} not allowed`});try{let a=Number(e.query.id||e.query.managerId||e.query.supervisorId);if(!Number.isFinite(a))return s.status(400).json({message:"Manager employee id is required"});let r=(await (0,t.default)(`SELECT
        a.id,
        a.name AS "assetName",
        a."asset_Id" AS "barcode",
        a."serial_no" AS "serialNumber",
        a.location,
        s.status AS "status",
        a."photoURL" AS "photoURL",
        a."barcodeURL" AS "barcodeURL",
        a."purchase_date" AS "purchaseDate",
        a."warranty_expiry" AS "warrantyExpiry",
        a.price,
        a.useful_life AS "usefulLife",
        a.salvage_value AS "salvageValue",
        a."categoryId" AS "categoryId",
        a."controller_key" AS "controllerKey",
        cat.category AS "category",
        assignee."fullName" AS "assignedTo",
        assigner."fullName" AS "assignedBy",
        aa.id AS "assignmentId",
        aa."projectName" AS "projectName",
        aa.assigned_date AS "assignedDate",
        aa.expected_return_date AS "expectedReturnDate",
        aa."operator_employeeId" AS "operatorId",
        aa."supervisor_employeeId" AS "senderId"
      FROM "Asset_Details" a
      LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
      LEFT JOIN "Status" s ON s.id = a.status_id
      LEFT JOIN "Users" assignee ON assignee."employeeId" = a.assigned_to AND (assignee."tenantId" = a."tenantId" OR a."tenantId" IS NULL)
      LEFT JOIN "Users" assigner ON assigner."employeeId" = a.assigned_by AND (assigner."tenantId" = a."tenantId" OR a."tenantId" IS NULL)
      OUTER APPLY (
        SELECT TOP 1 * FROM "Asset_Assignments"
        WHERE "assetId" = a.id
          AND COALESCE(status, '') <> 'returned'
          AND "returned_date" IS NULL
        ORDER BY id DESC
      ) aa
      WHERE (
        CAST(a.assigned_to AS text) = CAST($1 AS text)
        OR CAST(aa."operator_employeeId" AS text) = CAST($1 AS text)
        OR CAST(a.assigned_by AS text) = CAST($1 AS text)
        OR CAST(aa."supervisor_employeeId" AS text) = CAST($1 AS text)
      )
      AND (
        a."tenantId" = (SELECT "tenantId" FROM "Users" WHERE CAST("employeeId" AS text) = CAST($1 AS text) LIMIT 1)
        OR a."tenantId" IS NULL
      )
        AND LOWER(COALESCE(s.status, '')) IN ('assigned', 'overdue')
      ORDER BY a.id ASC`,[a])).rows.map(e=>{let t=parseFloat(e.price)||0,a=parseFloat(e.salvageValue)||0,s=parseInt(e.usefulLife)||5,r=t,n=100,i=0,o=null;if(t>0&&s>0&&e.purchaseDate){let d=new Date(e.purchaseDate),l=new Date,u=Math.max(0,(l.getTime()-d.getTime())/315576e5),p=Math.max(0,Math.min((t-a)/s*u,t-a));r=t-p,i=u/s*100,i=Math.min(100,i),(n=Math.max(0,100-i))<60&&(o=`Depreciation alert: remaining life is ${n.toFixed(1)}%. Please scrap or upgrade this asset.`)}return{id:e.id.toString(),assetId:Number(e.id),assetName:e.assetName,barcode:e.barcode,controllerKey:e.controllerKey||null,serialNumber:e.serialNumber,category:e.category||null,categoryId:e.categoryId?Number(e.categoryId):null,status:e.status,assignedTo:e.assignedTo,assignedBy:e.assignedBy,location:e.location&&"unassigned"!==String(e.location).trim().toLowerCase()&&"null"!==String(e.location).trim().toLowerCase()?String(e.location).trim():"Office",purchaseDate:e.purchaseDate,warrantyExpiry:e.warrantyExpiry,price:e.price,photoURL:e.photoURL||"",barcodeURL:e.barcodeURL||null,expectedReturnDate:e.expectedReturnDate||null,assignedDate:e.assignedDate||null,projectName:e.projectName||null,assignmentId:e.assignmentId?e.assignmentId.toString():null,operatorId:e.operatorId?e.operatorId.toString():null,senderId:e.senderId?e.senderId.toString():null,receiverId:e.operatorId?e.operatorId.toString():null,isOverdue:"overdue"===String(e.status||"").toLowerCase(),usefulLife:s,salvageValue:e.salvageValue||null,remainingValue:parseFloat(r.toFixed(2)),depreciationMessage:o}});return s.status(200).json({assets:r,count:r.length})}catch(e){return console.error("Managed assets API error:",e),s.status(500).json({message:"Internal server error"})}}e.s(["default",()=>s])},17318,e=>{"use strict";var t=e.i(33534),a=e.i(59016),s=e.i(55334),r=e.i(26175);let n=e.i(45532).default;e.s(["default",0,n],42287);var i=e.i(42287),o=e.i(8322),d=e.i(84914),l=e.i(83666);let u=(0,r.hoist)(i,"default"),p=(0,r.hoist)(i,"config"),c=new s.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/supervisor/assets",pathname:"/api/supervisor/assets",bundlePath:"",filename:""},userland:i,distDir:".next",relativeProjectDir:""});async function g(e,a,s){c.isDev&&(0,l.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/supervisor/assets";r=r.replace(/\/index$/,"")||"/";let n=await c.prepare(e,a,{srcPage:r});if(!n){a.statusCode=400,a.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:i,params:u,prerenderManifest:p,routerServerContext:g}=n;try{let t=e.method||"GET",s=(0,o.getTracer)(),n=s.getActiveScopeSpan(),l=c.instrumentationOnRequestError.bind(c),S=async n=>c.render(e,a,{query:{...i,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:c.isDev,page:"/api/supervisor/assets",internalRevalidate:null==g?void 0:g.revalidate,onError:(...t)=>l(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${t} ${r}`)});n?await S(n):await s.withPropagatedContext(e.headers,()=>s.trace(d.BaseServerSpan.handleRequest,{spanName:`${t} ${r}`,kind:o.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},S))}catch(e){if(c.isDev)throw e;(0,t.sendError)(a,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,p,"default",0,u,"handler",()=>g],17318)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__14e7b695._.js.map