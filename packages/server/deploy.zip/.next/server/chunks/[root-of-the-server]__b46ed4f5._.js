module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},43366,e=>{"use strict";var t=e.i(33534),s=e.i(59016),a=e.i(55334),n=e.i(26175),i=e.i(65058),r=e.i(74606);async function o(e,t){let s=e.headers.origin;if((0,r.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();if("GET"!==e.method)return t.setHeader("Allow",["GET","OPTIONS"]),t.status(405).end(`Method ${e.method} Not Allowed`);try{let s=new URL(e.url||"","http://localhost").searchParams.get("id"),a=e.query.id,n=["admin","supervisor","operator","tenant admin","tenantadmin"].includes(a?.toLowerCase()),r=e.query.role||(n?a.toLowerCase():null),o=s||(n?null:a);if(!o)return t.status(400).json({message:"Valid numeric receiver ID is required."});let d=parseInt(o,10);if(isNaN(d))return t.status(400).json({message:"Valid numeric receiver ID is required."});let l="",u="",c=[];"operator"===r&&(u="AND n.reply IS NULL"),console.log(r),"admin"===r||"tenant admin"===r||"tenantadmin"===r?(l=`
        SELECT
          n.id AS "notificationId",
          n."assignmentId",
          n.reason,
          n.reply,
          n.status AS "notificationStatus",
          n.created_at AS "createdAt",

          a.id AS "assetId",
          a.name AS "assetName",

          s."employeeId" AS "senderEmployeeId",
          s."fullName" AS "senderName"
        FROM "Notifications" n
        LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
        LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
        ORDER BY n.created_at DESC;
      `,c=[]):(l=`
        SELECT
          n.id AS "notificationId",
          n."assignmentId",
          n.reason,
          n.reply,
          n.status AS "notificationStatus",
          n.created_at AS "createdAt",

          a.id AS "assetId",
          a.name AS "assetName",

          s."employeeId" AS "senderEmployeeId",
          s."fullName" AS "senderName"
        FROM "Notifications" n
        LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
        LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
        WHERE n."receiverId" = $1
        ${u}
        ORDER BY n.created_at DESC;
      `,c=[d]);let p=await (0,i.default)(l,c);console.log(p);let m=p.rows.map(e=>({id:e.notificationId,notificationId:e.notificationId,assignmentId:e.assignmentId,reason:e.reason,reply:e.reply,status:e.notificationStatus,createdAt:e.createdAt,asset:{id:e.assetId,name:e.assetName},sender:{employeeId:e.senderEmployeeId,name:e.senderName}}));return t.status(200).json({count:m.length,notifications:m})}catch(e){return console.error("GET /notifications/[id] error:",e),t.status(500).json({message:"Internal server error"})}}e.s(["default",()=>o],27677);var d=e.i(27677),l=e.i(8322),u=e.i(84914),c=e.i(83666);let p=(0,n.hoist)(d,"default"),m=(0,n.hoist)(d,"config"),h=new a.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/notifications/[id]",pathname:"/api/notifications/[id]",bundlePath:"",filename:""},userland:d,distDir:".next",relativeProjectDir:""});async function f(e,s,a){h.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/notifications/[id]";n=n.replace(/\/index$/,"")||"/";let i=await h.prepare(e,s,{srcPage:n});if(!i){s.statusCode=400,s.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:r,params:o,prerenderManifest:d,routerServerContext:p}=i;try{let t=e.method||"GET",a=(0,l.getTracer)(),i=a.getActiveScopeSpan(),c=h.instrumentationOnRequestError.bind(h),m=async i=>h.render(e,s,{query:{...r,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:d.preview,propagateError:!1,dev:h.isDev,page:"/api/notifications/[id]",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>c(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=e.get("next.route");if(r){let e=`${t} ${r}`;i.setAttributes({"next.route":r,"http.route":r,"next.span_name":e}),i.updateName(e)}else i.updateName(`${t} ${n}`)});i?await m(i):await a.withPropagatedContext(e.headers,()=>a.trace(u.BaseServerSpan.handleRequest,{spanName:`${t} ${n}`,kind:l.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},m))}catch(e){if(h.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,m,"default",0,p,"handler",()=>f],43366)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__b46ed4f5._.js.map