module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let a=t||"";a.endsWith("/")&&(a=a.slice(0,-1)),a&&(a.includes("localhost")||a.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(a))&&(e.setHeader("Access-Control-Allow-Origin",a),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},42287,e=>e.a(async(t,a)=>{try{var s=e.i(65058),r=e.i(74606),i=t([s]);async function n(e,t){let a=e.headers.origin;if((0,r.setCorsHeaders)(t,a),"OPTIONS"===e.method)return void t.status(200).end();if("GET"!==e.method)return t.setHeader("Allow",["GET","OPTIONS"]),t.status(405).json({message:`Method ${e.method} not allowed`});try{let a=Number(e.query.id);if(!Number.isFinite(a))return t.status(400).json({message:"Supervisor employee id is required"});try{await (0,s.default)(`
        ALTER TABLE "Asset_Details" 
        ADD COLUMN IF NOT EXISTS "useful_life" INT DEFAULT 5,
        ADD COLUMN IF NOT EXISTS "salvage_value" VARCHAR(255);
      `,[])}catch(e){console.error("[AUTO-MIGRATION ERROR in supervisor assets]",e)}let r=(await (0,s.default)(`SELECT
        a.id,
        a.name AS "assetName",
        a."asset_Id" AS "barcode",
        a."serial_no" AS "serialNumber",
        a.location,
        s.status AS "status",
        a."photoURL" AS "photoURL",
        a."barcodeURL" AS "barcodeURL",
        a."purchase_date" AS "purchaseDate",
        a."warranty_expiry" AS "warrantyExpiry",
        a.price,
        a.useful_life AS "usefulLife",
        a.salvage_value AS "salvageValue",
        a."categoryId" AS "categoryId",
        a."controller_key" AS "controllerKey",
        cat.category AS "category",
        assignee."fullName" AS "assignedTo",
        assigner."fullName" AS "assignedBy",
        aa.id AS "assignmentId",
        aa."projectName" AS "projectName",
        aa.expected_return_date AS "expectedReturnDate",
        aa."operator_employeeId" AS "operatorId",
        aa."supervisor_employeeId" AS "senderId"
      FROM "Asset_Details" a
      LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
      LEFT JOIN "Status" s ON s.id = a.status_id
      LEFT JOIN "Users" assignee ON assignee."employeeId" = a.assigned_to
      LEFT JOIN "Users" assigner ON assigner."employeeId" = a.assigned_by
      LEFT JOIN LATERAL (
        SELECT * FROM "Asset_Assignments"
        WHERE "assetId" = a.id
          AND COALESCE(status, '') <> 'returned'
          AND "returned_date" IS NULL
        ORDER BY id DESC
        LIMIT 1
      ) aa ON TRUE
      WHERE a.assigned_to = $1
        AND LOWER(COALESCE(s.status, '')) IN ('assigned', 'overdue')
      ORDER BY a.id ASC`,[a])).rows.map(e=>{let t=parseFloat(e.price)||0,a=parseFloat(e.salvageValue)||0,s=parseInt(e.usefulLife)||5,r=t,i=100,n=0,o=null;if(t>0&&s>0&&e.purchaseDate){let l=new Date(e.purchaseDate),d=new Date,u=Math.max(0,(d.getTime()-l.getTime())/315576e5),p=Math.max(0,Math.min((t-a)/s*u,t-a));r=t-p,n=u/s*100,n=Math.min(100,n),(i=Math.max(0,100-n))<60&&(o=`Depreciation alert: remaining life is ${i.toFixed(1)}%. Please scrap or upgrade this asset.`)}return{id:e.id.toString(),assetId:Number(e.id),assetName:e.assetName,barcode:e.barcode,controllerKey:e.controllerKey||null,serialNumber:e.serialNumber,category:e.category||null,categoryId:e.categoryId?Number(e.categoryId):null,status:e.status,assignedTo:e.assignedTo,assignedBy:e.assignedBy,location:e.location,purchaseDate:e.purchaseDate,warrantyExpiry:e.warrantyExpiry,price:e.price,photoURL:e.photoURL||"",barcodeURL:e.barcodeURL||null,expectedReturnDate:e.expectedReturnDate||null,projectName:e.projectName||null,assignmentId:e.assignmentId?e.assignmentId.toString():null,operatorId:e.operatorId?e.operatorId.toString():null,senderId:e.senderId?e.senderId.toString():null,receiverId:e.operatorId?e.operatorId.toString():null,isOverdue:"overdue"===String(e.status||"").toLowerCase(),usefulLife:s,salvageValue:e.salvageValue||null,remainingValue:parseFloat(r.toFixed(2)),depreciationMessage:o}});return t.status(200).json({assets:r,count:r.length})}catch(e){return console.error("Supervisor assets API error:",e),t.status(500).json({message:"Internal server error"})}}[s]=i.then?(await i)():i,e.s(["default",()=>n]),a()}catch(e){a(e)}},!1),17318,e=>e.a(async(t,a)=>{try{var s=e.i(33534),r=e.i(59016),i=e.i(55334),n=e.i(26175),o=e.i(42287),l=e.i(8322),d=e.i(84914),u=e.i(83666),p=t([o]);[o]=p.then?(await p)():p;let g=(0,n.hoist)(o,"default"),h=(0,n.hoist)(o,"config"),m=new i.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/supervisor/assets",pathname:"/api/supervisor/assets",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function c(e,t,a){m.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/supervisor/assets";r=r.replace(/\/index$/,"")||"/";let i=await m.prepare(e,t,{srcPage:r});if(!i){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:n,params:o,prerenderManifest:p,routerServerContext:c}=i;try{let a=e.method||"GET",s=(0,l.getTracer)(),i=s.getActiveScopeSpan(),u=m.instrumentationOnRequestError.bind(m),g=async i=>m.render(e,t,{query:{...n,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:m.isDev,page:"/api/supervisor/assets",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${a} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${a} ${r}`)});i?await g(i):await s.withPropagatedContext(e.headers,()=>s.trace(d.BaseServerSpan.handleRequest,{spanName:`${a} ${r}`,kind:l.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},g))}catch(e){if(m.isDev)throw e;(0,s.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,h,"default",0,g,"handler",()=>c]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__d261436b._.js.map