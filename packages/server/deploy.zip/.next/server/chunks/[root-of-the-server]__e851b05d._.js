module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},59923,e=>{"use strict";var t=e.i(33534),s=e.i(59016),r=e.i(55334),a=e.i(26175),i=e.i(65058),n=e.i(74606);async function o(e,t){let s=e.headers.origin;if((0,n.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();if("POST"!==e.method)return t.setHeader("Allow",["POST","OPTIONS"]),t.status(405).json({message:`Method ${e.method} not allowed`});try{let s=e=>{let t=Number(e);return Number.isInteger(t)&&t>0?t:null},{notificationId:r,assignmentId:a,assetId:n,confirmedByEmployeeId:o}=e.body,d=Number(r),l=Number(a),u=Number(n),p=Number(o);if(!Number.isFinite(d)||!Number.isFinite(p))return t.status(400).json({message:"notificationId and confirmedByEmployeeId are required"});let m=null,E=null,I=null,c=Number.isFinite(l)&&l>0;if(c){let e=await (0,i.default)(`SELECT id, "assetId", "operator_employeeId", "supervisor_employeeId", status
         FROM "Asset_Assignments"
         WHERE id = $1
         LIMIT 1`,[l]);if(0===e.rows.length)return t.status(404).json({message:"Assignment not found"});let r=e.rows[0];m=Number(r.assetId),E=s(r.operator_employeeId),I=s(r.supervisor_employeeId)}else if(Number.isFinite(u)&&u>0){m=u;let e=await (0,i.default)(`SELECT assigned_to
         FROM "Asset_Details"
         WHERE id = $1
         LIMIT 1`,[m]);if(0===e.rows.length)return t.status(404).json({message:"Asset not found"});I=s(e.rows[0]?.assigned_to)}else{let e=await (0,i.default)(`SELECT "assetId", "assignmentId", "senderId", "receiverId"
         FROM "Notifications"
         WHERE id = $1
         LIMIT 1`,[d]);if(0===e.rows.length)return t.status(404).json({message:"Notification not found"});let r=e.rows[0],a=Number(r?.assetId),n=Number(r?.assignmentId);if(!Number.isFinite(a)||a<=0)return t.status(400).json({message:"Unable to resolve asset from notification"});if(m=a,Number.isFinite(n)&&n>0){let e=await (0,i.default)(`SELECT "operator_employeeId", "supervisor_employeeId"
           FROM "Asset_Assignments"
           WHERE id = $1
           LIMIT 1`,[n]);e.rows.length>0&&(E=s(e.rows[0]?.operator_employeeId),I=s(e.rows[0]?.supervisor_employeeId))}if(!Number.isFinite(I)){let e=await (0,i.default)(`SELECT assigned_to
           FROM "Asset_Details"
           WHERE id = $1
           LIMIT 1`,[m]);I=s(e.rows[0]?.assigned_to)}}await (0,i.default)(`UPDATE "Asset_Details"
       SET assigned_to = NULL,
           assigned_by = NULL,
           status_id = (
             SELECT TOP 1 id FROM "Status" WHERE LOWER(status) = 'unassigned'
           )
       WHERE id = $1`,[m]),await (0,i.default)(`UPDATE "Notifications"
       SET status = 'resolved',
           reply = ISNULL(reply, '') + CASE WHEN ISNULL(reply, '') = '' THEN '' ELSE CHAR(10) END + $2
       WHERE id = $1`,[d,`Return confirmed by employee ${p}.`]),await (0,i.default)(`UPDATE "Notifications"
       SET status = 'resolved'
       WHERE "assetId" = $1
         AND id <> $2
         AND ISNULL(status, '') <> 'resolved'
         AND (
           ($3 IS NOT NULL AND "assignmentId" = $3)
           OR
           ($3 IS NULL AND "assignmentId" IS NULL)
         )
         AND (
           LOWER(ISNULL(reason, '')) LIKE '%has been returned by%'
           OR LOWER(ISNULL(reply, '')) LIKE '%pending confirmation%'
         )`,[m,d,c?l:null]);let f=await (0,i.default)(`SELECT DISTINCT u."employeeId"
       FROM "Users" u
       INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
       INNER JOIN "Permissions" p ON rp."permissionId" = p.id
       WHERE p.code IN ('MANAGE_USERS', 'MANAGE_WORKFLOWS')`,[]);0===f.rows.length&&(f=await (0,i.default)(`SELECT DISTINCT u."employeeId"
         FROM "Users" u
         INNER JOIN "Roles" r ON u."roleId" = r."roleId"
         WHERE LOWER(r."roleName") IN ('admin', 'super admin', 'superadmin', 'tenant admin', 'tenantadmin')`,[]));let N=f.rows.map(e=>s(e.employeeId)).filter(e=>null!==e),g=await (0,i.default)('SELECT "tenantId" FROM "Users" WHERE "employeeId" = $1 LIMIT 1',[p]),h=g.rows[0]?.tenantId||null;for(let e of new Set([...N,...I?[I]:[],...E?[E]:[]])){let t={kind:"return_notification",message:`Asset ${m} is now unassigned after return confirmation.`,tenantId:h,returnedDate:new Date().toISOString()};await (0,i.default)(`INSERT INTO "Notifications"
        ("assetId", "assignmentId", "senderId", "receiverId", "reason", "reply", "status", "created_at", "tenantId")
        VALUES ($1, $2, $3, $4, $5, $6, 'received', GETDATE(), $7)`,[m,c?l:null,p,e,`Return confirmed for asset ${m}.`,JSON.stringify(t),h])}return t.status(200).json({message:"Return confirmed and asset moved to unassigned"})}catch(e){return console.error("Confirm return API error:",e),t.status(500).json({message:"Internal server error"})}}e.s(["default",()=>o],25711);var d=e.i(25711),l=e.i(8322),u=e.i(84914),p=e.i(83666);let m=(0,a.hoist)(d,"default"),E=(0,a.hoist)(d,"config"),I=new r.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/assets/confirm-return",pathname:"/api/assets/confirm-return",bundlePath:"",filename:""},userland:d,distDir:".next",relativeProjectDir:""});async function c(e,s,r){I.isDev&&(0,p.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/assets/confirm-return";a=a.replace(/\/index$/,"")||"/";let i=await I.prepare(e,s,{srcPage:a});if(!i){s.statusCode=400,s.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:n,params:o,prerenderManifest:d,routerServerContext:m}=i;try{let t=e.method||"GET",r=(0,l.getTracer)(),i=r.getActiveScopeSpan(),p=I.instrumentationOnRequestError.bind(I),E=async i=>I.render(e,s,{query:{...n,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:d.preview,propagateError:!1,dev:I.isDev,page:"/api/assets/confirm-return",internalRevalidate:null==m?void 0:m.revalidate,onError:(...t)=>p(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${t} ${a}`)});i?await E(i):await r.withPropagatedContext(e.headers,()=>r.trace(u.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:l.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},E))}catch(e){if(I.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,E,"default",0,m,"handler",()=>c],59923)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__e851b05d._.js.map