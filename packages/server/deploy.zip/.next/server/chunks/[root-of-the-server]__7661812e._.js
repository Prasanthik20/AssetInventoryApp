module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let r=t||"";r.endsWith("/")&&(r=r.slice(0,-1)),r&&(r.includes("localhost")||r.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(r))&&(e.setHeader("Access-Control-Allow-Origin",r),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},75941,e=>{"use strict";var t=e.i(65058),r=e.i(74606);async function s(e,s){let a=e.headers.origin;if((0,r.setCorsHeaders)(s,a),"OPTIONS"===e.method)return void s.status(200).end();if("GET"!==e.method)return s.setHeader("Allow",["GET","OPTIONS"]),s.status(405).end(`Method ${e.method} Not Allowed`);let n=e.query.id||e.query.userId||e.query.operatorId;if(!n)return s.status(400).json({message:"User ID missing or invalid"});let i=String(n).trim(),o=e.query.tenantId?String(e.query.tenantId).trim():null;try{let e=await (0,t.default)(`SELECT TOP 1 "tenantId", "employeeId"
       FROM "Users"
       WHERE "employeeId" = $1 OR CAST("employeeId" AS VARCHAR(50)) = $1`,[i]),r=e.rows[0]?.employeeId?Number(e.rows[0].employeeId):Number(i),a=o||e.rows[0]?.tenantId||null,n=`
      SELECT
        n.id                    AS "notificationId",
        n.reason,
        n.reply,
        n.status,
        n.created_at            AS "createdAt",

        ad.id                   AS "assetId",
        ad.name                 AS "assetName",

        s."employeeId"          AS "senderId",
        s."fullName"            AS "senderName",

        r."employeeId"          AS "receiverId",
        r."fullName"            AS "receiverName"

      FROM "Notifications" n
      LEFT JOIN "Asset_Details" ad ON ad.id = n."assetId"
      LEFT JOIN "Users" s ON (s."employeeId" = n."senderId" OR CAST(s."employeeId" AS VARCHAR(50)) = CAST(n."senderId" AS VARCHAR(50)))
      LEFT JOIN "Users" r ON (r."employeeId" = n."receiverId" OR CAST(r."employeeId" AS VARCHAR(50)) = CAST(n."receiverId" AS VARCHAR(50)))

      WHERE (
        n."receiverId" = $1 OR CAST(n."receiverId" AS VARCHAR(50)) = CAST($1 AS VARCHAR(50))
      )
        AND (n."tenantId" = $2 OR $2 IS NULL OR n."tenantId" IS NULL)
        AND n.status IN ('unread', 'resolved', 'received', 'replied', 'pending')
      ORDER BY n.created_at DESC;
    `,{rows:d}=await (0,t.default)(n,[r,a]),l=d.map(e=>({id:e.notificationId,notificationId:e.notificationId,assetId:e.assetId,assetName:e.assetName||"Asset",senderId:e.senderId,senderName:e.senderName||"Manager",receiverId:e.receiverId,receiverName:e.receiverName||"User",reason:e.reason,reply:e.reply,status:e.status,createdAt:e.createdAt}));return s.status(200).json({success:!0,notifications:l})}catch(e){return console.error("Fetch User Notifications Error:",e),s.status(500).json({message:"Internal server error fetching user notifications.",error:e.message})}}e.s(["default",()=>s])},90921,e=>{"use strict";var t=e.i(33534),r=e.i(59016),s=e.i(55334),a=e.i(26175);let n=e.i(75941).default;e.s(["default",0,n],46695);var i=e.i(46695),o=e.i(8322),d=e.i(84914),l=e.i(83666);let u=(0,a.hoist)(i,"default"),c=(0,a.hoist)(i,"config"),p=new s.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/notifications/operator",pathname:"/api/notifications/operator",bundlePath:"",filename:""},userland:i,distDir:".next",relativeProjectDir:""});async function A(e,r,s){p.isDev&&(0,l.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/notifications/operator";a=a.replace(/\/index$/,"")||"/";let n=await p.prepare(e,r,{srcPage:a});if(!n){r.statusCode=400,r.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:i,params:u,prerenderManifest:c,routerServerContext:A}=n;try{let t=e.method||"GET",s=(0,o.getTracer)(),n=s.getActiveScopeSpan(),l=p.instrumentationOnRequestError.bind(p),m=async n=>p.render(e,r,{query:{...i,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:p.isDev,page:"/api/notifications/operator",internalRevalidate:null==A?void 0:A.revalidate,onError:(...t)=>l(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${t} ${a}`)});n?await m(n):await s.withPropagatedContext(e.headers,()=>s.trace(d.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:o.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},m))}catch(e){if(p.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,c,"default",0,u,"handler",()=>A],90921)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__7661812e._.js.map