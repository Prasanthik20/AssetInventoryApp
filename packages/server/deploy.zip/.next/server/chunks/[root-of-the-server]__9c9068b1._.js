module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let r=t||"";r.endsWith("/")&&(r=r.slice(0,-1)),r&&(r.includes("localhost")||r.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(r))&&(e.setHeader("Access-Control-Allow-Origin",r),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},28562,e=>e.a(async(t,r)=>{try{var s=e.i(65058),a=e.i(74606),i=t([s]);async function o(e,t){let r=e.headers.origin;if((0,a.setCorsHeaders)(t,r),"OPTIONS"===e.method)return void t.status(200).end();if("POST"!==e.method)return t.status(405).end();try{let r=(...e)=>{for(let t of e){if(Array.isArray(t)){let e=t.map(e=>"string"==typeof e?e.trim():"").filter(e=>e.length>0);if(e.length>0)return e}if("string"==typeof t&&t.trim().length>0)return[t.trim()]}return[]},a=(...e)=>r(...e)[0],i=async(e,t)=>{if(!Number.isFinite(e))throw Error(`Invalid ${t} id`);let r=await (0,s.default)(`SELECT "employeeId"
                 FROM "Users"
                 WHERE "employeeId" = $1
                 LIMIT 1`,[e]),a=Number(r.rows[0]?.employeeId);if(Number.isFinite(a))return a;let i=await (0,s.default)(`SELECT "employeeId"
                 FROM "Users"
                 WHERE "userId" = $1
                 LIMIT 1`,[e]),o=Number(i.rows[0]?.employeeId);if(!Number.isFinite(o))throw Error(`Unable to resolve ${t} employee id`);return o},o=async e=>{let t=await (0,s.default)(`SELECT "fullName"
                 FROM "Users"
                 WHERE "employeeId" = $1
                 LIMIT 1`,[e]);return String(t.rows[0]?.fullName||e)},n=async()=>(await (0,s.default)(`SELECT DISTINCT u."employeeId"
                 FROM "Users" u
                 INNER JOIN "Roles" r ON u."roleId" = r."roleId"
                 WHERE LOWER(r."roleName") IN ('admin', 'super admin', 'superadmin')`,[])).rows.map(e=>Number(e.employeeId)).filter(e=>Number.isFinite(e)),d=async(e,t,r,a,i,o,n)=>{await (0,s.default)(`INSERT INTO "Notifications"
                 ("assetId", "assignmentId", "senderId", "receiverId", "reason", "reply", "status", "created_at", "tenantId")
                 VALUES ($1, $2, $3, $4, $5, $6, 'unread', NOW(), $7)`,[e,t,r,a,i,o??null,n??null])},{assetIds:l,operatorEmployeeId:u,photoURL:p,barcodeURL:c,assetMedia:m,assignmentIds:h}=e.body;if(!Array.isArray(l)||0===l.length)return t.status(400).json({message:"assetIds required"});let E=Number(u);if(!Number.isFinite(E))return t.status(400).json({message:"operatorEmployeeId required"});let f=await i(E,"operator"),b=await o(f),g=await (0,s.default)('SELECT "tenantId" FROM "Users" WHERE "employeeId" = $1 LIMIT 1',[f]),I=g.rows[0]?.tenantId||null,y=await n(),R=new Set(y),N=l.map(Number),w=new Map;Array.isArray(h)&&h.forEach((e,t)=>{let r=Number(e),s=Number(N[t]);Number.isFinite(r)&&Number.isFinite(s)&&w.set(s,r)});let A=new Map,L=r(e.body?.photoURLs,e.body?.photos,p,e.body?.photoUrl,e.body?.image),S=r(e.body?.barcodeURLs,e.body?.barcodes,c,e.body?.barcodeUrl,e.body?.barcodeImage,e.body?.barcode_image);if(Array.isArray(m))for(let e of m){let t=Number(e?.assetId);if(!Number.isFinite(t))continue;let s=Number(e?.assignmentId);Number.isFinite(s)&&w.set(t,s);let a=r(e?.photoURLs,e?.photos,e?.photoURL,e?.photoUrl,e?.photo,e?.image),i=r(e?.barcodeURLs,e?.barcodes,e?.barcodeURL,e?.barcodeUrl,e?.barcodeImage,e?.barcode_image);A.set(t,{photoURL:a[0],barcodeURL:i[0]})}for(let e of N){let t=A.get(e)||{photoURL:a(L,p),barcodeURL:a(S,c)},r=w.get(e),n=await (0,s.default)(`
                UPDATE "Asset_Assignments"
                SET 
                    "status" = 'returned',
                    "returned_date" = NOW(),
                    "photoURL" = COALESCE($3, "photoURL"),
                    "barcodeURL" = COALESCE($4, "barcodeURL"),
                    "serialNoVerified" = true,
                    "tenantId" = COALESCE("tenantId", $6)
                                WHERE id = COALESCE($5, (
                    SELECT id
                    FROM "Asset_Assignments"
                    WHERE "operator_employeeId" = $1
                      AND "assetId" = $2
                                            AND COALESCE("status", '') <> 'returned'
                                            AND "returned_date" IS NULL
                    ORDER BY "assigned_date" DESC NULLS LAST, id DESC
                    LIMIT 1
                                ))
                                    AND "operator_employeeId" = $1
                                    AND "assetId" = $2
                                    AND COALESCE("status", '') <> 'returned'
                                RETURNING id, "supervisor_employeeId"
                `,[f,e,t.photoURL??null,t.barcodeURL??null,Number.isFinite(r)?Number(r):null,I]);if(0===n.rows.length){console.warn(`No active assignment found for operator ${f} and asset ${e}`);continue}let l=Number(n.rows[0]?.id),u=await i(Number(n.rows[0]?.supervisor_employeeId),"supervisor"),m=await o(u),h=["assigned_to = $2","assigned_by = $2",`status_id = (
                    SELECT id FROM "Status" 
                    WHERE status ILIKE 'Assigned' 
                    LIMIT 1
                )`],E=[e,u];for(let r of(t.photoURL&&(h.push(`"photoURL" = $${E.length+1}`),E.push(t.photoURL)),t.barcodeURL&&(h.push(`"barcodeURL" = $${E.length+1}`),E.push(t.barcodeURL)),await (0,s.default)(`
                UPDATE "Asset_Details"
                SET ${h.join(", ")}
                WHERE id = $1
                `,E),new Set([...y,u]))){if(!Number.isFinite(r))continue;let t=`Asset ${e} has been returned by ${b}.`,s=R.has(r)?`Return pending confirmation: Asset ${e} was returned by ${b} and is now with ${m}.`:`Return pending confirmation: ${b} returned asset ${e}. Please confirm final return.`,a={kind:"return_notification",message:s,tenantId:I,returnedDate:new Date().toISOString()};await d(e,l,f,r,t,JSON.stringify(a),I)}}return t.status(200).json({message:"Assets returned and moved to supervisor pending confirmation"})}catch(e){return console.error(e),t.status(500).json({message:"Server error"})}}[s]=i.then?(await i)():i,e.s(["config",0,{api:{bodyParser:{sizeLimit:"2gb"}}},"default",()=>o]),r()}catch(e){r(e)}},!1),82894,e=>e.a(async(t,r)=>{try{var s=e.i(33534),a=e.i(59016),i=e.i(55334),o=e.i(26175),n=e.i(28562),d=e.i(8322),l=e.i(84914),u=e.i(83666),p=t([n]);[n]=p.then?(await p)():p;let m=(0,o.hoist)(n,"default"),h=(0,o.hoist)(n,"config"),E=new i.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/operator/returnAsset",pathname:"/api/operator/returnAsset",bundlePath:"",filename:""},userland:n,distDir:".next",relativeProjectDir:""});async function c(e,t,r){E.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/operator/returnAsset";a=a.replace(/\/index$/,"")||"/";let i=await E.prepare(e,t,{srcPage:a});if(!i){t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:o,params:n,prerenderManifest:p,routerServerContext:c}=i;try{let r=e.method||"GET",s=(0,d.getTracer)(),i=s.getActiveScopeSpan(),u=E.instrumentationOnRequestError.bind(E),m=async i=>E.render(e,t,{query:{...o,...n},params:n,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:E.isDev,page:"/api/operator/returnAsset",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let o=e.get("next.route");if(o){let e=`${r} ${o}`;i.setAttributes({"next.route":o,"http.route":o,"next.span_name":e}),i.updateName(e)}else i.updateName(`${r} ${a}`)});i?await m(i):await s.withPropagatedContext(e.headers,()=>s.trace(l.BaseServerSpan.handleRequest,{spanName:`${r} ${a}`,kind:d.SpanKind.SERVER,attributes:{"http.method":r,"http.target":e.url}},m))}catch(e){if(E.isDev)throw e;(0,s.sendError)(t,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,h,"default",0,m,"handler",()=>c]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__9c9068b1._.js.map