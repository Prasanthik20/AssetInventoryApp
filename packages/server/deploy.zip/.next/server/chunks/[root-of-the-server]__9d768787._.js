module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,s)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let s=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,s,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,s)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),s=e.i(74606),r=e.i(65058);let a=e=>async(r,a)=>{let n=r.headers.origin;if((0,s.setCorsHeaders)(a,n),"OPTIONS"===r.method)return void a.status(200).end();let i=r.headers.authorization;if(!i||!i.startsWith("Bearer "))return a.status(401).json({message:"Authorization token missing or invalid."});let o=i.split(" ")[1],d=(0,t.verifyToken)(o);return d?(r.user=d,e(r,a)):a.status(401).json({message:"Invalid or expired token."})};e.s(["withAuth",0,a,"withPermission",0,(e,t)=>a(async(s,a)=>{let{userId:n,tenantId:i,role:o}=s.user;if("Super Admin"===o||"SuperAdmin"===o)return t(s,a);try{let o=await (0,r.default)(`SELECT 1 
         FROM "Users" u
         INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
         INNER JOIN "Permissions" p ON rp."permissionId" = p.id
         WHERE u."userId" = $1 AND p.code = $2 AND (u."tenantId" = $3 OR u."tenantId" IS NULL)
         LIMIT 1`,[n,e,i||null]);if(0===o.rows.length)return a.status(403).json({message:`Forbidden: Missing required permission ${e}`});return t(s,a)}catch(e){return console.error("Permission check error:",e),a.status(500).json({message:"Internal server error during authorization."})}})])},54799,(e,t,s)=>{t.exports=e.x("crypto",()=>require("crypto"))},39732,e=>{"use strict";var t=e.i(33534),s=e.i(59016),r=e.i(55334),a=e.i(26175),n=e.i(65058);async function i(t,s){if("Super Admin"!==t.user.role)return s.status(403).json({message:"Access denied. Super Admin privileges required."});if("GET"===t.method)try{let e=`
        SELECT 
          t.id, 
          t.name, 
          t.status, 
          t."organizationType" AS "organizationType",
          t."createdAt" AS "createdAt",
          COALESCE(sub.name, 'No active plan') AS "planName",
          COALESCE(sub.plan_id, 'free-trial') AS "planId",
          sub."startDate" AS "startDate",
          sub."endDate" AS "endDate",
          admin."fullName" AS "adminName",
          admin.email AS "adminEmail",
          admin."phoneNumber" AS "adminPhone",
          admin.address AS "adminAddress",
          (SELECT COUNT(*) FROM "Asset_Details" WHERE "tenantId" = t.id) AS "assetsCount"
        FROM 
          "Tenants" t
        OUTER APPLY (
          SELECT TOP 1 p.name, p.id AS plan_id, s."startDate" AS "startDate", s."endDate" AS "endDate"
          FROM "Subscriptions" s
          JOIN "Plans" p ON s."planId" = p.id
          WHERE s."tenantId" = t.id
          ORDER BY s."updatedAt" DESC
        ) sub
        OUTER APPLY (
          SELECT TOP 1 u."fullName", u.email, u."phoneNumber", u.address
          FROM "Users" u
          LEFT JOIN "Roles" r ON u."roleId" = r."roleId"
          WHERE u."tenantId" = t.id AND (
            u."isPrimaryContact" = 1 OR
            (r."roleName" IS NOT NULL AND (
              LOWER(r."roleName") IN ('admin', 'super admin', 'superadmin', 'tenant admin', 'tenantadmin')
              OR EXISTS (
                SELECT 1 FROM "Role_Permissions" rp
                JOIN "Permissions" p ON rp."permissionId" = p.id
                WHERE rp."roleId" = u."roleId" AND p.code IN ('MANAGE_USERS', 'MANAGE_WORKFLOWS')
              )
            ))
          )
          ORDER BY u."userId" ASC
        ) admin
        ORDER BY 
          t."createdAt" DESC;
      `,t=await (0,n.default)(e);return console.log(t.rows),s.status(200).json({count:t.rows.length,tenants:t.rows})}catch(e){return console.error("Super Admin Fetch Tenants Error:",e),s.status(500).json({message:"An internal server error occurred."})}if("PUT"===t.method){let{tenantId:r,status:a,planId:i}=t.body;if(!r||!a||!i)return s.status(400).json({message:"Tenant ID, status, and target plan ID are required."});try{await (0,n.default)("BEGIN"),await (0,n.default)('UPDATE "Tenants" SET status = $1, "updatedAt" = NOW() WHERE id = $2',[a,r]);let t=await (0,n.default)('SELECT id FROM "Subscriptions" WHERE "tenantId" = $1 ORDER BY "createdAt" DESC LIMIT 1',[r]),o="active"===a?"active":"expired"===a?"expired":"canceled";if(t.rows.length>0)await (0,n.default)(`UPDATE "Subscriptions" 
           SET "planId" = $1, status = $2, "updatedAt" = NOW() 
           WHERE id = $3`,[i,o,t.rows[0].id]);else{let t=e.r(54799).randomUUID(),s=new Date(Date.now()+2592e6);await (0,n.default)(`INSERT INTO "Subscriptions" (id, "tenantId", "planId", "startDate", "endDate", status, "createdAt", "updatedAt")
           VALUES ($1, $2, $3, NOW(), $4, $5, NOW(), NOW())`,[t,r,i,s.toISOString(),o])}return await (0,n.default)("COMMIT"),s.status(200).json({success:!0,message:"Tenant profile, status, and subscription updated successfully!"})}catch(e){return await (0,n.default)("ROLLBACK"),console.error("Super Admin Update Tenant Error:",e),s.status(500).json({message:"An internal server error occurred during transaction processing."})}}return s.setHeader("Allow",["GET","PUT"]),s.status(405).json({message:`Method ${t.method} Not Allowed`})}let o=(0,e.i(19477).withAuth)(i);e.s(["default",0,o],94676);var d=e.i(94676),u=e.i(8322),l=e.i(84914),p=e.i(83666);let c=(0,a.hoist)(d,"default"),m=(0,a.hoist)(d,"config"),E=new r.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/superadmin/tenants",pathname:"/api/superadmin/tenants",bundlePath:"",filename:""},userland:d,distDir:".next",relativeProjectDir:""});async function A(e,s,r){E.isDev&&(0,p.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/superadmin/tenants";a=a.replace(/\/index$/,"")||"/";let n=await E.prepare(e,s,{srcPage:a});if(!n){s.statusCode=400,s.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:i,params:o,prerenderManifest:d,routerServerContext:c}=n;try{let t=e.method||"GET",r=(0,u.getTracer)(),n=r.getActiveScopeSpan(),p=E.instrumentationOnRequestError.bind(E),m=async n=>E.render(e,s,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:d.preview,propagateError:!1,dev:E.isDev,page:"/api/superadmin/tenants",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>p(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${t} ${a}`)});n?await m(n):await r.withPropagatedContext(e.headers,()=>r.trace(l.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:u.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},m))}catch(e){if(E.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,m,"default",0,c,"handler",()=>A],39732)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__9d768787._.js.map