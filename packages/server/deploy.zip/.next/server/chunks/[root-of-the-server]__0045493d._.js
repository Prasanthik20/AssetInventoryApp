module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,s)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let s=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,s,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,s)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),s=e.i(74606),r=e.i(65058);let a=e=>async(r,a)=>{let n=r.headers.origin;if((0,s.setCorsHeaders)(a,n),"OPTIONS"===r.method)return void a.status(200).end();let i=r.headers.authorization;if(!i||!i.startsWith("Bearer "))return a.status(401).json({message:"Authorization token missing or invalid."});let o=i.split(" ")[1],u=(0,t.verifyToken)(o);return u?(r.user=u,e(r,a)):a.status(401).json({message:"Invalid or expired token."})};e.s(["withAuth",0,a,"withPermission",0,(e,t)=>a(async(s,a)=>{let{userId:n,tenantId:i,role:o}=s.user;if("Super Admin"===o||"SuperAdmin"===o)return t(s,a);try{let o=await (0,r.default)(`SELECT 1 
         FROM "Users" u
         INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
         INNER JOIN "Permissions" p ON rp."permissionId" = p.id
         WHERE u."userId" = $1 AND p.code = $2 AND (u."tenantId" = $3 OR u."tenantId" IS NULL)
         LIMIT 1`,[n,e,i||null]);if(0===o.rows.length)return a.status(403).json({message:`Forbidden: Missing required permission ${e}`});return t(s,a)}catch(e){return console.error("Permission check error:",e),a.status(500).json({message:"Internal server error during authorization."})}})])},94990,e=>{"use strict";var t=e.i(33534),s=e.i(59016),r=e.i(55334),a=e.i(26175),n=e.i(65058),i=e.i(74606),o=e.i(19477);let u=e=>{if(!e)return null;let t=new Date(Array.isArray(e)?e[0]:e);return Number.isNaN(t.getTime())?null:t.toISOString()},l=(0,o.withAuth)(async function(e,t){let s=e.headers.origin;if((0,i.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();if("GET"!==e.method)return t.setHeader("Allow",["GET","OPTIONS"]),t.status(405).json({message:`Method ${e.method} not allowed`});try{let{tenantId:s}=e.user;if(!s)return t.status(403).json({message:"Tenant context missing."});let r=Number(e.query.employeeId),a=Array.isArray(e.query.roleName)?e.query.roleName[0]:e.query.roleName,i=String(a||"").toLowerCase().includes("admin"),o=u(e.query.fromDate),l=u(e.query.toDate);if(!Number.isFinite(r))return t.status(400).json({message:"employeeId is required"});if(!(await (0,n.default)(`SELECT u."employeeId"
       FROM "Users" u
       WHERE u."employeeId" = $1 AND u."tenantId" = $2
       LIMIT 1`,[r,s])).rows.length)return t.status(404).json({message:"User not found in your organization"});let d=[s],p=['ad."tenantId" = $1'],m=[];i||(d.push(r),p.push(`ad.id IN (
        SELECT aa2."assetId"
        FROM "Asset_Assignments" aa2
        WHERE aa2."operator_employeeId" = $${d.length}
           OR aa2."supervisor_employeeId" = $${d.length}
      )`)),o&&(d.push(o),m.push(`aa.assigned_date >= $${d.length}::date`)),l&&(d.push(l),m.push(`aa.assigned_date <= $${d.length}::date`));let E=p.length>0?`WHERE ${p.join(" AND ")}`:"",c=m.length>0?`AND ${m.join(" AND ")}`:"",N=`
      SELECT
        aa.id                                              AS "assignmentId",
        ad.id                                              AS "assetId",
        ad.name                                            AS "assetName",
        ad.serial_no                                       AS "serialNo",
        LOWER(COALESCE(s.status, 'unknown'))               AS "assetStatus",
        aa."operator_employeeId"                           AS "operatorEmployeeId",
        op."fullName"                                      AS "operatorName",
        aa."supervisor_employeeId"                         AS "supervisorEmployeeId",
        sp."fullName"                                      AS "supervisorName",
        aa.location,
        aa."projectName"                                   AS "projectName",
        aa.notes,
        aa.assigned_date                                   AS "assignedDate",
        aa.expected_return_date                            AS "expectedReturnDate",
        aa.returned_date                                   AS "returnedDate",
        CASE
          WHEN aa.id IS NULL THEN
            CASE
              WHEN LOWER(COALESCE(s.status, '')) IN ('under maintenance', 'maintenance')
                THEN 'maintenance'
              ELSE 'unassigned'
            END
          WHEN aa.status = 'returned' OR aa.returned_date IS NOT NULL THEN 'returned'
          WHEN aa.expected_return_date < CURRENT_DATE               THEN 'overdue'
          ELSE 'assigned'
        END                                                AS "status"
      FROM "Asset_Details" ad
      LEFT JOIN "Status" s ON s.id = ad.status_id
      LEFT JOIN "Asset_Assignments" aa
        ON aa."assetId" = ad.id ${c}
      LEFT JOIN "Users" op ON op."employeeId" = aa."operator_employeeId"
      LEFT JOIN "Users" sp ON sp."employeeId" = aa."supervisor_employeeId"
      ${E}
      ORDER BY
        CASE WHEN aa.id IS NULL THEN 1 ELSE 0 END,
        aa.assigned_date DESC,
        aa.id DESC;
    `,g=(await (0,n.default)(N,d)).rows.map(e=>({assignmentId:null!=e.assignmentId?Number(e.assignmentId):null,assetId:Number(e.assetId),assetName:String(e.assetName||""),serialNo:e.serialNo||null,assetStatus:String(e.assetStatus||"unknown"),operatorEmployeeId:null!=e.operatorEmployeeId?Number(e.operatorEmployeeId):null,operatorName:e.operatorName||null,supervisorEmployeeId:null!=e.supervisorEmployeeId?Number(e.supervisorEmployeeId):null,supervisorName:e.supervisorName||null,location:e.location||null,projectName:e.projectName||null,notes:(e=>{if(null==e)return null;let t=String(e).trim();if(!t)return null;try{let e=JSON.parse(t);if("string"==typeof e){let t=e.trim();return t.length>0?t:null}if(Array.isArray(e)){let t=e.map(e=>"string"==typeof e?e.trim():"").filter(e=>e.length>0).join(", ");return t.length>0?t:null}if(e&&"object"==typeof e){for(let t of["notes","note","message","reason","text","comment"]){let s=e[t];if("string"==typeof s&&s.trim().length>0)return s.trim()}let s=Object.entries(e).filter(([,e])=>null!=e&&String(e).trim().length>0).map(([e,t])=>`${e}: ${String(t).trim()}`).join(" | ");return s.length>0?s:t}}catch{}return t})(e.notes),assignedDate:e.assignedDate||null,expectedReturnDate:e.expectedReturnDate||null,returnedDate:e.returnedDate||null,status:String(e.status||"unassigned")})),h={totalAssignments:g.filter(e=>null!=e.assignmentId).length,activeAssignments:g.filter(e=>"assigned"===e.status).length,returnedAssignments:g.filter(e=>"returned"===e.status).length,overdueAssignments:g.filter(e=>"overdue"===e.status).length,unassignedAssets:g.filter(e=>"unassigned"===e.status).length,maintenanceAssets:g.filter(e=>"maintenance"===e.status).length},A=`
      FROM "Notifications" n
      WHERE n."tenantId" = $1
        AND LOWER(COALESCE(n.status, '')) IN ('unread', 'replied')
        AND (
          LOWER(COALESCE(n.reply, '')) LIKE '%pending confirmation%'
          OR LOWER(COALESCE(n.reply, '')) LIKE '%workflow_approval_pending%'
          OR (
            LOWER(COALESCE(n.reason, '')) LIKE '%has been returned by%'
            AND LOWER(COALESCE(n.reply, '')) LIKE '%return pending confirmation%'
          )
        )
        AND LOWER(COALESCE(n.reason, '')) NOT LIKE '%return confirmed%'
        AND LOWER(COALESCE(n.reply, '')) NOT LIKE '%return confirmed%'
    `,I=i?`SELECT COUNT(*)::int AS count ${A}`:`SELECT COUNT(*)::int AS count ${A}
         AND (n."receiverId" = $2 OR n."senderId" = $2)`,S=i?[s]:[s,r],f=await (0,n.default)(I,S),O=Number(f.rows?.[0]?.count||0),y={};if(i){let e=await (0,n.default)('SELECT COUNT(*)::int AS count FROM "Asset_Details" WHERE "tenantId" = $1',[s]),t=await (0,n.default)(`SELECT COUNT(*)::int AS count
         FROM "Asset_Details" ad
         LEFT JOIN "Status" s ON ad.status_id = s.id
         WHERE ad."tenantId" = $1 AND LOWER(COALESCE(s.status, '')) = 'unassigned'`,[s]),r=await (0,n.default)(`SELECT COUNT(*)::int AS count
         FROM "Asset_Details" ad
         LEFT JOIN "Status" s ON ad.status_id = s.id
         WHERE ad."tenantId" = $1 AND LOWER(COALESCE(s.status, '')) IN ('under maintenance', 'maintenance')`,[s]);y={totalAssets:Number(e.rows?.[0]?.count||0),officeAssets:Number(t.rows?.[0]?.count||0),underMaintenanceAssets:Number(r.rows?.[0]?.count||0)}}return t.status(200).json({role:i?"admin":"user",summary:{...h,pendingApprovalConfirmations:O,...y},history:g})}catch(e){return console.error("Reports API error:",e),t.status(500).json({message:"Internal server error"})}});e.s(["default",0,l],68108);var d=e.i(68108),p=e.i(8322),m=e.i(84914),E=e.i(83666);let c=(0,a.hoist)(d,"default"),N=(0,a.hoist)(d,"config"),g=new r.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/reports/asset-history",pathname:"/api/reports/asset-history",bundlePath:"",filename:""},userland:d,distDir:".next",relativeProjectDir:""});async function h(e,s,r){g.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/reports/asset-history";a=a.replace(/\/index$/,"")||"/";let n=await g.prepare(e,s,{srcPage:a});if(!n){s.statusCode=400,s.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:i,params:o,prerenderManifest:u,routerServerContext:l}=n;try{let t=e.method||"GET",r=(0,p.getTracer)(),n=r.getActiveScopeSpan(),d=g.instrumentationOnRequestError.bind(g),E=async n=>g.render(e,s,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:u.preview,propagateError:!1,dev:g.isDev,page:"/api/reports/asset-history",internalRevalidate:null==l?void 0:l.revalidate,onError:(...t)=>d(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${t} ${a}`)});n?await E(n):await r.withPropagatedContext(e.headers,()=>r.trace(m.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:p.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},E))}catch(e){if(g.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,N,"default",0,c,"handler",()=>h],94990)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0045493d._.js.map