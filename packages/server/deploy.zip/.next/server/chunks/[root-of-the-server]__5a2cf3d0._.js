module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,s)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let s=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,s,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,s)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),s=e.i(74606),a=e.i(65058);let r=e=>async(a,r)=>{let i=a.headers.origin;if((0,s.setCorsHeaders)(r,i),"OPTIONS"===a.method)return void r.status(200).end();let n=a.headers.authorization;if(!n||!n.startsWith("Bearer "))return r.status(401).json({message:"Authorization token missing or invalid."});let o=n.split(" ")[1],u=(0,t.verifyToken)(o);return u?(a.user=u,e(a,r)):r.status(401).json({message:"Invalid or expired token."})};e.s(["withAuth",0,r,"withPermission",0,(e,t)=>r(async(s,r)=>{let{userId:i,tenantId:n,role:o}=s.user;if("Super Admin"===o||"SuperAdmin"===o)return t(s,r);try{let o=await (0,a.default)(`SELECT 1 
         FROM "Users" u
         INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
         INNER JOIN "Permissions" p ON rp."permissionId" = p.id
         WHERE u."userId" = $1 AND p.code = $2 AND (u."tenantId" = $3 OR u."tenantId" IS NULL)
         LIMIT 1`,[i,e,n||null]);if(0===o.rows.length)return r.status(403).json({message:`Forbidden: Missing required permission ${e}`});return t(s,r)}catch(e){return console.error("Permission check error:",e),r.status(500).json({message:"Internal server error during authorization."})}})])},69217,e=>{"use strict";var t=e.i(65058),s=e.i(19477);async function a(e){try{let s=`
      SELECT 
        t.status AS "tenantStatus",
        p.id AS "planId",
        p.name AS "planName",
        p."maxAssets",
        p."maxUsers",
        s."endDate",
        s.status AS "subStatus"
      FROM 
        "Tenants" t
      LEFT JOIN 
        "Subscriptions" s ON s."tenantId" = t.id AND s.status = 'active'
      LEFT JOIN 
        "Plans" p ON p.id = s."planId"
      WHERE 
        t.id = $1
      ORDER BY 
        s."createdAt" DESC
      LIMIT 1;
    `,a=await (0,t.default)(s,[e]);if(0===a.rows.length)return null;let r=a.rows[0],i=new Date,n=r.endDate?new Date(r.endDate):null,o="expired"===r.tenantStatus||"expired"===r.subStatus||null!==n&&n<i;return{tenantStatus:r.tenantStatus||"active",planId:r.planId||"free-trial",planName:r.planName||"Free Trial",maxAssets:r.maxAssets||100,maxUsers:r.maxUsers||5,endDate:n,isExpired:o}}catch(e){return console.error("getSubscriptionInfo Error:",e),null}}async function r(e,s){let r=await a(e);if(!r)return{allowed:!1,used:0,max:0,error:"Subscription information not found."};if("suspended"===r.tenantStatus)return{allowed:!1,used:0,max:0,error:"Organization account has been suspended. Please contact the Super Admin."};if(r.isExpired)return{allowed:!1,used:0,max:0,error:"Subscription has expired. Write access is restricted."};if("assets"===s){let s=await (0,t.default)('SELECT COUNT(id) AS count FROM "Asset_Details" WHERE "tenantId" = $1',[e]),a=parseInt(s.rows[0]?.count||"0",10),i=r.maxAssets;return{allowed:a<i,used:a,max:i,error:a>=i?`Asset limit reached. Used: ${a}/${i}. Please upgrade your plan.`:void 0}}{let s=await (0,t.default)('SELECT COUNT("userId") AS count FROM "Users" WHERE "tenantId" = $1 AND status != \'disabled\'',[e]),a=parseInt(s.rows[0]?.count||"0",10),i=r.maxUsers;return{allowed:a<i,used:a,max:i,error:a>=i?`User limit reached. Active users: ${a}/${i}. Please upgrade your plan.`:void 0}}}e.s(["getSubscriptionInfo",()=>a,"withSubscriptionLimit",0,(e,t)=>(0,s.withAuth)(async(s,i)=>{let{tenantId:n,role:o}=s.user;if("Super Admin"===o)return e(s,i);if(!n)return i.status(400).json({message:"Tenant identifier missing in authentication payload."});let u=await a(n);if(!u)return i.status(403).json({message:"No valid tenant subscription found."});if("suspended"===u.tenantStatus)return i.status(403).json({code:"ACCOUNT_SUSPENDED",message:"Your organization access is suspended. Please contact the Super Admin."});if("GET"===s.method||"OPTIONS"===s.method)return i.setHeader("X-Subscription-Plan",u.planId),i.setHeader("X-Subscription-Status",u.tenantStatus),i.setHeader("X-Subscription-Expired",String(u.isExpired)),e(s,i);if(u.isExpired)return i.status(403).json({code:"SUBSCRIPTION_EXPIRED",message:"Your subscription has expired. Write operations are disabled. Please request a plan renewal.",subscriptionExpired:!0});if(t){let e=await r(n,t);if(!e.allowed)return i.status(403).json({code:"LIMIT_EXCEEDED",message:e.error,limitType:t,used:e.used,max:e.max})}return e(s,i)})])},93960,e=>{"use strict";var t=e.i(33534),s=e.i(59016),a=e.i(55334),r=e.i(26175),i=e.i(65058),n=e.i(74606),o=e.i(19477);async function u(e,t){let s=e.headers.origin;if((0,n.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();let{tenantId:a}=e.user;if(!a)return t.status(403).json({message:"Tenant context missing."});try{let e=`
      SELECT TOP 1 s.*, p.name as "planName", p."maxUsers", p."maxAssets"
      FROM "Subscriptions" s
      JOIN "Plans" p ON s."planId" = p.id
      WHERE s."tenantId" = $1 OR $1 IS NULL
      ORDER BY s."createdAt" DESC;
    `,s=(await (0,i.default)(e,[a])).rows[0],r=`
      SELECT
        COUNT(a.id) AS "totalAssets",
        COUNT(CASE WHEN LOWER(s.status) = 'unassigned' OR (s.id IS NULL AND a.assigned_to IS NULL) THEN a.id END) AS "unassignedAssets",
        COUNT(CASE WHEN LOWER(s.status) = 'assigned' OR (s.id IS NULL AND a.assigned_to IS NOT NULL) THEN a.id END) AS "assignedAssets",
        COUNT(CASE WHEN LOWER(s.status) = 'overdue' THEN a.id END) AS "overdueAssets",
        COUNT(CASE WHEN LOWER(s.status) IN ('under maintenance', 'maintenance') THEN a.id END) AS "underMaintenanceAssets",
        COUNT(CASE WHEN LOWER(s.status) = 'unassigned' OR (s.id IS NULL AND a.assigned_to IS NULL) THEN a.id END) AS "officeAssets",
        COUNT(CASE WHEN LOWER(s.status) IN ('assigned', 'overdue') OR (s.id IS NULL AND a.assigned_to IS NOT NULL) THEN a.id END) AS "fieldAssets",
        (
          SELECT COUNT(*) 
          FROM "Users" u 
          LEFT JOIN "Roles" r ON u."roleId" = r."roleId" 
          WHERE (u."tenantId" = $1 OR $1 IS NULL) 
            AND (r."roleName" IS NULL OR LOWER(r."roleName") NOT IN ('super admin', 'superadmin'))
        ) AS "totalUsers",
        (SELECT COUNT(*) FROM "Category" WHERE ("tenantId" = $1 OR $1 IS NULL OR "isSystemCategory" = 1)) AS "totalCategories"
      FROM "Asset_Details" a
      LEFT JOIN "Status" s ON a.status_id = s.id
      WHERE a."tenantId" = $1 OR $1 IS NULL;
    `,n=(await (0,i.default)(r,[a])).rows[0]||{},o=`
      SELECT TOP 10 COALESCE(location, 'Default Site') AS location, COUNT(*) as count
      FROM "Asset_Details" a
      LEFT JOIN "Status" s ON a.status_id = s.id
      WHERE (a."tenantId" = $1 OR $1 IS NULL OR a."tenantId" IS NULL) 
        AND (LOWER(s.status) IN ('assigned', 'overdue') OR a.assigned_to IS NOT NULL)
      GROUP BY location
      ORDER BY count DESC;
    `,u=await (0,i.default)(o,[a]),d=`
      SELECT 
        SUM(COALESCE(TRY_CAST(a.price AS FLOAT), 0)) AS "totalAssetValue",
        SUM(
          CASE 
            WHEN TRY_CAST(a.price AS FLOAT) > 0 AND COALESCE(a.useful_life, 5) > 0 AND a.purchase_date IS NOT NULL THEN
              CASE 
                WHEN ((TRY_CAST(a.price AS FLOAT) - COALESCE(TRY_CAST(a.salvage_value AS FLOAT), 0)) / COALESCE(a.useful_life, 5) * (DATEDIFF(day, a.purchase_date, GETDATE()) / 365.25)) > (TRY_CAST(a.price AS FLOAT) - COALESCE(TRY_CAST(a.salvage_value AS FLOAT), 0))
                  THEN (TRY_CAST(a.price AS FLOAT) - COALESCE(TRY_CAST(a.salvage_value AS FLOAT), 0))
                WHEN ((TRY_CAST(a.price AS FLOAT) - COALESCE(TRY_CAST(a.salvage_value AS FLOAT), 0)) / COALESCE(a.useful_life, 5) * (DATEDIFF(day, a.purchase_date, GETDATE()) / 365.25)) < 0
                  THEN 0
                ELSE ((TRY_CAST(a.price AS FLOAT) - COALESCE(TRY_CAST(a.salvage_value AS FLOAT), 0)) / COALESCE(a.useful_life, 5) * (DATEDIFF(day, a.purchase_date, GETDATE()) / 365.25))
              END
            ELSE 0
          END
        ) AS "totalDepreciatedValue",
        COUNT(
          CASE 
            WHEN TRY_CAST(a.price AS FLOAT) > 0 AND COALESCE(a.useful_life, 5) > 0 AND a.purchase_date IS NOT NULL AND a.purchase_date < GETDATE() THEN a.id
          END
        ) AS "depreciatedAssetsCount"
      FROM "Asset_Details" a
      WHERE a."tenantId" = $1 OR $1 IS NULL OR a."tenantId" IS NULL;
    `,l=(await (0,i.default)(d,[a])).rows[0]||{},p=parseFloat(l.totalAssetValue)||0,c=parseFloat(l.totalDepreciatedValue)||0,A=Math.max(0,p-c),E=`
      SELECT 
        a.id,
        a.name AS "assetName",
        a."asset_Id" AS "barcode",
        a.serial_no AS "serialNo",
        a.price,
        a.useful_life AS "usefulLife",
        a.salvage_value AS "salvageValue",
        a.purchase_date AS "purchaseDate",
        cat.category AS "category",
        s.status AS "status"
      FROM "Asset_Details" a
      LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
      LEFT JOIN "Status" s ON a.status_id = s.id
      WHERE (a."tenantId" = $1 OR $1 IS NULL OR a."tenantId" IS NULL);
    `,S=await (0,i.default)(E,[a]),N=[];S.rows.forEach(e=>{let t=parseFloat(e.price)||0,s=parseFloat(e.salvageValue)||0,a=parseInt(e.usefulLife)||5;if(t>0&&a>0&&e.purchaseDate){let r=new Date(e.purchaseDate),i=new Date,n=Math.max(0,(i.getTime()-r.getTime())/315576e5),o=(t-s)/a,u=Math.max(0,Math.min(o*n,t-s)),d=Math.max(0,t-u),l=Math.min(100,n/a*100),p=Math.max(0,100-l);p<60&&N.push({id:e.id.toString(),name:e.assetName,assetName:e.assetName,barcode:e.barcode,serialNo:e.serialNo||e.barcode,category:e.category,status:e.status,purchaseDate:e.purchaseDate,price:e.price,usefulLife:a,salvageValue:e.salvageValue,remainingValue:parseFloat(d.toFixed(2)),percentLifeRemaining:parseFloat(p.toFixed(1)),depreciationMessage:`Depreciation alert: remaining life is ${p.toFixed(1)}%. Please scrap or upgrade this asset.`})}});let T={totalAssets:parseInt(n.totalAssets)||0,unassignedAssets:parseInt(n.unassignedAssets)||0,assignedAssets:parseInt(n.assignedAssets)||0,overdueAssets:parseInt(n.overdueAssets)||0,underMaintenanceAssets:parseInt(n.underMaintenanceAssets)||0,officeAssets:parseInt(n.officeAssets)||0,fieldAssets:parseInt(n.fieldAssets)||0,totalUsers:parseInt(n.totalUsers)||0,totalCategories:parseInt(n.totalCategories)||0,depreciatingAssetsCount:N.length,depreciatedAssetsCount:N.length,totalAssetValue:parseFloat(p.toFixed(2)),totalDepreciatedValue:parseFloat(c.toFixed(2)),netBookValue:parseFloat(A.toFixed(2))},O=u.rows.map(e=>({location:e.location||"Unknown",count:parseInt(e.count)||0}));return t.status(200).json({...T,metrics:T,depreciatingAssets:N,subscription:s?{planName:s.planName,status:s.status,maxUsers:s.maxUsers,maxAssets:s.maxAssets,startDate:s.startDate,endDate:s.endDate}:null,fieldLocationStats:O,fieldLocationBreakdown:O})}catch(e){return console.error("Dashboard API Error:",e),t.status(500).json({message:"Internal server error.",details:String(e)})}}let d=(0,e.i(69217).withSubscriptionLimit)((0,o.withAuth)(u));e.s(["default",0,d],3123);var l=e.i(3123),p=e.i(8322),c=e.i(84914),A=e.i(83666);let E=(0,r.hoist)(l,"default"),S=(0,r.hoist)(l,"config"),N=new a.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/dashboard",pathname:"/api/dashboard",bundlePath:"",filename:""},userland:l,distDir:".next",relativeProjectDir:""});async function T(e,s,a){N.isDev&&(0,A.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/dashboard";r=r.replace(/\/index$/,"")||"/";let i=await N.prepare(e,s,{srcPage:r});if(!i){s.statusCode=400,s.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:n,params:o,prerenderManifest:u,routerServerContext:d}=i;try{let t=e.method||"GET",a=(0,p.getTracer)(),i=a.getActiveScopeSpan(),l=N.instrumentationOnRequestError.bind(N),A=async i=>N.render(e,s,{query:{...n,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:u.preview,propagateError:!1,dev:N.isDev,page:"/api/dashboard",internalRevalidate:null==d?void 0:d.revalidate,onError:(...t)=>l(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${t} ${r}`)});i?await A(i):await a.withPropagatedContext(e.headers,()=>a.trace(c.BaseServerSpan.handleRequest,{spanName:`${t} ${r}`,kind:p.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},A))}catch(e){if(N.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,S,"default",0,E,"handler",()=>T],93960)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__5a2cf3d0._.js.map