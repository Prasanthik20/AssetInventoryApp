module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},25711,e=>e.a(async(t,s)=>{try{var r=e.i(65058),a=e.i(74606),i=t([r]);async function n(e,t){let s=e.headers.origin;if((0,a.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();if("POST"!==e.method)return t.setHeader("Allow",["POST","OPTIONS"]),t.status(405).json({message:`Method ${e.method} not allowed`});try{let s=e=>{let t=Number(e);return Number.isInteger(t)&&t>0?t:null},{notificationId:a,assignmentId:i,assetId:n,confirmedByEmployeeId:o}=e.body,d=Number(a),l=Number(i),u=Number(n),m=Number(o);if(!Number.isFinite(d)||!Number.isFinite(m))return t.status(400).json({message:"notificationId and confirmedByEmployeeId are required"});let p=null,E=null,c=null,I=Number.isFinite(l)&&l>0;if(I){let e=await (0,r.default)(`SELECT id, "assetId", "operator_employeeId", "supervisor_employeeId", status
         FROM "Asset_Assignments"
         WHERE id = $1
         LIMIT 1`,[l]);if(0===e.rows.length)return t.status(404).json({message:"Assignment not found"});let a=e.rows[0];p=Number(a.assetId),E=s(a.operator_employeeId),c=s(a.supervisor_employeeId)}else if(Number.isFinite(u)&&u>0){p=u;let e=await (0,r.default)(`SELECT assigned_to
         FROM "Asset_Details"
         WHERE id = $1
         LIMIT 1`,[p]);if(0===e.rows.length)return t.status(404).json({message:"Asset not found"});c=s(e.rows[0]?.assigned_to)}else{let e=await (0,r.default)(`SELECT "assetId", "assignmentId", "senderId", "receiverId"
         FROM "Notifications"
         WHERE id = $1
         LIMIT 1`,[d]);if(0===e.rows.length)return t.status(404).json({message:"Notification not found"});let a=e.rows[0],i=Number(a?.assetId),n=Number(a?.assignmentId);if(!Number.isFinite(i)||i<=0)return t.status(400).json({message:"Unable to resolve asset from notification"});if(p=i,Number.isFinite(n)&&n>0){let e=await (0,r.default)(`SELECT "operator_employeeId", "supervisor_employeeId"
           FROM "Asset_Assignments"
           WHERE id = $1
           LIMIT 1`,[n]);e.rows.length>0&&(E=s(e.rows[0]?.operator_employeeId),c=s(e.rows[0]?.supervisor_employeeId))}if(!Number.isFinite(c)){let e=await (0,r.default)(`SELECT assigned_to
           FROM "Asset_Details"
           WHERE id = $1
           LIMIT 1`,[p]);c=s(e.rows[0]?.assigned_to)}}await (0,r.default)(`UPDATE "Asset_Details"
       SET assigned_to = NULL,
           assigned_by = NULL,
           status_id = (
             SELECT id FROM "Status" WHERE status ILIKE 'Unassigned' LIMIT 1
           )
       WHERE id = $1`,[p]),await (0,r.default)(`UPDATE "Notifications"
       SET status = 'resolved',
           reply = COALESCE(reply, '') || CASE WHEN COALESCE(reply, '') = '' THEN '' ELSE E'
' END || $2
       WHERE id = $1`,[d,`Return confirmed by employee ${m}.`]),await (0,r.default)(`UPDATE "Notifications"
       SET status = 'resolved'
       WHERE "assetId" = $1
         AND id <> $2
         AND COALESCE(status, '') <> 'resolved'
         AND (
           ($3::bigint IS NOT NULL AND "assignmentId" = $3)
           OR
           ($3::bigint IS NULL AND "assignmentId" IS NULL)
         )
         AND (
           LOWER(COALESCE(reason, '')) LIKE '%has been returned by%'
           OR LOWER(COALESCE(reply, '')) LIKE '%pending confirmation%'
         )`,[p,d,I?l:null]);let f=(await (0,r.default)(`SELECT DISTINCT u."employeeId"
       FROM "Users" u
       INNER JOIN "Roles" r ON u."roleId" = r."roleId"
       WHERE LOWER(r."roleName") IN ('admin', 'super admin', 'superadmin')`,[])).rows.map(e=>s(e.employeeId)).filter(e=>null!==e),g=await (0,r.default)('SELECT "tenantId" FROM "Users" WHERE "employeeId" = $1 LIMIT 1',[m]),h=g.rows[0]?.tenantId||null;for(let e of new Set([...f,...c?[c]:[],...E?[E]:[]])){let t={kind:"return_notification",message:`Asset ${p} is now unassigned after return confirmation.`,tenantId:h,returnedDate:new Date().toISOString()};await (0,r.default)(`INSERT INTO "Notifications"
        ("assetId", "assignmentId", "senderId", "receiverId", "reason", "reply", "status", "created_at", "tenantId")
        VALUES ($1, $2, $3, $4, $5, $6, 'received', NOW(), $7)`,[p,I?l:null,m,e,`Return confirmed for asset ${p}.`,JSON.stringify(t),h])}return t.status(200).json({message:"Return confirmed and asset moved to unassigned"})}catch(e){return console.error("Confirm return API error:",e),t.status(500).json({message:"Internal server error"})}}[r]=i.then?(await i)():i,e.s(["default",()=>n]),s()}catch(e){s(e)}},!1),59923,e=>e.a(async(t,s)=>{try{var r=e.i(33534),a=e.i(59016),i=e.i(55334),n=e.i(26175),o=e.i(25711),d=e.i(8322),l=e.i(84914),u=e.i(83666),m=t([o]);[o]=m.then?(await m)():m;let E=(0,n.hoist)(o,"default"),c=(0,n.hoist)(o,"config"),I=new i.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/assets/confirm-return",pathname:"/api/assets/confirm-return",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,s){I.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/assets/confirm-return";a=a.replace(/\/index$/,"")||"/";let i=await I.prepare(e,t,{srcPage:a});if(!i){t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:n,params:o,prerenderManifest:m,routerServerContext:p}=i;try{let s=e.method||"GET",r=(0,d.getTracer)(),i=r.getActiveScopeSpan(),u=I.instrumentationOnRequestError.bind(I),E=async i=>I.render(e,t,{query:{...n,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:m.preview,propagateError:!1,dev:I.isDev,page:"/api/assets/confirm-return",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${s} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${s} ${a}`)});i?await E(i):await r.withPropagatedContext(e.headers,()=>r.trace(l.BaseServerSpan.handleRequest,{spanName:`${s} ${a}`,kind:d.SpanKind.SERVER,attributes:{"http.method":s,"http.target":e.url}},E))}catch(e){if(I.isDev)throw e;(0,r.sendError)(t,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,c,"default",0,E,"handler",()=>p]),s()}catch(e){s(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__69a5a8d3._.js.map