module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,s)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let s=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,s,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,s)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),s=e.i(74606);e.s(["withAuth",0,e=>async(a,r)=>{let n=a.headers.origin;if((0,s.setCorsHeaders)(r,n),"OPTIONS"===a.method)return void r.status(200).end();let i=a.headers.authorization;if(!i||!i.startsWith("Bearer "))return r.status(401).json({message:"Authorization token missing or invalid."});let o=i.split(" ")[1],u=(0,t.verifyToken)(o);return u?(a.user=u,e(a,r)):r.status(401).json({message:"Invalid or expired token."})}])},69217,e=>e.a(async(t,s)=>{try{var a=e.i(65058),r=e.i(19477),n=t([a]);async function i(e){try{let t=`
      SELECT 
        t.status AS "tenantStatus",
        p.id AS "planId",
        p.name AS "planName",
        p."maxAssets",
        p."maxUsers",
        s."endDate",
        s.status AS "subStatus"
      FROM 
        "Tenants" t
      LEFT JOIN 
        "Subscriptions" s ON s."tenantId" = t.id AND s.status = 'active'
      LEFT JOIN 
        "Plans" p ON p.id = s."planId"
      WHERE 
        t.id = $1
      ORDER BY 
        s."createdAt" DESC
      LIMIT 1;
    `,s=await (0,a.default)(t,[e]);if(0===s.rows.length)return null;let r=s.rows[0],n=new Date,i=r.endDate?new Date(r.endDate):null,o="expired"===r.tenantStatus||"expired"===r.subStatus||null!==i&&i<n;return{tenantStatus:r.tenantStatus||"active",planId:r.planId||"free-trial",planName:r.planName||"Free Trial",maxAssets:r.maxAssets||100,maxUsers:r.maxUsers||5,endDate:i,isExpired:o}}catch(e){return console.error("getSubscriptionInfo Error:",e),null}}async function o(e,t){let s=await i(e);if(!s)return{allowed:!1,used:0,max:0,error:"Subscription information not found."};if("suspended"===s.tenantStatus)return{allowed:!1,used:0,max:0,error:"Organization account has been suspended. Please contact the Super Admin."};if(s.isExpired)return{allowed:!1,used:0,max:0,error:"Subscription has expired. Write access is restricted."};if("assets"===t){let t=await (0,a.default)('SELECT COUNT(id) AS count FROM "Asset_Details" WHERE "tenantId" = $1',[e]),r=parseInt(t.rows[0]?.count||"0",10),n=s.maxAssets;return{allowed:r<n,used:r,max:n,error:r>=n?`Asset limit reached. Used: ${r}/${n}. Please upgrade your plan.`:void 0}}{let t=await (0,a.default)('SELECT COUNT("userId") AS count FROM "Users" WHERE "tenantId" = $1 AND status != \'disabled\'',[e]),r=parseInt(t.rows[0]?.count||"0",10),n=s.maxUsers;return{allowed:r<n,used:r,max:n,error:r>=n?`User limit reached. Active users: ${r}/${n}. Please upgrade your plan.`:void 0}}}[a]=n.then?(await n)():n,e.s(["getSubscriptionInfo",()=>i,"withSubscriptionLimit",0,(e,t)=>(0,r.withAuth)(async(s,a)=>{let{tenantId:r,role:n}=s.user;if("Super Admin"===n)return e(s,a);if(!r)return a.status(400).json({message:"Tenant identifier missing in authentication payload."});let u=await i(r);if(!u)return a.status(403).json({message:"No valid tenant subscription found."});if("suspended"===u.tenantStatus)return a.status(403).json({code:"ACCOUNT_SUSPENDED",message:"Your organization access is suspended. Please contact the Super Admin."});if("GET"===s.method||"OPTIONS"===s.method)return a.setHeader("X-Subscription-Plan",u.planId),a.setHeader("X-Subscription-Status",u.tenantStatus),a.setHeader("X-Subscription-Expired",String(u.isExpired)),e(s,a);if(u.isExpired)return a.status(403).json({code:"SUBSCRIPTION_EXPIRED",message:"Your subscription has expired. Write operations are disabled. Please request a plan renewal.",subscriptionExpired:!0});if(t){let e=await o(r,t);if(!e.allowed)return a.status(403).json({code:"LIMIT_EXCEEDED",message:e.error,limitType:t,used:e.used,max:e.max})}return e(s,a)})]),s()}catch(e){s(e)}},!1),3123,e=>e.a(async(t,s)=>{try{var a=e.i(65058),r=e.i(74606),n=e.i(69217),i=t([a,n]);async function o(e,t){let s=e.headers.origin;if((0,r.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();let{tenantId:n}=e.user;if(!n)return t.status(403).json({message:"Tenant context missing."});try{try{await (0,a.default)(`
        ALTER TABLE "Asset_Details" 
        ADD COLUMN IF NOT EXISTS "useful_life" INT DEFAULT 5,
        ADD COLUMN IF NOT EXISTS "salvage_value" VARCHAR(255);
      `,[])}catch(e){console.error("[AUTO-MIGRATION ERROR]",e)}let e=`
      SELECT s.*, p.name as "planName", p."maxUsers", p."maxAssets"
      FROM "Subscriptions" s
      JOIN "Plans" p ON s."planId" = p.id
      WHERE s."tenantId" = $1
      ORDER BY s."createdAt" DESC
      LIMIT 1;
    `,s=(await (0,a.default)(e,[n])).rows[0],r=`
      SELECT
        COUNT(a.id) AS "totalAssets",
        COUNT(a.id) FILTER (WHERE s.status = 'Unassigned') AS "unassignedAssets",
        COUNT(a.id) FILTER (WHERE s.status = 'Assigned') AS "assignedAssets",
        COUNT(a.id) FILTER (WHERE s.status = 'Overdue') AS "overdueAssets",
        COUNT(a.id) FILTER (WHERE s.status IN ('Under Maintenance', 'Maintenance', 'under maintenance')) AS "underMaintenanceAssets",
        COUNT(a.id) FILTER (WHERE s.status = 'Unassigned') AS "officeAssets",
        COUNT(a.id) FILTER (WHERE s.status IN ('Assigned', 'Overdue')) AS "fieldAssets",
        (SELECT COUNT(*) FROM "Users" WHERE "tenantId" = $1) AS "totalUsers",
        (SELECT COUNT(*) FROM "Category" WHERE "tenantId" = $1) AS "totalCategories"
      FROM "Asset_Details" a
      LEFT JOIN "Status" s ON a.status_id = s.id
      WHERE a."tenantId" = $1;
    `,i=(await (0,a.default)(r,[n])).rows[0],o=`
      SELECT location, COUNT(*)::int as count
      FROM "Asset_Details"
      WHERE "tenantId" = $1 
        AND status_id IN (SELECT id FROM "Status" WHERE status IN ('Assigned', 'Overdue'))
      GROUP BY location
      ORDER BY count DESC
      LIMIT 10;
    `,u=await (0,a.default)(o,[n]),d=await (0,a.default)(`
      SELECT 
        a.id, 
        a.name, 
        a.serial_no AS "serialNo", 
        a.price, 
        a.purchase_date AS "purchaseDate", 
        a.useful_life AS "usefulLife", 
        a.salvage_value AS "salvageValue"
      FROM "Asset_Details" a
      WHERE a."tenantId" = $1
    `,[n]),l=0,c=[];for(let e of d.rows){let t=parseFloat(e.price)||0,s=parseFloat(e.salvageValue)||0,a=parseInt(e.usefulLife)||5;if(t>0&&a>0&&e.purchaseDate){let r=new Date(e.purchaseDate),n=new Date,i=Math.max(0,(n.getTime()-r.getTime())/315576e5),o=(t-s)/a,u=Math.max(0,Math.min(o*i,t-s)),d=t-u,p=i/a*100,E=Math.max(0,100-p);E<60&&(l++,c.push({id:e.id.toString(),name:e.name,serialNo:e.serialNo,price:e.price,usefulLife:a,salvageValue:e.salvageValue||"0",remainingValue:parseFloat(d.toFixed(2)),percentLifeRemaining:parseFloat(E.toFixed(1))}))}}let p=Number(i.totalAssets||0),E=Number(i.totalUsers||0),m={totalAssets:p,totalUsers:E,totalCategories:Number(i.totalCategories||0),unassignedAssets:Number(i.unassignedAssets||0),assignedAssets:Number(i.assignedAssets||0),overdueAssets:Number(i.overdueAssets||0),underMaintenanceAssets:Number(i.underMaintenanceAssets||0),officeAssets:Number(i.officeAssets||0),fieldAssets:Number(i.fieldAssets||0)},A=null;if(s){let e=s.maxUsers>0?E/s.maxUsers*100:0,t=s.maxAssets>0?p/s.maxAssets*100:0;A={plan:s.planName,status:s.status,endDate:s.endDate,maxUsers:s.maxUsers,maxAssets:s.maxAssets,userUsagePercent:Math.min(100,Math.round(e)),assetUsagePercent:Math.min(100,Math.round(t))}}return t.status(200).json({...m,fieldLocationStats:u.rows,subscription:A,depreciatingAssetsCount:l,depreciatingAssets:c})}catch(e){return console.error("Dashboard API Error:",e),t.status(500).json({error:"Internal server error"})}}[a,n]=i.then?(await i)():i;let u=(0,n.withSubscriptionLimit)(o);e.s(["default",0,u]),s()}catch(e){s(e)}},!1),93960,e=>e.a(async(t,s)=>{try{var a=e.i(33534),r=e.i(59016),n=e.i(55334),i=e.i(26175),o=e.i(3123),u=e.i(8322),d=e.i(84914),l=e.i(83666),c=t([o]);[o]=c.then?(await c)():c;let E=(0,i.hoist)(o,"default"),m=(0,i.hoist)(o,"config"),A=new n.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/dashboard",pathname:"/api/dashboard",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,s){A.isDev&&(0,l.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/dashboard";r=r.replace(/\/index$/,"")||"/";let n=await A.prepare(e,t,{srcPage:r});if(!n){t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:i,params:o,prerenderManifest:c,routerServerContext:p}=n;try{let s=e.method||"GET",a=(0,u.getTracer)(),n=a.getActiveScopeSpan(),l=A.instrumentationOnRequestError.bind(A),E=async n=>A.render(e,t,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:A.isDev,page:"/api/dashboard",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>l(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${s} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${s} ${r}`)});n?await E(n):await a.withPropagatedContext(e.headers,()=>a.trace(d.BaseServerSpan.handleRequest,{spanName:`${s} ${r}`,kind:u.SpanKind.SERVER,attributes:{"http.method":s,"http.target":e.url}},E))}catch(e){if(A.isDev)throw e;(0,a.sendError)(t,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,m,"default",0,E,"handler",()=>p]),s()}catch(e){s(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__cb4aacb3._.js.map