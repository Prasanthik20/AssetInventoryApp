module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let a=t||"";a.endsWith("/")&&(a=a.slice(0,-1)),a&&(a.includes("localhost")||a.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(a))&&(e.setHeader("Access-Control-Allow-Origin",a),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,a)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let a=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,a,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,a)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),a=e.i(74606),s=e.i(65058);let r=e=>async(s,r)=>{let n=s.headers.origin;if((0,a.setCorsHeaders)(r,n),"OPTIONS"===s.method)return void r.status(200).end();let i=s.headers.authorization;if(!i||!i.startsWith("Bearer "))return r.status(401).json({message:"Authorization token missing or invalid."});let o=i.split(" ")[1],d=(0,t.verifyToken)(o);return d?(s.user=d,e(s,r)):r.status(401).json({message:"Invalid or expired token."})};e.s(["withAuth",0,r,"withPermission",0,(e,t)=>r(async(a,r)=>{let{userId:n,tenantId:i,role:o}=a.user;if("Super Admin"===o||"SuperAdmin"===o)return t(a,r);try{let o=await (0,s.default)(`SELECT 1 
         FROM "Users" u
         INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
         INNER JOIN "Permissions" p ON rp."permissionId" = p.id
         WHERE u."userId" = $1 AND p.code = $2 AND (u."tenantId" = $3 OR u."tenantId" IS NULL)
         LIMIT 1`,[n,e,i||null]);if(0===o.rows.length)return r.status(403).json({message:`Forbidden: Missing required permission ${e}`});return t(a,r)}catch(e){return console.error("Permission check error:",e),r.status(500).json({message:"Internal server error during authorization."})}})])},59679,e=>{"use strict";var t=e.i(33534),a=e.i(59016),s=e.i(55334),r=e.i(26175),n=e.i(65058),i=e.i(74606);async function o(e,t){let a=e.headers.origin;if((0,i.setCorsHeaders)(t,a),"OPTIONS"===e.method)return void t.status(200).end();let{id:s}=e.query,{tenantId:r}=e.user;if(!s||"string"!=typeof s)return t.status(400).json({message:"Asset ID is required."});try{await (0,n.default)(`
      IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Asset_Details') AND name = 'useful_life')
      BEGIN
        ALTER TABLE "Asset_Details" ADD "useful_life" INT DEFAULT 5;
      END
      IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Asset_Details') AND name = 'salvage_value')
      BEGIN
        ALTER TABLE "Asset_Details" ADD "salvage_value" VARCHAR(255);
      END
    `,[])}catch(e){console.error("[AUTO-MIGRATION ERROR]",e)}if("PUT"===e.method)try{let{assetName:a,category:i,controllerKey:o,modelNumber:d,serialNumber:l,purchaseDate:u,warrantyExpiry:p,price:c,location:I,status:g,photoURL:h,barcodeURL:A,usefulLife:m,salvageValue:E,dynamicFields:f}=e.body;await (0,n.default)("BEGIN",[]);let y=await (0,n.default)('SELECT id FROM "Asset_Details" WHERE id = $1 AND "tenantId" = $2 LIMIT 1',[parseInt(s),r]);if(0===y.rows.length)return await (0,n.default)("ROLLBACK",[]),t.status(404).json({message:"Asset not found or access denied."});let N=[],S=[],L=1,R=await (0,n.default)(`SELECT cat.category AS category
         FROM "Asset_Details" a
         LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
         WHERE a.id = $1 AND a."tenantId" = $2
         LIMIT 1`,[parseInt(s),r]),O=String(R.rows[0]?.category||"").trim().toLowerCase();if(void 0!==a&&(N.push(`name = $${L++}`),S.push(a)),void 0!==i){let e=await (0,n.default)(`SELECT TOP 1 "categoryId", category FROM "Category"
           WHERE (category = $1 OR LOWER(category) = LOWER($1) OR CAST("categoryId" AS VARCHAR) = $1)
             AND ("tenantId" = $2 OR "tenantId" IS NULL)`,[String(i).trim(),r]);if(e.rows.length>0)N.push(`"categoryId" = $${L++}`),S.push(e.rows[0].categoryId),O=String(e.rows[0].category||"").trim().toLowerCase();else{try{await (0,n.default)("ROLLBACK",[])}catch(e){}return t.status(400).json({message:`Invalid category: "${i}"`})}}if(void 0!==o){let e="string"==typeof o?o.trim():String(o||"").trim(),t=O.includes("controller")&&e||null;N.push(`"controller_key" = $${L++}`),S.push(t)}else void 0===i||O.includes("controller")||(N.push(`"controller_key" = $${L++}`),S.push(null));if(void 0!==d&&(N.push(`model_no = $${L++}`),S.push(d||null)),void 0!==l&&(N.push(`serial_no = $${L++}`),S.push(l)),void 0!==u&&(N.push(`purchase_date = $${L++}`),S.push(u||null)),void 0!==p&&(N.push(`warranty_expiry = $${L++}`),S.push(p||null)),void 0!==c&&(N.push(`price = $${L++}`),S.push(c||null)),void 0!==m&&(N.push(`"useful_life" = $${L++}`),S.push(null!==m?parseInt(String(m),10):5)),void 0!==E&&(N.push(`"salvage_value" = $${L++}`),S.push(E||null)),void 0!==I&&(N.push(`location = $${L++}`),S.push(I||null)),void 0!==g){let e=await (0,n.default)('SELECT id FROM "Status" WHERE status = $1 AND ("tenantId" = $2 OR "tenantId" IS NULL) LIMIT 1',[g,r]);e.rows.length>0&&(N.push(`status_id = $${L++}`),S.push(e.rows[0].id))}if(void 0!==h&&(N.push(`"photoURL" = $${L++}`),S.push(h||null)),void 0!==A&&(N.push(`"barcodeURL" = $${L++}`),S.push(A||null)),N.length>0){S.push(parseInt(s)),S.push(r);let e=`
          UPDATE "Asset_Details"
          SET ${N.join(", ")}
          WHERE id = $${L++} AND "tenantId" = $${L}
        `;await (0,n.default)(e,S)}if(f&&Array.isArray(f))for(let e of f)e.fieldId&&(await (0,n.default)('SELECT id FROM "AssetCategoryFields" WHERE id = $1 AND ("tenantId" = $2 OR "tenantId" IS NULL) LIMIT 1',[e.fieldId,r])).rows.length>0&&(await (0,n.default)('DELETE FROM "AssetDynamicValues" WHERE "assetId" = $1 AND "fieldId" = $2',[parseInt(s),e.fieldId]),await (0,n.default)('INSERT INTO "AssetDynamicValues" ("assetId", "fieldId", value) VALUES ($1, $2, $3)',[parseInt(s),e.fieldId,String(e.value)]));return await (0,n.default)("COMMIT",[]),t.status(200).json({message:"Asset updated successfully",assetId:s})}catch(e){try{await (0,n.default)("ROLLBACK",[])}catch(e){}return console.error("Update Asset Error:",e),t.status(500).json({message:e.message||"Internal server error.",detail:e.detail})}if("GET"!==e.method)return t.setHeader("Allow",["GET","PUT"]),t.status(405).end(`Method ${e.method} Not Allowed`);try{let e=`
      SELECT
        a.id AS "assetId",
        a.name AS "assetName",
        cat.category AS "category",
        a."categoryId" AS "categoryId",
        a."controller_key" AS "controllerKey",
        s.status AS "dbStatus",
        a.model_no AS "modelNumber",
        a.serial_no AS "serialNumber",
        a."asset_Id" AS "barcode",
        a.location,
        a."photoURL",
        COALESCE(u."fullName", u_aa."fullName") AS "assignedBy",
        COALESCE(assignee."fullName", assignee_aa."fullName") AS "assignedToName",
        COALESCE(a.assigned_to, aa."operator_employeeId") AS assigned_to,
        a.warranty_expiry AS "warrantyExpiry",
        a.purchase_date AS "purchaseDate",
        a.price,
        a.useful_life AS "usefulLife",
        a.salvage_value AS "salvageValue",
        
        aa.assigned_date AS assigned_date,
        aa.expected_return_date AS expected_return_date,
        aa.returned_date AS returned_date,
        aa."projectName" AS "projectName"
      FROM "Asset_Details" a
      LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId" AND (cat."tenantId" = a."tenantId" OR cat."tenantId" IS NULL OR a."tenantId" IS NULL)
      LEFT JOIN "Status" s ON a.status_id = s.id
      OUTER APPLY (
        SELECT TOP 1 * FROM "Asset_Assignments"
        WHERE "assetId" = a.id
          AND ("tenantId" = $2 OR $2 IS NULL OR "tenantId" IS NULL)
          AND (COALESCE(status, '') <> 'returned')
        ORDER BY id DESC
      ) aa
      LEFT JOIN "Users" u ON (u."employeeId" = a.assigned_by OR u."userId" = a.assigned_by) AND (u."tenantId" = a."tenantId" OR u."tenantId" IS NULL OR a."tenantId" IS NULL)
      LEFT JOIN "Users" u_aa ON (u_aa."employeeId" = aa."supervisor_employeeId" OR u_aa."userId" = aa."supervisor_employeeId") AND (u_aa."tenantId" = a."tenantId" OR u_aa."tenantId" IS NULL OR a."tenantId" IS NULL)
      LEFT JOIN "Users" assignee ON (assignee."employeeId" = a.assigned_to OR assignee."userId" = a.assigned_to) AND (assignee."tenantId" = a."tenantId" OR assignee."tenantId" IS NULL OR a."tenantId" IS NULL)
      LEFT JOIN "Users" assignee_aa ON (assignee_aa."employeeId" = aa."operator_employeeId" OR assignee_aa."userId" = aa."operator_employeeId") AND (assignee_aa."tenantId" = a."tenantId" OR assignee_aa."tenantId" IS NULL OR a."tenantId" IS NULL)
      WHERE a.id = $1 AND (a."tenantId" = $2 OR $2 IS NULL);
    `,a=await (0,n.default)(e,[parseInt(s),r]);if(0===a.rows.length)return t.status(404).json({message:`Asset with ID ${s} not found.`});let i=a.rows[0],o=await (0,n.default)(`SELECT adv."fieldId", adv.value, acf."fieldName", acf."fieldType"
       FROM "AssetDynamicValues" adv
       JOIN "AssetCategoryFields" acf ON adv."fieldId" = acf.id
       WHERE adv."assetId" = $1`,[parseInt(s)]),d=e=>e?new Date(e).toISOString().split("T")[0]:null,l=new Date;l.setHours(0,0,0,0);let u=i.expected_return_date?new Date(i.expected_return_date):null,p=!!u&&u<l,c="Assigned"===i.dbStatus&&null!==i.assigned_to,I=parseFloat(i.price)||0,g=parseFloat(i.salvageValue)||0,h=parseInt(i.usefulLife)||5,A=I,m=100,E=0,f=null;if(I>0&&h>0&&i.purchaseDate){let e=new Date(i.purchaseDate),t=new Date,a=Math.max(0,(t.getTime()-e.getTime())/315576e5),s=(I-g)/h,r=Math.max(0,Math.min(s*a,I-g));A=I-r,E=a/h*100,E=Math.min(100,E),(m=Math.max(0,100-E))<60&&(f=`Depreciation alert: remaining life is ${m.toFixed(1)}%. Please scrap or upgrade this asset.`)}let y={assetId:i.assetId,assetName:i.assetName,category:i.category,categoryId:i.categoryId,controllerKey:i.controllerKey,status:c&&p?"Overdue":i.dbStatus,modelNumber:i.modelNumber,serialNumber:i.serialNumber,barcode:i.barcode,location:(e=>{if(!e||"string"!=typeof e)return"Office";let t=e.trim();return t&&"unassigned"!==t.toLowerCase()&&"null"!==t.toLowerCase()?t:"Office"})(i.location),photoURL:i.photoURL||null,assignedBy:i.assignedBy||"N/A",assignedTo:i.assignedToName||"N/A",warrantyExpiry:d(i.warrantyExpiry),purchaseDate:d(i.purchaseDate),assignedDate:d(i.assigned_date),expectedReturnDate:d(i.expected_return_date),returnedDate:d(i.returned_date),projectName:i.projectName||null,price:i.price||null,value:i.price?parseFloat(i.price).toLocaleString():"N/A",usefulLife:h,salvageValue:i.salvageValue||null,remainingValue:parseFloat(A.toFixed(2)),depreciationMessage:f,dynamicValues:o.rows};return t.status(200).json(y)}catch(e){return console.error("Get Asset Error:",e),t.status(500).json({message:"Internal server error."})}}let d=(0,e.i(19477).withAuth)(o);e.s(["config",0,{api:{bodyParser:{sizeLimit:"10mb"}}},"default",0,d],67124);var l=e.i(67124),u=e.i(8322),p=e.i(84914),c=e.i(83666);let I=(0,r.hoist)(l,"default"),g=(0,r.hoist)(l,"config"),h=new s.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/assets/[id]",pathname:"/api/assets/[id]",bundlePath:"",filename:""},userland:l,distDir:".next",relativeProjectDir:""});async function A(e,a,s){h.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/assets/[id]";r=r.replace(/\/index$/,"")||"/";let n=await h.prepare(e,a,{srcPage:r});if(!n){a.statusCode=400,a.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:i,params:o,prerenderManifest:d,routerServerContext:l}=n;try{let t=e.method||"GET",s=(0,u.getTracer)(),n=s.getActiveScopeSpan(),c=h.instrumentationOnRequestError.bind(h),I=async n=>h.render(e,a,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:d.preview,propagateError:!1,dev:h.isDev,page:"/api/assets/[id]",internalRevalidate:null==l?void 0:l.revalidate,onError:(...t)=>c(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${t} ${r}`)});n?await I(n):await s.withPropagatedContext(e.headers,()=>s.trace(p.BaseServerSpan.handleRequest,{spanName:`${t} ${r}`,kind:u.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},I))}catch(e){if(h.isDev)throw e;(0,t.sendError)(a,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,g,"default",0,I,"handler",()=>A],59679)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__264bbef3._.js.map