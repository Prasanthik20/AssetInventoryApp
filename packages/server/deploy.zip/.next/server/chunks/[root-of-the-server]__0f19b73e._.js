module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},80355,e=>{"use strict";var t=e.i(65058),s=e.i(74606);async function a(e,t){let a=e.headers.origin;(0,s.setCorsHeaders)(t,a);try{if("OPTIONS"===e.method)return t.status(200).end();if("GET"===e.method)return n(e,t);if("POST"===e.method)return r(e,t);if("PUT"===e.method)return i(e,t);return t.status(405).json({message:"Method not allowed"})}catch(e){return console.error("Manager API Error:",e),t.status(500).json({message:e?.message||"Internal server error",details:String(e)})}}async function n(e,s){let a=e.query.id||e.query.managerId||e.query.supervisorId;if(!a)return s.status(400).json({message:"Manager ID required"});let n=String(a).trim();try{let e=`
      SELECT
        n.id                    AS "notificationId",
        n.reason,
        n.reply,
        n.status,
        n.created_at            AS "createdAt",
        n."assignmentId",
        n."senderId",
        n."receiverId",
        n."tenantId",
        ad.id                   AS "assetId",
        ad.name                 AS "assetName",
        COALESCE(u."fullName", 'Employee') AS "operatorName"

      FROM "Notifications" n
      LEFT JOIN "Asset_Details" ad ON ad.id = n."assetId"
      LEFT JOIN "Users" u ON CAST(u."employeeId" AS text) = CAST(n."senderId" AS text) AND (u."tenantId" = n."tenantId" OR n."tenantId" IS NULL)

      WHERE (
        CAST(n."receiverId" AS text) = $1
        OR n."receiverId" IS NULL
      )
      AND (
        n."tenantId" = (SELECT "tenantId" FROM "Users" WHERE CAST("employeeId" AS text) = $1 LIMIT 1)
        OR n."tenantId" IS NULL
        OR (SELECT "tenantId" FROM "Users" WHERE CAST("employeeId" AS text) = $1 LIMIT 1) IS NULL
      )
        AND n.status IN ('unread', 'replied', 'received')
      ORDER BY n.created_at DESC
    `,{rows:a}=await (0,t.default)(e,[n]);return s.status(200).json(a)}catch(e){return console.error("GET Manager Notifications Error:",e),s.status(500).json({message:e?.message||"Failed to fetch manager notifications",details:String(e)})}}async function r(e,s){let{assetId:a,assignmentId:n,operatorId:r,receiverId:i,reason:o,tenantId:d}=e.body;if(!a||!r||!i||!o)return s.status(400).json({message:"Missing required fields"});let l=d||null;if(!l){let e=await (0,t.default)('SELECT "tenantId" FROM "Users" WHERE CAST("employeeId" AS text) = $1 LIMIT 1',[String(r)]);l=e.rows[0]?.tenantId||null}let u=`
    INSERT INTO "Notifications"
      ("assetId", "assignmentId", "senderId", "receiverId", "reason", "status", "tenantId")
    VALUES ($1, $2, $3, $4, $5, 'unread', $6)
    RETURNING *;
  `,{rows:c}=await (0,t.default)(u,[a,n||null,r,i,o,l]);return s.status(201).json(c[0])}async function i(e,s){let{notificationId:a,assignmentId:n,newReturnDate:r}=e.body;return a&&n&&r?(await (0,t.default)(`UPDATE "Asset_Assignments"
     SET expected_return_date = $1
     WHERE id = $2`,[r,n]),await (0,t.default)(`UPDATE "Notifications"
     SET status = 'resolved'
     WHERE id = $1`,[a]),s.status(200).json({message:"Resolved successfully"})):s.status(400).json({message:"Missing required fields"})}e.s(["default",()=>a])},51968,e=>{"use strict";var t=e.i(33534),s=e.i(59016),a=e.i(55334),n=e.i(26175),r=e.i(80355),i=e.i(8322),o=e.i(84914),d=e.i(83666);let l=(0,n.hoist)(r,"default"),u=(0,n.hoist)(r,"config"),c=new a.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/notifications/manager",pathname:"/api/notifications/manager",bundlePath:"",filename:""},userland:r,distDir:".next",relativeProjectDir:""});async function p(e,s,a){c.isDev&&(0,d.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/notifications/manager";n=n.replace(/\/index$/,"")||"/";let r=await c.prepare(e,s,{srcPage:n});if(!r){s.statusCode=400,s.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:l,params:u,prerenderManifest:p,routerServerContext:m}=r;try{let t=e.method||"GET",a=(0,i.getTracer)(),r=a.getActiveScopeSpan(),d=c.instrumentationOnRequestError.bind(c),g=async r=>c.render(e,s,{query:{...l,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:c.isDev,page:"/api/notifications/manager",internalRevalidate:null==m?void 0:m.revalidate,onError:(...t)=>d(e,...t)}).finally(()=>{if(!r)return;r.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==o.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;r.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),r.updateName(e)}else r.updateName(`${t} ${n}`)});r?await g(r):await a.withPropagatedContext(e.headers,()=>a.trace(o.BaseServerSpan.handleRequest,{spanName:`${t} ${n}`,kind:i.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},g))}catch(e){if(c.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,u,"default",0,l,"handler",()=>p])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0f19b73e._.js.map