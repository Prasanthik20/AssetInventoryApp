module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let a=t||"";a.endsWith("/")&&(a=a.slice(0,-1)),a&&(a.includes("localhost")||a.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(a))&&(e.setHeader("Access-Control-Allow-Origin",a),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,a)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let a=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,a,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,a)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),a=e.i(74606),s=e.i(65058);let r=e=>async(s,r)=>{let n=s.headers.origin;if((0,a.setCorsHeaders)(r,n),"OPTIONS"===s.method)return void r.status(200).end();let i=s.headers.authorization;if(!i||!i.startsWith("Bearer "))return r.status(401).json({message:"Authorization token missing or invalid."});let o=i.split(" ")[1],l=(0,t.verifyToken)(o);return l?(s.user=l,e(s,r)):r.status(401).json({message:"Invalid or expired token."})};e.s(["withAuth",0,r,"withPermission",0,(e,t)=>r(async(a,r)=>{let{userId:n,tenantId:i,role:o}=a.user;if("Super Admin"===o||"SuperAdmin"===o)return t(a,r);try{let o=await (0,s.default)(`SELECT 1 
         FROM "Users" u
         INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
         INNER JOIN "Permissions" p ON rp."permissionId" = p.id
         WHERE u."userId" = $1 AND p.code = $2 AND (u."tenantId" = $3 OR u."tenantId" IS NULL)
         LIMIT 1`,[n,e,i||null]);if(0===o.rows.length)return r.status(403).json({message:`Forbidden: Missing required permission ${e}`});return t(a,r)}catch(e){return console.error("Permission check error:",e),r.status(500).json({message:"Internal server error during authorization."})}})])},90556,e=>{"use strict";var t=e.i(33534),a=e.i(59016),s=e.i(55334),r=e.i(26175),n=e.i(65058),i=e.i(74606),o=e.i(19477);let l=!1,d=new Map;async function u(e,t){let a=e.headers.origin;if((0,i.setCorsHeaders)(t,a),"OPTIONS"===e.method)return void t.status(200).end();if("GET"!==e.method)return t.setHeader("Allow",["GET","OPTIONS"]),t.status(405).end(`Method ${e.method} Not Allowed`);let{tenantId:s,role:r}=e.user;if(!s&&"Super Admin"!==r)return console.error("[ERROR] tenantId missing in token for non-Super Admin user."),t.status(403).json({message:"Tenant ID missing. Please log in again."});if(!l)try{await (0,n.default)(`
                IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Asset_Details') AND name = 'useful_life')
                    ALTER TABLE "Asset_Details" ADD "useful_life" INT DEFAULT 5;
            `,[]),l=!0}catch(e){console.error("[AUTO-MIGRATION ERROR]",e),l=!0}let o=Math.max(1,parseInt(e.query.page)||1),u=Math.min(1e3,Math.max(1,parseInt(e.query.limit)||50)),p=(o-1)*u,c="true"===e.query.includeMedia,I=e.query.search||"";("undefined"===I||"null"===I)&&(I="");let g=I.trim().length>0;try{let e=String(s||"global"),a=d.get(e)||0,r=Date.now();if(1===o&&r-a>6e4){d.set(e,r);let t=`
                UPDATE "Asset_Details"
                SET status_id = (
                    SELECT TOP 1 id FROM "Status" WHERE status = 'Overdue' AND ("tenantId" = $1 OR "tenantId" IS NULL)
                )
                WHERE status_id = (
                    SELECT TOP 1 id FROM "Status" WHERE status = 'Assigned' AND ("tenantId" = $1 OR "tenantId" IS NULL)
                )
                AND "tenantId" = $1
                AND assigned_to IS NOT NULL
                AND id IN (
                    SELECT "assetId" FROM "Asset_Assignments"
                    WHERE "expected_return_date" < GETDATE()
                      AND "tenantId" = $1
                      AND COALESCE(status, '') <> 'returned'
                      AND "returned_date" IS NULL
                );
            `;(0,n.default)(t,[s]).catch(e=>console.error("[OVERDUE UPDATE ERROR]",e))}let i=`
            SELECT
                a.id,
                a.name AS "assetName",
                a."asset_Id" AS "barcode",
                a."controller_key" AS "controllerKey",
                COALESCE(a."barcodeURL", aa."barcodeURL") AS "barcodeURL",
                a."serial_no" AS "serialNumber",
                a.location,
                a."purchase_date" AS "purchaseDate",
                a.price,
                a.useful_life AS "usefulLife",
                a.salvage_value AS "salvageValue",
                a."warranty_expiry" AS "warrantyExpiry",
                COALESCE(a."photoURL", aa."photoURL") AS "photoURL",
                
                cat.category AS "category",
                s.status AS "status",
                COALESCE(u."fullName", u_aa."fullName") AS "assignedBy",
                COALESCE(assignee."fullName", assignee_aa."fullName") AS "assignedTo",
                
                aa.id AS "assignmentId",
                aa."projectName" AS "projectName",
                aa.assigned_date AS "assignedDate",
                aa.expected_return_date AS "expectedReturnDate",
                aa.returned_date AS "returnedDate",
                COALESCE(aa."operator_employeeId", a.assigned_to) AS "operatorId",
                COALESCE(aa."supervisor_employeeId", a.assigned_by) AS "senderId"

            FROM "Asset_Details" a WITH (NOLOCK)
            LEFT JOIN "Category" cat WITH (NOLOCK) ON a."categoryId" = cat."categoryId"
            LEFT JOIN "Status" s WITH (NOLOCK) ON a.status_id = s.id
            
            OUTER APPLY (
                SELECT TOP 1 * FROM "Asset_Assignments" WITH (NOLOCK)
                WHERE "assetId" = a.id
                  AND (a."tenantId" = $1 OR "tenantId" = $1 OR "tenantId" IS NULL)
                  AND (COALESCE(status, '') <> 'returned')
                ORDER BY id DESC
            ) aa

            LEFT JOIN "Users" u WITH (NOLOCK) ON u."employeeId" = a.assigned_by AND (u."tenantId" = a."tenantId" OR a."tenantId" IS NULL)
            LEFT JOIN "Users" assignee WITH (NOLOCK) ON assignee."employeeId" = a.assigned_to AND (assignee."tenantId" = a."tenantId" OR a."tenantId" IS NULL)
            
            LEFT JOIN "Users" u_aa WITH (NOLOCK) ON u_aa."employeeId" = aa."supervisor_employeeId" AND (u_aa."tenantId" = a."tenantId" OR a."tenantId" IS NULL)
            LEFT JOIN "Users" assignee_aa WITH (NOLOCK) ON assignee_aa."employeeId" = aa."operator_employeeId" AND (assignee_aa."tenantId" = a."tenantId" OR a."tenantId" IS NULL)

            WHERE (a."tenantId" = $1 OR a."tenantId" IS NULL)
            ${g?'AND (a.name LIKE $2 OR a."asset_Id" LIKE $2 OR a."serial_no" LIKE $2)':""}
            ORDER BY a.id ASC
            OFFSET ${p} ROWS FETCH NEXT ${u} ROWS ONLY;
        `,l=`
            SELECT COUNT(*) as total
            FROM "Asset_Details" a WITH (NOLOCK)
            WHERE (a."tenantId" = $1 OR a."tenantId" IS NULL)
            ${g?'AND (a.name LIKE $2 OR a."asset_Id" LIKE $2 OR a."serial_no" LIKE $2)':""};
        `,E=g?`%${I.trim()}%`:null,[m,A]=await Promise.all([(0,n.default)(i,g?[s,E]:[s]),(0,n.default)(l,g?[s,E]:[s])]),O=parseInt(A.rows[0]?.total||"0"),h=Math.ceil(O/u),N=e=>e?c?e:"string"==typeof e&&e.startsWith("data:")?null:e:null,S=m.rows.map(e=>{let t=parseFloat(e.price)||0,a=parseFloat(e.salvageValue)||0,s=parseInt(e.usefulLife)||5,r=t,n=100,i=0,o=null;if(t>0&&s>0&&e.purchaseDate){let l=new Date(e.purchaseDate),d=new Date,u=Math.max(0,(d.getTime()-l.getTime())/315576e5),p=Math.max(0,Math.min((t-a)/s*u,t-a));r=t-p,i=u/s*100,i=Math.min(100,i),(n=Math.max(0,100-i))<60&&(o=`Depreciation alert: remaining life is ${n.toFixed(1)}%. Please scrap or upgrade this asset.`)}return{id:e.id.toString(),assetName:e.assetName,barcode:e.barcode,controllerKey:e.controllerKey||null,serialNumber:e.serialNumber,category:e.category,status:e.status,assignedBy:e.assignedBy||null,assignedTo:e.assignedTo||null,location:(e=>{if(!e||"string"!=typeof e)return"Office";let t=e.trim();return t&&"unassigned"!==t.toLowerCase()&&"null"!==t.toLowerCase()?t:"Office"})(e.location),purchaseDate:e.purchaseDate,warrantyExpiry:e.warrantyExpiry,price:e.price,photoURL:N(e.photoURL),barcodeURL:N(e.barcodeURL),expectedReturnDate:e.expectedReturnDate||null,assignedDate:e.assignedDate||null,returnedDate:e.returnedDate||null,projectName:e.projectName||null,assignmentId:e.assignmentId?e.assignmentId.toString():null,operatorId:e.operatorId?e.operatorId.toString():null,senderId:e.senderId?e.senderId.toString():null,receiverId:e.operatorId?e.operatorId.toString():null,usefulLife:s,salvageValue:e.salvageValue||null,remainingValue:parseFloat(r.toFixed(2)),depreciationMessage:o}});return t.status(200).json({message:"Assets fetched successfully!",count:S.length,total:O,page:o,limit:u,totalPages:h,assets:S})}catch(e){return console.error("Get All Assets Error:",e),t.status(500).json({message:"Internal server error."})}}let p=(0,o.withAuth)(u);e.s(["default",0,p],31350);var c=e.i(31350),I=e.i(8322),g=e.i(84914),E=e.i(83666);let m=(0,r.hoist)(c,"default"),A=(0,r.hoist)(c,"config"),O=new s.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/assets/index",pathname:"/api/assets",bundlePath:"",filename:""},userland:c,distDir:".next",relativeProjectDir:""});async function h(e,a,s){O.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/assets/index";r=r.replace(/\/index$/,"")||"/";let n=await O.prepare(e,a,{srcPage:r});if(!n){a.statusCode=400,a.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:i,params:o,prerenderManifest:l,routerServerContext:d}=n;try{let t=e.method||"GET",s=(0,I.getTracer)(),n=s.getActiveScopeSpan(),u=O.instrumentationOnRequestError.bind(O),p=async n=>O.render(e,a,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:l.preview,propagateError:!1,dev:O.isDev,page:"/api/assets/index",internalRevalidate:null==d?void 0:d.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==g.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${t} ${r}`)});n?await p(n):await s.withPropagatedContext(e.headers,()=>s.trace(g.BaseServerSpan.handleRequest,{spanName:`${t} ${r}`,kind:I.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},p))}catch(e){if(O.isDev)throw e;(0,t.sendError)(a,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,A,"default",0,m,"handler",()=>h],90556)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__b672da7a._.js.map