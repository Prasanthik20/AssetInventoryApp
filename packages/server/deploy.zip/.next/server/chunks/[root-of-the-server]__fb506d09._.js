module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},2305,e=>e.a(async(t,s)=>{try{var a=e.i(65058),r=e.i(74606),n=t([a]);async function i(e,t){let s=e.headers.origin;if((0,r.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();try{if("GET"===e.method){let{id:s,role:r}=e.query,n="string"==typeof r?r.toLowerCase():"",i="",o=[];if(s||n){if(!s||"0"===s)return t.status(200).json([]);i=`
          SELECT
            n.id::text AS "notifId",
            n.reason,
            n.reply,
            n.status,
            n."created_at" AS "createdAt",
            a.name AS "assetName",
            s."fullName" AS "senderName",
            r."roleName" AS "senderRole"
          FROM "Notifications" n
          LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
          LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
          LEFT JOIN "Roles" r ON s."roleId" = r."roleId"
          WHERE n."receiverId" = $1
          ORDER BY n."created_at" DESC;
        `,o=[parseInt(s)]}else i=`
          SELECT
            n.id::text AS "notifId",
            n.reason,
            n.reply,
            n.status,
            n."created_at" AS "createdAt",
            a.name AS "assetName",
            s."fullName" AS "senderName",
            r."roleName" AS "senderRole"
          FROM "Notifications" n
          LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
          LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
          LEFT JOIN "Roles" r ON s."roleId" = r."roleId"
          ORDER BY n."created_at" DESC;
        `;let d=await (0,a.default)(i,o);return t.status(200).json(d.rows)}if("POST"===e.method){let{assetId:s,senderId:r,receiverId:n,reason:i}=e.body;if(!s||!r||!n||!i)return t.status(400).json({message:"Missing required fields"});let o=`
        INSERT INTO "Notifications"
        ("assetId", "senderId", "receiverId", "reason")
        VALUES ($1, $2, $3, $4)
        RETURNING *;
      `,d=[Number(s),Number(r),Number(n),i],l=await (0,a.default)(o,d);return t.status(201).json({message:"Notification sent successfully",notification:l.rows[0]})}return t.status(405).json({message:"Method not allowed"})}catch(e){return console.error("Notifications API Error:",e),t.status(500).json({message:"Internal server error",error:e.message})}}[a]=n.then?(await n)():n,e.s(["default",()=>i]),s()}catch(e){s(e)}},!1),25229,e=>e.a(async(t,s)=>{try{var a=e.i(33534),r=e.i(59016),n=e.i(55334),i=e.i(26175),o=e.i(2305),d=e.i(8322),l=e.i(84914),u=e.i(83666),c=t([o]);[o]=c.then?(await c)():c;let h=(0,i.hoist)(o,"default"),m=(0,i.hoist)(o,"config"),f=new n.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/notifications/index",pathname:"/api/notifications",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,s){f.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/notifications/index";r=r.replace(/\/index$/,"")||"/";let n=await f.prepare(e,t,{srcPage:r});if(!n){t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:i,params:o,prerenderManifest:c,routerServerContext:p}=n;try{let s=e.method||"GET",a=(0,d.getTracer)(),n=a.getActiveScopeSpan(),u=f.instrumentationOnRequestError.bind(f),h=async n=>f.render(e,t,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:f.isDev,page:"/api/notifications/index",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${s} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${s} ${r}`)});n?await h(n):await a.withPropagatedContext(e.headers,()=>a.trace(l.BaseServerSpan.handleRequest,{spanName:`${s} ${r}`,kind:d.SpanKind.SERVER,attributes:{"http.method":s,"http.target":e.url}},h))}catch(e){if(f.isDev)throw e;(0,a.sendError)(t,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,m,"default",0,h,"handler",()=>p]),s()}catch(e){s(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__fb506d09._.js.map