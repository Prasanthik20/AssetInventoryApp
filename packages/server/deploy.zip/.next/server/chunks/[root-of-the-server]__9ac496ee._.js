module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let a=t||"";a.endsWith("/")&&(a=a.slice(0,-1)),a&&(a.includes("localhost")||a.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(a))&&(e.setHeader("Access-Control-Allow-Origin",a),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,a)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let a=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,a,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,a)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),a=e.i(74606);e.s(["withAuth",0,e=>async(s,r)=>{let n=s.headers.origin;if((0,a.setCorsHeaders)(r,n),"OPTIONS"===s.method)return void r.status(200).end();let i=s.headers.authorization;if(!i||!i.startsWith("Bearer "))return r.status(401).json({message:"Authorization token missing or invalid."});let o=i.split(" ")[1],l=(0,t.verifyToken)(o);return l?(s.user=l,e(s,r)):r.status(401).json({message:"Invalid or expired token."})}])},31350,e=>e.a(async(t,a)=>{try{var s=e.i(65058),r=e.i(74606),n=e.i(19477),i=t([s]);async function o(e,t){let a=e.headers.origin;if((0,r.setCorsHeaders)(t,a),"OPTIONS"===e.method)return void t.status(200).end();if("GET"!==e.method)return t.setHeader("Allow",["GET","OPTIONS"]),t.status(405).end(`Method ${e.method} Not Allowed`);let{tenantId:n,role:i}=e.user;if(!n&&"Super Admin"!==i)return console.error("[ERROR] tenantId missing in token for non-Super Admin user."),t.status(403).json({message:"Tenant ID missing. Please log in again."});try{await (0,s.default)(`
            ALTER TABLE "Asset_Details" 
            ADD COLUMN IF NOT EXISTS "useful_life" INT DEFAULT 5,
            ADD COLUMN IF NOT EXISTS "salvage_value" VARCHAR(255);
        `,[])}catch(e){console.error("[AUTO-MIGRATION ERROR]",e)}console.log(`[DEBUG] User Payload: ${JSON.stringify(e.user)}`),console.log(`[DEBUG] Fetching assets for tenantId: "${n}"`);let o=Math.max(1,parseInt(e.query.page)||1),l=Math.min(100,Math.max(1,parseInt(e.query.limit)||50)),d=(o-1)*l,u=e.query.search||"";("undefined"===u||"null"===u)&&(u="");let c=u.trim().length>0;try{let e=`
            UPDATE "Asset_Details"
            SET status_id = (
                SELECT id FROM "Status" WHERE status = 'Overdue' AND ("tenantId" = $1 OR "tenantId" IS NULL) LIMIT 1
            )
            WHERE status_id = (
                SELECT id FROM "Status" WHERE status = 'Assigned' AND ("tenantId" = $1 OR "tenantId" IS NULL) LIMIT 1
            )
            AND "tenantId" = $1
            AND assigned_to IS NOT NULL
            AND id IN (
                SELECT "assetId" FROM "Asset_Assignments"
                WHERE "expected_return_date" < CURRENT_DATE
                  AND "tenantId" = $1
                  AND COALESCE(status, '') <> 'returned'
                  AND "returned_date" IS NULL
            );
        `;await (0,s.default)(e,[n]);let a=`
            SELECT
                a.id,
                a.name AS "assetName",
                a."asset_Id" AS "barcode",
                a."controller_key" AS "controllerKey",
                COALESCE(a."barcodeURL", aa."barcodeURL") AS "barcodeURL",
                a."serial_no" AS "serialNumber",
                a.location,
                a."purchase_date" AS "purchaseDate",
                a.price,
                a.useful_life AS "usefulLife",
                a.salvage_value AS "salvageValue",
                a."warranty_expiry" AS "warrantyExpiry",
                COALESCE(a."photoURL", aa."photoURL") AS "photoURL",
                
                cat.category AS "category",
                s.status AS "status",
                u."fullName" AS "assignedBy",
                assignee."fullName" AS "assignedTo",
                
                aa.id AS "assignmentId",
                aa."projectName" AS "projectName",
                aa.expected_return_date AS "expectedReturnDate",
                aa."operator_employeeId" AS "operatorId",
                aa."supervisor_employeeId" AS "senderId"

            FROM "Asset_Details" a
            LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
            LEFT JOIN "Status" s ON a.status_id = s.id
            LEFT JOIN "Users" u ON a.assigned_by = u."employeeId"
            LEFT JOIN "Users" assignee ON a.assigned_to = assignee."employeeId"
            
            LEFT JOIN LATERAL (
                SELECT * FROM "Asset_Assignments"
                WHERE "assetId" = a.id
                  AND ("tenantId" = $1 OR $1 IS NULL)
                  AND COALESCE(status, '') <> 'returned'
                  AND "returned_date" IS NULL
                ORDER BY id DESC
                LIMIT 1
            ) aa ON TRUE
            WHERE (a."tenantId" = $1 OR $1 IS NULL)
            ${c?'AND (a.name ILIKE $2 OR a."asset_Id" ILIKE $2 OR a."serial_no" ILIKE $2)':""}
            ORDER BY a.id ASC
            LIMIT $${c?3:2} OFFSET $${c?4:3};
        `,r=`
            SELECT COUNT(*) as total
            FROM "Asset_Details" a
            WHERE (a."tenantId" = $1 OR $1 IS NULL)
            ${c?'AND (a.name ILIKE $2 OR a."asset_Id" ILIKE $2 OR a."serial_no" ILIKE $2)':""};
        `,i=c?`%${u.trim()}%`:null,[p,h]=await Promise.all([(0,s.default)(a,c?[n,i,l,d]:[n,l,d]),(0,s.default)(r,c?[n,i]:[n])]),I=parseInt(h.rows[0]?.total||"0");console.log(`[DEBUG] Query results: MainRows=${p.rows.length}, TotalCount=${I}`);let g=Math.ceil(I/l),A=p.rows.map(e=>{let t=parseFloat(e.price)||0,a=parseFloat(e.salvageValue)||0,s=parseInt(e.usefulLife)||5,r=t,n=100,i=0,o=null;if(t>0&&s>0&&e.purchaseDate){let l=new Date(e.purchaseDate),d=new Date,u=Math.max(0,(d.getTime()-l.getTime())/315576e5),c=Math.max(0,Math.min((t-a)/s*u,t-a));r=t-c,i=u/s*100,i=Math.min(100,i),(n=Math.max(0,100-i))<60&&(o=`Depreciation alert: remaining life is ${n.toFixed(1)}%. Please scrap or upgrade this asset.`)}return{id:e.id.toString(),assetName:e.assetName,barcode:e.barcode,controllerKey:e.controllerKey||null,serialNumber:e.serialNumber,category:e.category,status:e.status,assignedBy:e.assignedBy||null,assignedTo:e.assignedTo||null,location:e.location,purchaseDate:e.purchaseDate,warrantyExpiry:e.warrantyExpiry,price:e.price,photoURL:e.photoURL||null,barcodeURL:e.barcodeURL||null,expectedReturnDate:e.expectedReturnDate||null,projectName:e.projectName||null,assignmentId:e.assignmentId?e.assignmentId.toString():null,operatorId:e.operatorId?e.operatorId.toString():null,senderId:e.senderId?e.senderId.toString():null,receiverId:e.operatorId?e.operatorId.toString():null,usefulLife:s,salvageValue:e.salvageValue||null,remainingValue:parseFloat(r.toFixed(2)),depreciationMessage:o}});return t.status(200).json({message:"Assets fetched successfully!",count:A.length,total:I,page:o,limit:l,totalPages:g,assets:A})}catch(e){return console.error("Get All Assets Error:",e),t.status(500).json({message:"Internal server error."})}}[s]=i.then?(await i)():i;let l=(0,n.withAuth)(o);e.s(["default",0,l]),a()}catch(e){a(e)}},!1),90556,e=>e.a(async(t,a)=>{try{var s=e.i(33534),r=e.i(59016),n=e.i(55334),i=e.i(26175),o=e.i(31350),l=e.i(8322),d=e.i(84914),u=e.i(83666),c=t([o]);[o]=c.then?(await c)():c;let h=(0,i.hoist)(o,"default"),I=(0,i.hoist)(o,"config"),g=new n.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/assets/index",pathname:"/api/assets",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,a){g.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/assets/index";r=r.replace(/\/index$/,"")||"/";let n=await g.prepare(e,t,{srcPage:r});if(!n){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:i,params:o,prerenderManifest:c,routerServerContext:p}=n;try{let a=e.method||"GET",s=(0,l.getTracer)(),n=s.getActiveScopeSpan(),u=g.instrumentationOnRequestError.bind(g),h=async n=>g.render(e,t,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:g.isDev,page:"/api/assets/index",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${a} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${a} ${r}`)});n?await h(n):await s.withPropagatedContext(e.headers,()=>s.trace(d.BaseServerSpan.handleRequest,{spanName:`${a} ${r}`,kind:l.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},h))}catch(e){if(g.isDev)throw e;(0,s.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,I,"default",0,h,"handler",()=>p]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__9ac496ee._.js.map