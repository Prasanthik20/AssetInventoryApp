module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},27677,e=>e.a(async(t,s)=>{try{var a=e.i(65058),n=e.i(74606),i=t([a]);async function r(e,t){let s=e.headers.origin;if((0,n.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();if("GET"!==e.method)return t.setHeader("Allow",["GET","OPTIONS"]),t.status(405).end(`Method ${e.method} Not Allowed`);try{let s=new URL(e.url||"","http://localhost").searchParams.get("id"),n=e.query.id,i=["admin","supervisor","operator"].includes(n?.toLowerCase()),r=e.query.role||(i?n.toLowerCase():null),o=s||(i?null:n);if(!o)return t.status(400).json({message:"Valid numeric receiver ID is required."});let d=parseInt(o,10);if(isNaN(d))return t.status(400).json({message:"Valid numeric receiver ID is required."});let l="",c="",u=[];"operator"===r&&(c="AND n.reply IS NULL"),console.log(r),"admin"===r?(l=`
        SELECT
          n.id AS "notificationId",
          n."assignmentId",
          n.reason,
          n.reply,
          n.status AS "notificationStatus",
          n.created_at AS "createdAt",

          a.id AS "assetId",
          a.name AS "assetName",

          s."employeeId" AS "senderEmployeeId",
          s."fullName" AS "senderName"
        FROM "Notifications" n
        LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
        LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
        ORDER BY n.created_at DESC;
      `,u=[]):(l=`
        SELECT
          n.id AS "notificationId",
          n."assignmentId",
          n.reason,
          n.reply,
          n.status AS "notificationStatus",
          n.created_at AS "createdAt",

          a.id AS "assetId",
          a.name AS "assetName",

          s."employeeId" AS "senderEmployeeId",
          s."fullName" AS "senderName"
        FROM "Notifications" n
        LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
        LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
        WHERE n."receiverId" = $1
        ${c}
        ORDER BY n.created_at DESC;
      `,u=[d]);let p=await (0,a.default)(l,u);console.log(p);let m=p.rows.map(e=>({id:e.notificationId,notificationId:e.notificationId,assignmentId:e.assignmentId,reason:e.reason,reply:e.reply,status:e.notificationStatus,createdAt:e.createdAt,asset:{id:e.assetId,name:e.assetName},sender:{employeeId:e.senderEmployeeId,name:e.senderName}}));return t.status(200).json({count:m.length,notifications:m})}catch(e){return console.error("GET /notifications/[id] error:",e),t.status(500).json({message:"Internal server error"})}}[a]=i.then?(await i)():i,e.s(["default",()=>r]),s()}catch(e){s(e)}},!1),43366,e=>e.a(async(t,s)=>{try{var a=e.i(33534),n=e.i(59016),i=e.i(55334),r=e.i(26175),o=e.i(27677),d=e.i(8322),l=e.i(84914),c=e.i(83666),u=t([o]);[o]=u.then?(await u)():u;let m=(0,r.hoist)(o,"default"),h=(0,r.hoist)(o,"config"),f=new i.PagesAPIRouteModule({definition:{kind:n.RouteKind.PAGES_API,page:"/api/notifications/[id]",pathname:"/api/notifications/[id]",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,s){f.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/notifications/[id]";n=n.replace(/\/index$/,"")||"/";let i=await f.prepare(e,t,{srcPage:n});if(!i){t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:r,params:o,prerenderManifest:u,routerServerContext:p}=i;try{let s=e.method||"GET",a=(0,d.getTracer)(),i=a.getActiveScopeSpan(),c=f.instrumentationOnRequestError.bind(f),m=async i=>f.render(e,t,{query:{...r,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:u.preview,propagateError:!1,dev:f.isDev,page:"/api/notifications/[id]",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>c(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=e.get("next.route");if(r){let e=`${s} ${r}`;i.setAttributes({"next.route":r,"http.route":r,"next.span_name":e}),i.updateName(e)}else i.updateName(`${s} ${n}`)});i?await m(i):await a.withPropagatedContext(e.headers,()=>a.trace(l.BaseServerSpan.handleRequest,{spanName:`${s} ${n}`,kind:d.SpanKind.SERVER,attributes:{"http.method":s,"http.target":e.url}},m))}catch(e){if(f.isDev)throw e;(0,a.sendError)(t,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,h,"default",0,m,"handler",()=>p]),s()}catch(e){s(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__0c48704f._.js.map