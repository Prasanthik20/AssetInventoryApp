module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let r=t||"";r.endsWith("/")&&(r=r.slice(0,-1)),r&&(r.includes("localhost")||r.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(r))&&(e.setHeader("Access-Control-Allow-Origin",r),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},51565,e=>{"use strict";var t=e.i(65058),r=e.i(74606);async function s(e,s){let a=e.headers.origin;if((0,r.setCorsHeaders)(s,a),"OPTIONS"===e.method)return void s.status(200).end();if("POST"!==e.method)return s.status(405).end();try{let r=(...e)=>{for(let t of e){if(Array.isArray(t)){let e=t.map(e=>"string"==typeof e?e.trim():"").filter(e=>e.length>0);if(e.length>0)return e}if("string"==typeof t&&t.trim().length>0)return[t.trim()]}return[]},a=(...e)=>r(...e)[0],o=async(e,r)=>{if(!Number.isFinite(e))throw Error(`Invalid ${r} id`);let s=await (0,t.default)(`SELECT "employeeId"
                 FROM "Users"
                 WHERE "employeeId" = $1
                 LIMIT 1`,[e]),a=Number(s.rows[0]?.employeeId);if(Number.isFinite(a))return a;let o=await (0,t.default)(`SELECT "employeeId"
                 FROM "Users"
                 WHERE "userId" = $1
                 LIMIT 1`,[e]),i=Number(o.rows[0]?.employeeId);if(!Number.isFinite(i))throw Error(`Unable to resolve ${r} employee id`);return i},i=async e=>{let r=await (0,t.default)(`SELECT "fullName"
                 FROM "Users"
                 WHERE "employeeId" = $1
                 LIMIT 1`,[e]);return String(r.rows[0]?.fullName||e)},n=async()=>{let e=await (0,t.default)(`SELECT DISTINCT u."employeeId"
                 FROM "Users" u
                 INNER JOIN "Role_Permissions" rp ON u."roleId" = rp."roleId"
                 INNER JOIN "Permissions" p ON rp."permissionId" = p.id
                 WHERE p.code IN ('MANAGE_USERS', 'MANAGE_WORKFLOWS')`,[]);return 0===e.rows.length&&(e=await (0,t.default)(`SELECT DISTINCT u."employeeId"
                     FROM "Users" u
                     INNER JOIN "Roles" r ON u."roleId" = r."roleId"
                     WHERE LOWER(r."roleName") IN ('admin', 'super admin', 'superadmin', 'tenant admin', 'tenantadmin')`,[])),e.rows.map(e=>Number(e.employeeId)).filter(e=>Number.isFinite(e))},d=async(e,r,s,a,o,i,n)=>{await (0,t.default)(`INSERT INTO "Notifications"
                 ("assetId", "assignmentId", "senderId", "receiverId", "reason", "reply", "status", "created_at", "tenantId")
                 VALUES ($1, $2, $3, $4, $5, $6, 'unread', NOW(), $7)`,[e,r,s,a,o,i??null,n??null])},{assetIds:l,operatorEmployeeId:u,userEmployeeId:p,photoURL:E,barcodeURL:m,assetMedia:c,assignmentIds:I}=e.body;if(!Array.isArray(l)||0===l.length)return s.status(400).json({message:"assetIds required"});let R=Number(p||u);if(!Number.isFinite(R))return s.status(400).json({message:"userEmployeeId required"});let f=await o(R,"user"),N=await i(f),h=await (0,t.default)('SELECT "tenantId" FROM "Users" WHERE "employeeId" = $1 LIMIT 1',[f]),w=h.rows[0]?.tenantId||null,g=await n(),A=new Set(g),S=l.map(Number),b=new Map;Array.isArray(I)&&I.forEach((e,t)=>{let r=Number(e),s=Number(S[t]);Number.isFinite(r)&&Number.isFinite(s)&&b.set(s,r)});let L=new Map,$=r(e.body?.photoURLs,e.body?.photos,E,e.body?.photoUrl,e.body?.image),y=r(e.body?.barcodeURLs,e.body?.barcodes,m,e.body?.barcodeUrl,e.body?.barcodeImage,e.body?.barcode_image);if(Array.isArray(c))for(let e of c){let t=Number(e?.assetId);if(!Number.isFinite(t))continue;let s=Number(e?.assignmentId);Number.isFinite(s)&&b.set(t,s);let a=r(e?.photoURLs,e?.photos,e?.photoURL,e?.photoUrl,e?.photo,e?.image),o=r(e?.barcodeURLs,e?.barcodes,e?.barcodeURL,e?.barcodeUrl,e?.barcodeImage,e?.barcode_image);L.set(t,{photoURL:a[0],barcodeURL:o[0]})}let T=await (0,t.default)(`SELECT id, name FROM "Approval_Workflows" 
             WHERE "tenantId" = $1 AND "actionType" = 'RETURN' AND "isActive" = true 
             LIMIT 1`,[w]);if(T.rows.length>0){let e=T.rows[0].id,r=T.rows[0].name;for(let r of S){let s=L.get(r)||{photoURL:a($,E),barcodeURL:a(y,m)};if((await (0,t.default)(`SELECT id FROM "Approval_Requests" 
                     WHERE "assetId" = $1 AND status = 'PENDING' LIMIT 1`,[r])).rows.length>0)continue;let o=await (0,t.default)('SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM "Approval_Requests"',[]),i=Number(o.rows[0]?.next_id||1);await (0,t.default)(`INSERT INTO "Approval_Requests"
                     ("id", "tenantId", "assetId", "workflowId", "currentStepSequence", "status", "requestedById", "payload", "createdAt", "updatedAt")
                     VALUES ($1, $2, $3, $4, 1, 'PENDING', $5, $6, GETDATE(), GETDATE())`,[i,w,r,e,f,JSON.stringify({photoURL:s.photoURL||null,barcodeURL:s.barcodeURL||null})]);let n=await (0,t.default)(`SELECT "stepSequence", "approverRoleId" FROM "Approval_Workflow_Steps"
                     WHERE "workflowId" = $1 ORDER BY "stepSequence" ASC`,[e]),d=await (0,t.default)('SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM "Approval_Request_Steps"',[]),l=Number(d.rows[0]?.next_id||1);for(let e of n.rows)await (0,t.default)(`INSERT INTO "Approval_Request_Steps"
                         ("id", "requestId", "stepSequence", "approverRoleId", "status")
                         VALUES ($1, $2, $3, $4, 'PENDING')`,[l++,i,e.stepSequence,e.approverRoleId]);let u=n.rows[0].approverRoleId,p=(await (0,t.default)('SELECT "employeeId" FROM "Users" WHERE "roleId" = $1 AND "tenantId" = $2',[u,w])).rows.map(e=>Number(e.employeeId)),c={kind:"workflow_approval_pending",requestId:i.toString(),actionType:"RETURN",stepSequence:1,message:`Pending return approval step 1 for asset ${r}.`};for(let e of p)await (0,t.default)(`INSERT INTO "Notifications"
                         ("assetId", "assignmentId", "senderId", "receiverId", "reason", "reply", "status", "tenantId")
                         VALUES ($1, NULL, $2, $3, $4, $5, 'unread', $6)`,[r,f,e,`New return approval request submitted by ${N}.`,JSON.stringify(c),w])}return s.status(200).json({message:`Return requests submitted for approval via workflow: ${r}.`,pendingApproval:!0})}for(let e of S){let r=L.get(e)||{photoURL:a($,E),barcodeURL:a(y,m)},s=b.get(e),n=await (0,t.default)(`
                UPDATE "Asset_Assignments"
                SET 
                    "status" = 'returned',
                    "returned_date" = GETDATE(),
                    "photoURL" = COALESCE($3, "photoURL"),
                    "barcodeURL" = COALESCE($4, "barcodeURL"),
                    "serialNoVerified" = 1,
                    "tenantId" = COALESCE("tenantId", $6)
                OUTPUT INSERTED.id, INSERTED.supervisor_employeeId
                WHERE id = COALESCE($5, (
                    SELECT TOP 1 id
                    FROM "Asset_Assignments"
                    WHERE "operator_employeeId" = $1
                      AND "assetId" = $2
                      AND COALESCE("status", '') <> 'returned'
                      AND "returned_date" IS NULL
                    ORDER BY "assigned_date" DESC, id DESC
                ))
                    AND "operator_employeeId" = $1
                    AND "assetId" = $2
                    AND COALESCE("status", '') <> 'returned'
                `,[f,e,r.photoURL??null,r.barcodeURL??null,Number.isFinite(s)?Number(s):null,w]);if(0===n.rows.length){console.warn(`No active assignment found for user ${f} and asset ${e}`);continue}let l=Number(n.rows[0]?.id),u=await o(Number(n.rows[0]?.supervisor_employeeId),"manager"),p=await i(u),c=["assigned_to = $2","assigned_by = $2",`status_id = (
                    SELECT TOP 1 id FROM "Status" 
                    WHERE status LIKE 'Assigned' 
                )`],I=[e,u];r.photoURL&&(c.push(`"photoURL" = $${I.length+1}`),I.push(r.photoURL)),r.barcodeURL&&(c.push(`"barcodeURL" = $${I.length+1}`),I.push(r.barcodeURL)),await (0,t.default)(`
                UPDATE "Asset_Details"
                SET ${c.join(", ")}
                WHERE id = $1
                `,I);let R=await (0,t.default)('SELECT "reportingTo" FROM "Users" WHERE "employeeId" = $1 AND ("tenantId" = $2 OR $2 IS NULL) LIMIT 1',[f,w]),h=Number(R.rows[0]?.reportingTo);for(let t of new Set([...g,u,...Number.isFinite(h)&&h>0?[h]:[]])){if(!Number.isFinite(t))continue;let r=`Asset ${e} has been returned by ${N}.`,s=A.has(t)?`Return pending confirmation: Asset ${e} was returned by ${N} and is now with ${p}.`:`Return pending confirmation: ${N} returned asset ${e}. Please confirm final return.`,a={kind:"return_notification",message:s,tenantId:w,returnedDate:new Date().toISOString()};await d(e,l,f,t,r,JSON.stringify(a),w)}}return s.status(200).json({message:"Assets returned and moved to manager pending confirmation"})}catch(e){return console.error(e),s.status(500).json({message:"Server error"})}}e.s(["config",0,{api:{bodyParser:{sizeLimit:"50mb"}}},"default",()=>s])},63421,e=>{"use strict";var t=e.i(33534),r=e.i(59016),s=e.i(55334),a=e.i(26175),o=e.i(51565),i=e.i(8322),n=e.i(84914),d=e.i(83666);let l=(0,a.hoist)(o,"default"),u=(0,a.hoist)(o,"config"),p=new s.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/user/return-asset",pathname:"/api/user/return-asset",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function E(e,r,s){p.isDev&&(0,d.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/user/return-asset";a=a.replace(/\/index$/,"")||"/";let o=await p.prepare(e,r,{srcPage:a});if(!o){r.statusCode=400,r.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:l,params:u,prerenderManifest:E,routerServerContext:m}=o;try{let t=e.method||"GET",s=(0,i.getTracer)(),o=s.getActiveScopeSpan(),d=p.instrumentationOnRequestError.bind(p),c=async o=>p.render(e,r,{query:{...l,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:E.preview,propagateError:!1,dev:p.isDev,page:"/api/user/return-asset",internalRevalidate:null==m?void 0:m.revalidate,onError:(...t)=>d(e,...t)}).finally(()=>{if(!o)return;o.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==n.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;o.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),o.updateName(e)}else o.updateName(`${t} ${a}`)});o?await c(o):await s.withPropagatedContext(e.headers,()=>s.trace(n.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:i.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},c))}catch(e){if(p.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,u,"default",0,l,"handler",()=>E])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__7dfd957e._.js.map