module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let a=t||"";a.endsWith("/")&&(a=a.slice(0,-1)),a&&(a.includes("localhost")||a.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(a))&&(e.setHeader("Access-Control-Allow-Origin",a),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,a)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let a=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,a,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,a)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),a=e.i(74606);e.s(["withAuth",0,e=>async(r,s)=>{let n=r.headers.origin;if((0,a.setCorsHeaders)(s,n),"OPTIONS"===r.method)return void s.status(200).end();let i=r.headers.authorization;if(!i||!i.startsWith("Bearer "))return s.status(401).json({message:"Authorization token missing or invalid."});let o=i.split(" ")[1],d=(0,t.verifyToken)(o);return d?(r.user=d,e(r,s)):s.status(401).json({message:"Invalid or expired token."})}])},54799,(e,t,a)=>{t.exports=e.x("crypto",()=>require("crypto"))},94676,e=>e.a(async(t,a)=>{try{var r=e.i(65058),s=e.i(19477),n=t([r]);async function i(t,a){if("Super Admin"!==t.user.role)return a.status(403).json({message:"Access denied. Super Admin privileges required."});if("GET"===t.method)try{let e=`
        SELECT 
          t.id, 
          t.name, 
          t.status, 
          t."organizationType",
          t."createdAt",
          COALESCE(sub.name, 'No active plan') AS "planName",
          COALESCE(sub.plan_id, 'free-trial') AS "planId",
          sub."startDate",
          sub."endDate",
          admin."fullName" AS "adminName",
          admin.email AS "adminEmail",
          admin."phoneNumber" AS "adminPhone",
          admin.address AS "adminAddress",
          (SELECT COUNT(*)::int FROM "Asset_Details" WHERE "tenantId" = t.id) AS "assetsCount"
        FROM 
          "Tenants" t
        LEFT JOIN LATERAL (
          SELECT p.name, p.id AS plan_id, s."startDate", s."endDate"
          FROM "Subscriptions" s
          JOIN "Plans" p ON s."planId" = p.id
          WHERE s."tenantId" = t.id
          ORDER BY s."updatedAt" DESC
          LIMIT 1
        ) sub ON TRUE
        LEFT JOIN LATERAL (
          SELECT u."fullName", u.email, u."phoneNumber", u.address
          FROM "Users" u
          JOIN "Roles" r ON u."roleId" = r."roleId"
          WHERE u."tenantId" = t.id AND (r."roleName" = 'Admin' OR r."roleName" = 'Super Admin' OR r."roleName" = 'superadmin' OR r."roleName" = 'admin' OR r."roleName" = 'Tenant Admin' OR r."roleName" = 'tenant admin')
          ORDER BY u."userId" ASC
          LIMIT 1
        ) admin ON TRUE
        ORDER BY 
          t."createdAt" DESC;
      `,t=await (0,r.default)(e);return console.log(t.rows),a.status(200).json({count:t.rows.length,tenants:t.rows})}catch(e){return console.error("Super Admin Fetch Tenants Error:",e),a.status(500).json({message:"An internal server error occurred."})}if("PUT"===t.method){let s,{tenantId:n,status:i,planId:o}=t.body;if(!n||!i||!o)return a.status(400).json({message:"Tenant ID, status, and target plan ID are required."});try{s=await r.pool.connect(),await s.query("BEGIN"),await s.query('UPDATE "Tenants" SET status = $1, "updatedAt" = NOW() WHERE id = $2',[i,n]);let t=await s.query('SELECT id FROM "Subscriptions" WHERE "tenantId" = $1 ORDER BY "createdAt" DESC LIMIT 1',[n]),d="active"===i?"active":"expired"===i?"expired":"canceled";if(t.rows.length>0)await s.query(`UPDATE "Subscriptions" 
           SET "planId" = $1, status = $2, "updatedAt" = NOW() 
           WHERE id = $3`,[o,d,t.rows[0].id]);else{let t=e.r(54799).randomUUID(),a=new Date(Date.now()+2592e6);await s.query(`INSERT INTO "Subscriptions" (id, "tenantId", "planId", "startDate", "endDate", status, "createdAt", "updatedAt")
           VALUES ($1, $2, $3, NOW(), $4, $5, NOW(), NOW())`,[t,n,o,a.toISOString(),d])}return await s.query("COMMIT"),a.status(200).json({success:!0,message:"Tenant profile, status, and subscription updated successfully!"})}catch(e){return s&&await s.query("ROLLBACK"),console.error("Super Admin Update Tenant Error:",e),a.status(500).json({message:"An internal server error occurred during transaction processing."})}finally{s&&s.release()}}return a.setHeader("Allow",["GET","PUT"]),a.status(405).json({message:`Method ${t.method} Not Allowed`})}[r]=n.then?(await n)():n;let o=(0,s.withAuth)(i);e.s(["default",0,o]),a()}catch(e){a(e)}},!1),39732,e=>e.a(async(t,a)=>{try{var r=e.i(33534),s=e.i(59016),n=e.i(55334),i=e.i(26175),o=e.i(94676),d=e.i(8322),u=e.i(84914),l=e.i(83666),p=t([o]);[o]=p.then?(await p)():p;let m=(0,i.hoist)(o,"default"),h=(0,i.hoist)(o,"config"),E=new n.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/superadmin/tenants",pathname:"/api/superadmin/tenants",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function c(e,t,a){E.isDev&&(0,l.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let s="/api/superadmin/tenants";s=s.replace(/\/index$/,"")||"/";let n=await E.prepare(e,t,{srcPage:s});if(!n){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:i,params:o,prerenderManifest:p,routerServerContext:c}=n;try{let a=e.method||"GET",r=(0,d.getTracer)(),n=r.getActiveScopeSpan(),l=E.instrumentationOnRequestError.bind(E),m=async n=>E.render(e,t,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:E.isDev,page:"/api/superadmin/tenants",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>l(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${a} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${a} ${s}`)});n?await m(n):await r.withPropagatedContext(e.headers,()=>r.trace(u.BaseServerSpan.handleRequest,{spanName:`${a} ${s}`,kind:d.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},m))}catch(e){if(E.isDev)throw e;(0,r.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,h,"default",0,m,"handler",()=>c]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__7dab13b6._.js.map