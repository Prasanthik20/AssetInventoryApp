module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},25229,e=>{"use strict";var t=e.i(33534),s=e.i(59016),r=e.i(55334),a=e.i(26175),n=e.i(65058),i=e.i(74606);async function o(e,t){let s=e.headers.origin;if((0,i.setCorsHeaders)(t,s),"OPTIONS"===e.method)return void t.status(200).end();try{if("GET"===e.method){let{id:s,role:r}=e.query,a="string"==typeof r?r.toLowerCase():"",i="",o=[];if(s||a){if(!s||"0"===s)return t.status(200).json([]);i=`
          SELECT
            n.id::text AS "notifId",
            n.reason,
            n.reply,
            n.status,
            n."created_at" AS "createdAt",
            a.name AS "assetName",
            s."fullName" AS "senderName",
            r."roleName" AS "senderRole"
          FROM "Notifications" n
          LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
          LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
          LEFT JOIN "Roles" r ON s."roleId" = r."roleId"
          WHERE n."receiverId" = $1
          ORDER BY n."created_at" DESC;
        `,o=[parseInt(s)]}else i=`
          SELECT
            n.id::text AS "notifId",
            n.reason,
            n.reply,
            n.status,
            n."created_at" AS "createdAt",
            a.name AS "assetName",
            s."fullName" AS "senderName",
            r."roleName" AS "senderRole"
          FROM "Notifications" n
          LEFT JOIN "Asset_Details" a ON n."assetId" = a.id
          LEFT JOIN "Users" s ON n."senderId" = s."employeeId"
          LEFT JOIN "Roles" r ON s."roleId" = r."roleId"
          ORDER BY n."created_at" DESC;
        `;let d=await (0,n.default)(i,o);return t.status(200).json(d.rows)}if("POST"===e.method){let{assetId:s,senderId:r,receiverId:a,reason:i}=e.body;if(!s||!r||!a||!i)return t.status(400).json({message:"Missing required fields"});let o=`
        INSERT INTO "Notifications"
        ("assetId", "senderId", "receiverId", "reason")
        VALUES ($1, $2, $3, $4)
        RETURNING *;
      `,d=[Number(s),Number(r),Number(a),i],l=await (0,n.default)(o,d);return t.status(201).json({message:"Notification sent successfully",notification:l.rows[0]})}return t.status(405).json({message:"Method not allowed"})}catch(e){return console.error("Notifications API Error:",e),t.status(500).json({message:"Internal server error",error:e.message})}}e.s(["default",()=>o],2305);var d=e.i(2305),l=e.i(8322),u=e.i(84914),c=e.i(83666);let p=(0,a.hoist)(d,"default"),h=(0,a.hoist)(d,"config"),m=new r.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/notifications/index",pathname:"/api/notifications",bundlePath:"",filename:""},userland:d,distDir:".next",relativeProjectDir:""});async function f(e,s,r){m.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/notifications/index";a=a.replace(/\/index$/,"")||"/";let n=await m.prepare(e,s,{srcPage:a});if(!n){s.statusCode=400,s.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:i,params:o,prerenderManifest:d,routerServerContext:p}=n;try{let t=e.method||"GET",r=(0,l.getTracer)(),n=r.getActiveScopeSpan(),c=m.instrumentationOnRequestError.bind(m),h=async n=>m.render(e,s,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:d.preview,propagateError:!1,dev:m.isDev,page:"/api/notifications/index",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>c(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${t} ${a}`)});n?await h(n):await r.withPropagatedContext(e.headers,()=>r.trace(u.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:l.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},h))}catch(e){if(m.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,h,"default",0,p,"handler",()=>f],25229)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__4fb19984._.js.map