module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,s)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let s=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,s,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,s)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),s=e.i(74606);e.s(["withAuth",0,e=>async(r,a)=>{let i=r.headers.origin;if((0,s.setCorsHeaders)(a,i),"OPTIONS"===r.method)return void a.status(200).end();let n=r.headers.authorization;if(!n||!n.startsWith("Bearer "))return a.status(401).json({message:"Authorization token missing or invalid."});let o=n.split(" ")[1],u=(0,t.verifyToken)(o);return u?(r.user=u,e(r,a)):a.status(401).json({message:"Invalid or expired token."})}])},38503,e=>e.a(async(t,s)=>{try{var r=e.i(65058),a=e.i(19477),i=t([r]);[r]=i.then?(await i)():i;let u=!1;async function n(){if(!u)try{await (0,r.default)(`
      ALTER TABLE "Plans" 
      ADD COLUMN IF NOT EXISTS min_users INT DEFAULT 1,
      ADD COLUMN IF NOT EXISTS min_assets INT DEFAULT 1;
    `);let e=`
      INSERT INTO "Plans" (
        id, 
        name, 
        min_users, 
        "maxUsers", 
        min_assets, 
        "maxAssets", 
        price, 
        currency, 
        features,
        "createdAt"
      ) VALUES 
      (
        'free-trial', 
        'Free Trial', 
        1, 
        5, 
        1, 
        100, 
        0.00, 
        'INR', 
        '{"qrCode": false, "reports": "basic", "storage": "2GB", "support": "email", "apiAccess": false, "dashboard": "basic", "trialDays": 30, "customCategories": false}',
        '2026-05-14T02:36:33.002Z'
      ),
      (
        'starter', 
        'Starter', 
        6, 
        25, 
        101, 
        2500, 
        4999.00, 
        'INR', 
        '{"qrCode": true, "reports": "standard", "storage": "25GB", "support": "email", "apiAccess": false, "yearlyPrice": 59988, "customCategories": false, "emailNotifications": true}',
        '2026-05-14T02:36:33.002Z'
      ),
      (
        'professional', 
        'Professional', 
        26, 
        100, 
        2501, 
        25000, 
        14999.00, 
        'INR', 
        '{"qrCode": true, "reports": "advanced", "storage": "100GB", "support": "priority", "apiAccess": true, "auditLogs": true, "yearlyPrice": 179988, "dynamicFields": true, "roleManagement": true, "customCategories": true, "emailNotifications": true}',
        '2026-05-14T02:36:33.002Z'
      ),
      (
        'enterprise', 
        'Enterprise Plan', 
        101, 
        999999, 
        25001, 
        999999, 
        -1.00, 
        'INR', 
        '{"sla": true, "sso": true, "qrCode": true, "reports": "advanced", "storage": "Unlimited", "support": "dedicated", "apiAccess": true, "auditLogs": true, "dedicatedDB": true, "multiBranch": true, "customPricing": true, "dynamicFields": true, "whiteLabeling": true, "roleManagement": true, "customCategories": true, "customIntegrations": true, "emailNotifications": true}',
        '2026-05-14T02:18:07.300Z'
      ),
      (
        'enterprise-demo', 
        'Enterprise (Demo)', 
        1, 
        999, 
        1, 
        999999, 
        0.00, 
        'INR', 
        NULL,
        '2026-06-13T00:26:34.959Z'
      )
      ON CONFLICT (id) 
      DO UPDATE SET 
        name = EXCLUDED.name,
        min_users = EXCLUDED.min_users,
        "maxUsers" = EXCLUDED."maxUsers",
        min_assets = EXCLUDED.min_assets,
        "maxAssets" = EXCLUDED."maxAssets",
        price = EXCLUDED.price,
        currency = EXCLUDED.currency,
        features = EXCLUDED.features,
        "createdAt" = EXCLUDED."createdAt";
    `;await (0,r.default)(e),u=!0,console.log("Postgres plans schema auto-migration and seeding succeeded.")}catch(e){console.error("ensureDatabaseSchema plans migration error:",e)}}async function o(e,t){if(await n(),"GET"===e.method){if(!["Super Admin","Tenant Admin","Admin"].includes(e.user.role))return t.status(403).json({message:"Access denied. Privileged role required to view plans."})}else if("Super Admin"!==e.user.role)return t.status(403).json({message:"Access denied. Super Admin privileges required."});if("GET"===e.method)try{let e=await (0,r.default)('SELECT * FROM "Plans" ORDER BY price ASC');return t.status(200).json({count:e.rows.length,plans:e.rows})}catch(e){return console.error("Fetch Plans Error:",e),t.status(500).json({message:"An internal server error occurred."})}if("POST"===e.method){let{id:s,name:a,minUsers:i,maxUsers:n,minAssets:o,maxAssets:u,price:l,currency:d,features:c}=e.body;if(!s||!a||void 0===n||void 0===u||void 0===l)return t.status(400).json({message:"Plan Identifier (id), name, maximum users, maximum assets, and price are required."});try{let e=`
        INSERT INTO "Plans" (id, name, min_users, "maxUsers", min_assets, "maxAssets", price, currency, features, "createdAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb, NOW())
        ON CONFLICT (id) DO UPDATE SET
          name = EXCLUDED.name,
          min_users = EXCLUDED.min_users,
          "maxUsers" = EXCLUDED."maxUsers",
          min_assets = EXCLUDED.min_assets,
          "maxAssets" = EXCLUDED."maxAssets",
          price = EXCLUDED.price,
          currency = EXCLUDED.currency,
          features = EXCLUDED.features
        RETURNING *;
      `,p=[s.toLowerCase().trim().replace(/\s+/g,"-"),a.trim(),parseInt(void 0!==i?i:1,10),parseInt(n,10),parseInt(void 0!==o?o:1,10),parseInt(u,10),parseFloat(l),d||"INR",JSON.stringify(c||{})],m=await (0,r.default)(e,p);return t.status(200).json({success:!0,message:`Plan "${a}" has been successfully added/updated in the catalog.`,plan:m.rows[0]})}catch(e){return console.error("Super Admin Save Plan Error:",e),t.status(500).json({message:"An internal server error occurred during plan saving."})}}return t.setHeader("Allow",["GET","POST"]),t.status(405).json({message:`Method ${e.method} Not Allowed`})}let l=(0,a.withAuth)(o);e.s(["default",0,l]),s()}catch(e){s(e)}},!1),63188,e=>e.a(async(t,s)=>{try{var r=e.i(33534),a=e.i(59016),i=e.i(55334),n=e.i(26175),o=e.i(38503),u=e.i(8322),l=e.i(84914),d=e.i(83666),c=t([o]);[o]=c.then?(await c)():c;let m=(0,n.hoist)(o,"default"),h=(0,n.hoist)(o,"config"),E=new i.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/superadmin/plans",pathname:"/api/superadmin/plans",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,s){E.isDev&&(0,d.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/superadmin/plans";a=a.replace(/\/index$/,"")||"/";let i=await E.prepare(e,t,{srcPage:a});if(!i){t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:n,params:o,prerenderManifest:c,routerServerContext:p}=i;try{let s=e.method||"GET",r=(0,u.getTracer)(),i=r.getActiveScopeSpan(),d=E.instrumentationOnRequestError.bind(E),m=async i=>E.render(e,t,{query:{...n,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:E.isDev,page:"/api/superadmin/plans",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>d(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${s} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${s} ${a}`)});i?await m(i):await r.withPropagatedContext(e.headers,()=>r.trace(l.BaseServerSpan.handleRequest,{spanName:`${s} ${a}`,kind:u.SpanKind.SERVER,attributes:{"http.method":s,"http.target":e.url}},m))}catch(e){if(E.isDev)throw e;(0,r.sendError)(t,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,h,"default",0,m,"handler",()=>p]),s()}catch(e){s(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__0cfc7a7d._.js.map