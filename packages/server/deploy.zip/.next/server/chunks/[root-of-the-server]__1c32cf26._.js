module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},18328,e=>e.a(async(t,s)=>{try{var r=e.i(65058),a=e.i(74606),n=t([r]);async function i(e,t){let s=e.headers.origin;(0,a.setCorsHeaders)(t,s);try{if("OPTIONS"===e.method)return t.status(200).end();if("GET"===e.method)return o(e,t);if("POST"===e.method)return d(e,t);if("PUT"===e.method)return l(e,t);return t.status(405).json({message:"Method not allowed"})}catch(e){return console.error("Supervisor API Error:",e),t.status(500).json({message:"Internal server error"})}}async function o(e,t){let s=Number(e.query.id);if(!s)return t.status(400).json({message:"Supervisor ID required"});let a=`
  SELECT
    n.id                    AS "notificationId",
    n.reason,
    n.reply,
    n.status,
    n.created_at            AS "createdAt",
    n."assignmentId",       -- 🔥 Need this for the PUT extend function later
    n."senderId",
    n."receiverId",
    ad.id                   AS "assetId",
    ad.name                 AS "assetName",

    u."fullName"            AS "operatorName" -- The person who sent the reply

  FROM "Notifications" n
  LEFT JOIN "Asset_Details" ad ON ad.id = n."assetId"
  -- Join Users to 'senderId' because in a reply, the Operator is the sender
  LEFT JOIN "Users" u ON u."employeeId" = n."senderId" 

  WHERE n."receiverId" = $1   -- Supervisor is the Receiver of the reply
    AND n.status IN ('unread', 'replied', 'received')  -- Only show active replies
  ORDER BY n.created_at DESC
`,{rows:n}=await (0,r.default)(a,[s]);return console.log(`Backend found ${n.length} replies for ID ${s}`),t.status(200).json(n)}async function d(e,t){let{assetId:s,assignmentId:a,operatorId:n,receiverId:i,reason:o}=e.body;if(!s||!n||!i||!o)return t.status(400).json({message:"Missing required fields"});let d=`
  INSERT INTO "Notifications"
    ("assetId", "assignmentId", "senderId", "receiverId", "reason", "status")
  VALUES ($1, $2, $3, $4, $5, 'unread')
  RETURNING *;
`,{rows:l}=await (0,r.default)(d,[s,a||null,n,i,o]);return t.status(201).json(l[0])}async function l(e,t){let{notificationId:s,assignmentId:a,newReturnDate:n}=e.body;return s&&a&&n?(await (0,r.default)(`UPDATE "Asset_Assignments"
     SET expected_return_date = $1
     WHERE id = $2`,[n,a]),await (0,r.default)(`UPDATE "Notifications"
     SET status = 'resolved'
     WHERE id = $1`,[s]),t.status(200).json({message:"Resolved successfully"})):t.status(400).json({message:"Missing required fields"})}[r]=n.then?(await n)():n,e.s(["default",()=>i]),s()}catch(e){s(e)}},!1),62794,e=>e.a(async(t,s)=>{try{var r=e.i(33534),a=e.i(59016),n=e.i(55334),i=e.i(26175),o=e.i(18328),d=e.i(8322),l=e.i(84914),u=e.i(83666),c=t([o]);[o]=c.then?(await c)():c;let h=(0,i.hoist)(o,"default"),f=(0,i.hoist)(o,"config"),m=new n.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/notifications/supervisor",pathname:"/api/notifications/supervisor",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function p(e,t,s){m.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/notifications/supervisor";a=a.replace(/\/index$/,"")||"/";let n=await m.prepare(e,t,{srcPage:a});if(!n){t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:i,params:o,prerenderManifest:c,routerServerContext:p}=n;try{let s=e.method||"GET",r=(0,d.getTracer)(),n=r.getActiveScopeSpan(),u=m.instrumentationOnRequestError.bind(m),h=async n=>m.render(e,t,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:m.isDev,page:"/api/notifications/supervisor",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${s} ${i}`;n.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),n.updateName(e)}else n.updateName(`${s} ${a}`)});n?await h(n):await r.withPropagatedContext(e.headers,()=>r.trace(l.BaseServerSpan.handleRequest,{spanName:`${s} ${a}`,kind:d.SpanKind.SERVER,attributes:{"http.method":s,"http.target":e.url}},h))}catch(e){if(m.isDev)throw e;(0,r.sendError)(t,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,f,"default",0,h,"handler",()=>p]),s()}catch(e){s(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__1c32cf26._.js.map