module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let a=t||"";a.endsWith("/")&&(a=a.slice(0,-1)),a&&(a.includes("localhost")||a.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(a))&&(e.setHeader("Access-Control-Allow-Origin",a),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},96187,(e,t,a)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},42196,e=>{"use strict";var t=e.i(96187);let a=process.env.JWT_SECRET||"super-secret-key-change-me";e.s(["signToken",0,e=>t.default.sign(e,a,{expiresIn:"1d"}),"verifyToken",0,e=>{try{return t.default.verify(e,a)}catch(e){return null}}])},19477,e=>{"use strict";var t=e.i(42196),a=e.i(74606);e.s(["withAuth",0,e=>async(s,r)=>{let i=s.headers.origin;if((0,a.setCorsHeaders)(r,i),"OPTIONS"===s.method)return void r.status(200).end();let n=s.headers.authorization;if(!n||!n.startsWith("Bearer "))return r.status(401).json({message:"Authorization token missing or invalid."});let l=n.split(" ")[1],o=(0,t.verifyToken)(l);return o?(s.user=o,e(s,r)):r.status(401).json({message:"Invalid or expired token."})}])},67124,e=>e.a(async(t,a)=>{try{var s=e.i(65058),r=e.i(74606),i=e.i(19477),n=t([s]);async function l(e,t){let a=e.headers.origin;if((0,r.setCorsHeaders)(t,a),"OPTIONS"===e.method)return void t.status(200).end();let{id:i}=e.query,{tenantId:n}=e.user;if(!i||"string"!=typeof i)return t.status(400).json({message:"Asset ID is required."});try{await (0,s.default)(`
      ALTER TABLE "Asset_Details" 
      ADD COLUMN IF NOT EXISTS "useful_life" INT DEFAULT 5,
      ADD COLUMN IF NOT EXISTS "salvage_value" VARCHAR(255);
    `,[])}catch(e){console.error("[AUTO-MIGRATION ERROR]",e)}if("PUT"===e.method)try{let{assetName:a,category:r,controllerKey:l,modelNumber:o,serialNumber:d,purchaseDate:u,warrantyExpiry:c,price:p,location:h,status:g,photoURL:I,barcodeURL:A,usefulLife:E,salvageValue:f,dynamicFields:m}=e.body;await (0,s.default)("BEGIN",[]);let y=await (0,s.default)('SELECT id FROM "Asset_Details" WHERE id = $1 AND "tenantId" = $2 LIMIT 1',[parseInt(i),n]);if(0===y.rows.length)return await (0,s.default)("ROLLBACK",[]),t.status(404).json({message:"Asset not found or access denied."});let v=[],S=[],w=1,$=await (0,s.default)(`SELECT cat.category AS category
         FROM "Asset_Details" a
         LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
         WHERE a.id = $1 AND a."tenantId" = $2
         LIMIT 1`,[parseInt(i),n]),R=String($.rows[0]?.category||"").trim().toLowerCase();if(void 0!==a&&(v.push(`name = $${w++}`),S.push(a)),void 0!==r){let e=await (0,s.default)('SELECT "categoryId" FROM "Category" WHERE category = $1 AND ("tenantId" = $2 OR "tenantId" IS NULL) LIMIT 1',[r,n]);e.rows.length>0&&(v.push(`"categoryId" = $${w++}`),S.push(e.rows[0].categoryId),R=String(r||"").trim().toLowerCase())}if(void 0!==l||void 0!==r){let e="string"==typeof l?l.trim():String(l||"").trim(),t=R.includes("controller")&&e||null;v.push(`"controller_key" = $${w++}`),S.push(t)}if(void 0!==o&&(v.push(`model_no = $${w++}`),S.push(o||null)),void 0!==d&&(v.push(`serial_no = $${w++}`),S.push(d)),void 0!==u&&(v.push(`purchase_date = $${w++}`),S.push(u||null)),void 0!==c&&(v.push(`warranty_expiry = $${w++}`),S.push(c||null)),void 0!==p&&(v.push(`price = $${w++}`),S.push(p||null)),void 0!==E&&(v.push(`"useful_life" = $${w++}`),S.push(null!==E?parseInt(String(E),10):5)),void 0!==f&&(v.push(`"salvage_value" = $${w++}`),S.push(f||null)),void 0!==h&&(v.push(`location = $${w++}`),S.push(h||null)),void 0!==g){let e=await (0,s.default)('SELECT id FROM "Status" WHERE status = $1 AND ("tenantId" = $2 OR "tenantId" IS NULL) LIMIT 1',[g,n]);e.rows.length>0&&(v.push(`status_id = $${w++}`),S.push(e.rows[0].id))}if(void 0!==I&&(v.push(`"photoURL" = $${w++}`),S.push(I||null)),void 0!==A&&(v.push(`"barcodeURL" = $${w++}`),S.push(A||null)),v.length>0){S.push(parseInt(i)),S.push(n);let e=`
          UPDATE "Asset_Details"
          SET ${v.join(", ")}
          WHERE id = $${w++} AND "tenantId" = $${w}
          RETURNING id
        `;await (0,s.default)(e,S)}if(m&&Array.isArray(m))for(let e of m)e.fieldId&&(await (0,s.default)('SELECT id FROM "AssetCategoryFields" WHERE id = $1 AND "tenantId" = $2 LIMIT 1',[e.fieldId,n])).rows.length>0&&(await (0,s.default)('DELETE FROM "AssetDynamicValues" WHERE "assetId" = $1 AND "fieldId" = $2',[parseInt(i),e.fieldId]),await (0,s.default)('INSERT INTO "AssetDynamicValues" ("assetId", "fieldId", value) VALUES ($1, $2, $3)',[parseInt(i),e.fieldId,String(e.value)]));return await (0,s.default)("COMMIT",[]),t.status(200).json({message:"Asset updated successfully",assetId:i})}catch(e){return await (0,s.default)("ROLLBACK",[]),console.error("Update Asset Error:",e),t.status(500).json({message:e.message||"Internal server error.",detail:e.detail})}if("GET"!==e.method)return t.setHeader("Allow",["GET","PUT"]),t.status(405).end(`Method ${e.method} Not Allowed`);try{let e=`
      SELECT
        a.id AS "assetId",
        a.name AS "assetName",
        cat.category AS "category",
        a."categoryId" AS "categoryId",
        a."controller_key" AS "controllerKey",
        s.status AS "dbStatus",
        a.model_no AS "modelNumber",
        a.serial_no AS "serialNumber",
        a."asset_Id" AS "barcode",
        a.location,
        a."photoURL",
        u."fullName" AS "assignedBy",
        a.assigned_to,
        a.warranty_expiry AS "warrantyExpiry",
        a.purchase_date AS "purchaseDate",
        a.price,
        a.useful_life AS "usefulLife",
        a.salvage_value AS "salvageValue",
        
        (
          SELECT "assigned_date"
          FROM "Asset_Assignments"
          WHERE "assetId" = a.id AND "tenantId" = $2
          ORDER BY id DESC
          LIMIT 1
        ) AS assigned_date,
        (
          SELECT "expected_return_date"
          FROM "Asset_Assignments"
          WHERE "assetId" = a.id AND "tenantId" = $2
          ORDER BY id DESC
          LIMIT 1
        ) AS expected_return_date
        ,(
          SELECT "projectName"
          FROM "Asset_Assignments"
          WHERE "assetId" = a.id AND "tenantId" = $2
          ORDER BY id DESC
          LIMIT 1
        ) AS "projectName"
      FROM "Asset_Details" a
      LEFT JOIN "Category" cat ON a."categoryId" = cat."categoryId"
      LEFT JOIN "Status" s ON a.status_id = s.id
      LEFT JOIN "Users" u ON a.assigned_by = u."employeeId"
      WHERE a.id = $1 AND a."tenantId" = $2;
    `,a=await (0,s.default)(e,[parseInt(i),n]);if(0===a.rows.length)return t.status(404).json({message:`Asset with ID ${i} not found.`});let r=a.rows[0],l=await (0,s.default)(`SELECT adv."fieldId", adv.value, acf."fieldName", acf."fieldType"
       FROM "AssetDynamicValues" adv
       JOIN "AssetCategoryFields" acf ON adv."fieldId" = acf.id
       WHERE adv."assetId" = $1`,[parseInt(i)]),o=e=>e?new Date(e).toISOString().split("T")[0]:null,d=new Date;d.setHours(0,0,0,0);let u=r.expected_return_date?new Date(r.expected_return_date):null,c=!!u&&u<d,p="Assigned"===r.dbStatus&&null!==r.assigned_to,h=parseFloat(r.price)||0,g=parseFloat(r.salvageValue)||0,I=parseInt(r.usefulLife)||5,A=h,E=100,f=0,m=null;if(h>0&&I>0&&r.purchaseDate){let e=new Date(r.purchaseDate),t=new Date,a=Math.max(0,(t.getTime()-e.getTime())/315576e5),s=(h-g)/I,i=Math.max(0,Math.min(s*a,h-g));A=h-i,f=a/I*100,f=Math.min(100,f),(E=Math.max(0,100-f))<60&&(m=`Depreciation alert: remaining life is ${E.toFixed(1)}%. Please scrap or upgrade this asset.`)}let y={assetId:r.assetId,assetName:r.assetName,category:r.category,categoryId:r.categoryId,controllerKey:r.controllerKey,status:p&&c?"Overdue":r.dbStatus,modelNumber:r.modelNumber,serialNumber:r.serialNumber,barcode:r.barcode,location:r.location,photoURL:r.photoURL||null,assignedBy:r.assignedBy||"N/A",warrantyExpiry:o(r.warrantyExpiry),purchaseDate:o(r.purchaseDate),assignedDate:o(r.assigned_date),expectedReturnDate:o(r.expected_return_date),projectName:r.projectName||null,price:r.price||null,value:r.price?parseFloat(r.price).toLocaleString():"N/A",usefulLife:I,salvageValue:r.salvageValue||null,remainingValue:parseFloat(A.toFixed(2)),depreciationMessage:m,dynamicValues:l.rows};return t.status(200).json(y)}catch(e){return console.error("Get Asset Error:",e),t.status(500).json({message:"Internal server error."})}}[s]=n.then?(await n)():n;let o=(0,i.withAuth)(l);e.s(["config",0,{api:{bodyParser:{sizeLimit:"10mb"}}},"default",0,o]),a()}catch(e){a(e)}},!1),59679,e=>e.a(async(t,a)=>{try{var s=e.i(33534),r=e.i(59016),i=e.i(55334),n=e.i(26175),l=e.i(67124),o=e.i(8322),d=e.i(84914),u=e.i(83666),c=t([l]);[l]=c.then?(await c)():c;let h=(0,n.hoist)(l,"default"),g=(0,n.hoist)(l,"config"),I=new i.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/assets/[id]",pathname:"/api/assets/[id]",bundlePath:"",filename:""},userland:l,distDir:".next",relativeProjectDir:""});async function p(e,t,a){I.isDev&&(0,u.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/assets/[id]";r=r.replace(/\/index$/,"")||"/";let i=await I.prepare(e,t,{srcPage:r});if(!i){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:n,params:l,prerenderManifest:c,routerServerContext:p}=i;try{let a=e.method||"GET",s=(0,o.getTracer)(),i=s.getActiveScopeSpan(),u=I.instrumentationOnRequestError.bind(I),h=async i=>I.render(e,t,{query:{...n,...l},params:l,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:I.isDev,page:"/api/assets/[id]",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>u(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${a} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${a} ${r}`)});i?await h(i):await s.withPropagatedContext(e.headers,()=>s.trace(d.BaseServerSpan.handleRequest,{spanName:`${a} ${r}`,kind:o.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},h))}catch(e){if(I.isDev)throw e;(0,s.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,g,"default",0,h,"handler",()=>p]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__1dc56ec1._.js.map