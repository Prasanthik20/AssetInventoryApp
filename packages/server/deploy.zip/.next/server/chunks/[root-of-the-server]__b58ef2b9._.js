module.exports=[70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let s=t||"";s.endsWith("/")&&(s=s.slice(0,-1)),s&&(s.includes("localhost")||s.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(s))&&(e.setHeader("Access-Control-Allow-Origin",s),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},37809,e=>{"use strict";var t=e.i(65058),s=e.i(74606);async function a(e,a){let r=e.headers.origin;if((0,s.setCorsHeaders)(a,r),"OPTIONS"===e.method)return void a.status(200).end();if("GET"!==e.method)return a.setHeader("Allow",["GET"]),a.status(405).end(`Method ${e.method} Not Allowed`);let n=e.query.id||e.query.userId||e.query.employeeId||e.query.operatorId;if(!n||"string"!=typeof n)return a.status(400).json({message:"User/Employee ID is required."});try{let e=parseInt(n)||0,s=String(n).trim(),r=await (0,t.default)(`SELECT TOP 1 "tenantId", "employeeId" 
       FROM "Users" 
       WHERE "employeeId" = $1 OR CAST("employeeId" AS VARCHAR(50)) = $2 OR "userId" = $1`,[e,s]),o=r.rows[0]?.tenantId||null,i=r.rows[0]?.employeeId?Number(r.rows[0].employeeId):e,d=`
      SELECT
        aa.id AS "assignmentId",
        ad.id AS "assetId",
        ad.name AS "assetName",
        ad.serial_no as "serialNo",
        ad."asset_Id" AS "barcode",
        COALESCE(aa."photoURL", ad."photoURL") AS "photoURL",
        COALESCE(aa."barcodeURL", ad."barcodeURL") AS "barcodeURL",
        COALESCE(aa.location, ad.location) AS "assetLocation",
        aa.assigned_date AS "assignedDate",
        aa.expected_return_date AS "expectedReturnDate",
        aa.returned_date AS "returnedDate",
        aa."supervisor_employeeId" AS "assignedById",
        COALESCE(u_assigner."fullName", CAST(aa."supervisor_employeeId" AS VARCHAR(50))) AS "assignedBy",
        aa.status AS "assignmentStatus",
        ad.assigned_to AS "currentlyAssignedTo",
        COALESCE(u_assignee."fullName", CAST(ad.assigned_to AS VARCHAR(50))) AS "assignedToName"
      FROM "Asset_Details" ad
      LEFT JOIN "Asset_Assignments" aa ON ad.id = aa."assetId"
      LEFT JOIN "Users" u_assigner ON CAST(aa."supervisor_employeeId" AS VARCHAR(50)) = CAST(u_assigner."employeeId" AS VARCHAR(50))
      LEFT JOIN "Users" u_assignee ON CAST(ad.assigned_to AS VARCHAR(50)) = CAST(u_assignee."employeeId" AS VARCHAR(50))
      WHERE (
        ad.assigned_to = $1 
        OR CAST(ad.assigned_to AS VARCHAR(50)) = $2
        OR aa."operator_employeeId" = $1 
        OR CAST(aa."operator_employeeId" AS VARCHAR(50)) = $2
      )
        AND ($3 IS NULL OR ad."tenantId" IS NULL OR ad."tenantId" = $3 OR LOWER(ad."tenantId") = LOWER($3))
      ORDER BY COALESCE(aa.assigned_date, ad.purchase_date) DESC, ad.id DESC;
    `,l=(await (0,t.default)(d,[i,s,o])).rows.map(e=>{let t=new Date;t.setHours(0,0,0,0);let a=!1,r=String(e.assignmentStatus||"assigned").toLowerCase();if(e.expectedReturnDate){let s=new Date(e.expectedReturnDate);s.setHours(0,0,0,0),a="assigned"===r&&s<t}let n=null!==e.currentlyAssignedTo&&void 0!==e.currentlyAssignedTo&&(Number(e.currentlyAssignedTo)===i||String(e.currentlyAssignedTo).trim()===s),o="Assigned";return"returned"!==r&&(n||null!==e.currentlyAssignedTo)?a&&(o="Overdue"):o="Returned",{assignmentId:Number(e.assignmentId||e.assignmentid||0),assetId:Number(e.assetId||e.assetid||0),assetName:e.assetName||e.assetname,barcode:e.barcode,barcodeURL:e.barcodeURL||e.barcodeurl,serialNo:e.serialNo||e.serialno,location:e.assetLocation&&"unassigned"!==String(e.assetLocation).trim().toLowerCase()&&"null"!==String(e.assetLocation).trim().toLowerCase()?String(e.assetLocation).trim():"Office",photoURL:e.photoURL,assignedDate:e.assignedDate,expectedReturnDate:e.expectedReturnDate,returnedDate:e.returnedDate,assignedById:e.assignedById,assignedBy:e.assignedBy,assignedTo:e.assignedToName||e.currentlyAssignedTo,isCurrentlyAssigned:n,isOverdue:a,status:o}}),u=`
      SELECT TOP 1 location 
      FROM "Asset_Assignments"
      WHERE "operator_employeeId" = $1
      ORDER BY assigned_date DESC;
    `,p=await (0,t.default)(u,[i]),c=p.rows.length>0?p.rows[0].location:"No Location",A=l.filter(e=>{let t=String(e?.status||"").toLowerCase();return"assigned"===t||"overdue"===t}).length,g=l.filter(e=>"returned"===String(e?.status||"").toLowerCase()).length;return a.status(200).json({userEmployeeId:i,assignedCount:A,returnedCount:g,location:c,assets:l})}catch(e){return console.error("My Assets API Error:",e),a.status(500).json({message:e?.message||"Internal server error.",details:String(e?.stack||e)})}}e.s(["default",()=>a])},41504,e=>{"use strict";var t=e.i(33534),s=e.i(59016),a=e.i(55334),r=e.i(26175);let n=e.i(37809).default;e.s(["default",0,n],696);var o=e.i(696),i=e.i(8322),d=e.i(84914),l=e.i(83666);let u=(0,r.hoist)(o,"default"),p=(0,r.hoist)(o,"config"),c=new a.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/operator/assets",pathname:"/api/operator/assets",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function A(e,s,a){c.isDev&&(0,l.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/operator/assets";r=r.replace(/\/index$/,"")||"/";let n=await c.prepare(e,s,{srcPage:r});if(!n){s.statusCode=400,s.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:o,params:u,prerenderManifest:p,routerServerContext:A}=n;try{let t=e.method||"GET",a=(0,i.getTracer)(),n=a.getActiveScopeSpan(),l=c.instrumentationOnRequestError.bind(c),g=async n=>c.render(e,s,{query:{...o,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:c.isDev,page:"/api/operator/assets",internalRevalidate:null==A?void 0:A.revalidate,onError:(...t)=>l(e,...t)}).finally(()=>{if(!n)return;n.setAttributes({"http.status_code":s.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let o=e.get("next.route");if(o){let e=`${t} ${o}`;n.setAttributes({"next.route":o,"http.route":o,"next.span_name":e}),n.updateName(e)}else n.updateName(`${t} ${r}`)});n?await g(n):await a.withPropagatedContext(e.headers,()=>a.trace(d.BaseServerSpan.handleRequest,{spanName:`${t} ${r}`,kind:i.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},g))}catch(e){if(c.isDev)throw e;(0,t.sendError)(s,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,p,"default",0,u,"handler",()=>A],41504)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__b58ef2b9._.js.map