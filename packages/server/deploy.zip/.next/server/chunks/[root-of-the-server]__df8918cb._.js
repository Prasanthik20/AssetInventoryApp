module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},74606,e=>{"use strict";function t(e,t){let a=t||"";a.endsWith("/")&&(a=a.slice(0,-1)),a&&(a.includes("localhost")||a.includes("127.0.0.1")||["https://assetmgmt.asquaretech.in","http://localhost:8081","http://localhost:8082","http://localhost:3000","http://127.0.0.1:8081","http://127.0.0.1:8082","http://127.0.0.1:3000","https://assetmgmt.asquaretech.in","https://assetmgmt.asquaretech.in/","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net","https://asq-asset-api-ckdtfzgqdggjcedv.southindia-01.azurewebsites.net/"].includes(a))&&(e.setHeader("Access-Control-Allow-Origin",a),e.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS,PATCH"),e.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, X-Requested-With"),e.setHeader("Access-Control-Allow-Credentials","true"))}e.s(["setCorsHeaders",()=>t])},46695,e=>e.a(async(t,a)=>{try{var r=e.i(65058),s=e.i(74606),i=t([r]);async function n(e,t){let a=e.headers.origin;if((0,s.setCorsHeaders)(t,a),"OPTIONS"===e.method)return void t.status(200).end();if("GET"!==e.method)return t.setHeader("Allow",["GET","OPTIONS"]),t.status(405).end(`Method ${e.method} Not Allowed`);let i=Number(e.query.id);if(!i)return t.status(400).json({message:"Operator ID missing or invalid"});try{let e=`
      SELECT
        n.id                    AS "notificationId",
        n.reason,
        n.reply,
        n.status,
        n.created_at            AS "createdAt",

        ad.id                   AS "assetId",
        ad.name                 AS "assetName",

        s."employeeId"          AS "senderId",
        s."fullName"            AS "senderName",

        r."employeeId"          AS "receiverId",
        r."fullName"            AS "receiverName"

      FROM "Notifications" n
      LEFT JOIN "Asset_Details" ad ON ad.id = n."assetId"
      LEFT JOIN "Users" s ON s."employeeId" = n."senderId"
      LEFT JOIN "Users" r ON r."employeeId" = n."receiverId"

      WHERE n."receiverId" = $1
        AND n.status IN ('unread', 'resolved', 'received')
      ORDER BY n.created_at DESC;
    `,{rows:a}=await (0,r.default)(e,[i]),s=a.map(e=>({id:e.notificationId,notificationId:e.notificationId,message:e.reply??e.reason,reason:e.reason,reply:e.reply,status:e.status,createdAt:e.createdAt,asset:e.assetId?{id:e.assetId,name:e.assetName}:null,sender:{employeeId:e.senderId,name:e.senderName},receiver:{employeeId:e.receiverId,name:e.receiverName}}));return t.status(200).json({notifications:s})}catch(e){return console.error("❌ Operator Notifications Error:",e),t.status(500).json({message:"Internal server error",error:e instanceof Error?e.message:e})}}[r]=i.then?(await i)():i,e.s(["default",()=>n]),a()}catch(e){a(e)}},!1),90921,e=>e.a(async(t,a)=>{try{var r=e.i(33534),s=e.i(59016),i=e.i(55334),n=e.i(26175),o=e.i(46695),d=e.i(8322),l=e.i(84914),c=e.i(83666),p=t([o]);[o]=p.then?(await p)():p;let h=(0,n.hoist)(o,"default"),m=(0,n.hoist)(o,"config"),f=new i.PagesAPIRouteModule({definition:{kind:s.RouteKind.PAGES_API,page:"/api/notifications/operator",pathname:"/api/notifications/operator",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function u(e,t,a){f.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let s="/api/notifications/operator";s=s.replace(/\/index$/,"")||"/";let i=await f.prepare(e,t,{srcPage:s});if(!i){t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:n,params:o,prerenderManifest:p,routerServerContext:u}=i;try{let a=e.method||"GET",r=(0,d.getTracer)(),i=r.getActiveScopeSpan(),c=f.instrumentationOnRequestError.bind(f),h=async i=>f.render(e,t,{query:{...n,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:f.isDev,page:"/api/notifications/operator",internalRevalidate:null==u?void 0:u.revalidate,onError:(...t)=>c(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${a} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${a} ${s}`)});i?await h(i):await r.withPropagatedContext(e.headers,()=>r.trace(l.BaseServerSpan.handleRequest,{spanName:`${a} ${s}`,kind:d.SpanKind.SERVER,attributes:{"http.method":a,"http.target":e.url}},h))}catch(e){if(f.isDev)throw e;(0,r.sendError)(t,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,m,"default",0,h,"handler",()=>u]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__df8918cb._.js.map